/*********
CONCEPT_RECORD_COMPLETENESS
number of 0s / total number of records 
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PERSON
cdmFieldName = GENDER_SOURCE_CONCEPT_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'PERSON.GENDER_SOURCE_CONCEPT_ID' as violating_field, 
		  cdmtable.* 
		from cy_imosphere_cdm_531.person cdmtable
		where cdmtable.gender_source_concept_id = 0 
		/*violatedRowsEnd*/
		) violated_rows
) violated_row_count,
( 
	select COUNT(*) as num_rows
	from cy_imosphere_cdm_531.person cdmtable
) denominator
;

/*********
CONCEPT_RECORD_COMPLETENESS
number of 0s / total number of records 
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PERSON
cdmFieldName = RACE_SOURCE_CONCEPT_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'PERSON.RACE_SOURCE_CONCEPT_ID' as violating_field, 
		  cdmtable.* 
		from cy_imosphere_cdm_531.person cdmtable
		where cdmtable.race_source_concept_id = 0 
		/*violatedRowsEnd*/
		) violated_rows
) violated_row_count,
( 
	select COUNT(*) as num_rows
	from cy_imosphere_cdm_531.person cdmtable
) denominator
;

/*********
CONCEPT_RECORD_COMPLETENESS
number of 0s / total number of records 
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PERSON
cdmFieldName = ETHNICITY_SOURCE_CONCEPT_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'PERSON.ETHNICITY_SOURCE_CONCEPT_ID' as violating_field, 
		  cdmtable.* 
		from cy_imosphere_cdm_531.person cdmtable
		where cdmtable.ethnicity_source_concept_id = 0 
		/*violatedRowsEnd*/
		) violated_rows
) violated_row_count,
( 
	select COUNT(*) as num_rows
	from cy_imosphere_cdm_531.person cdmtable
) denominator
;

/*********
CONCEPT_RECORD_COMPLETENESS
number of 0s / total number of records 
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_OCCURRENCE
cdmFieldName = VISIT_SOURCE_CONCEPT_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'VISIT_OCCURRENCE.VISIT_SOURCE_CONCEPT_ID' as violating_field, 
		  cdmtable.* 
		from cy_imosphere_cdm_531.visit_occurrence cdmtable
		where cdmtable.visit_source_concept_id = 0 
		/*violatedRowsEnd*/
		) violated_rows
) violated_row_count,
( 
	select COUNT(*) as num_rows
	from cy_imosphere_cdm_531.visit_occurrence cdmtable
) denominator
;

/*********
CONCEPT_RECORD_COMPLETENESS
number of 0s / total number of records 
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_SOURCE_CONCEPT_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'CONDITION_OCCURRENCE.CONDITION_SOURCE_CONCEPT_ID' as violating_field, 
		  cdmtable.* 
		from cy_imosphere_cdm_531.condition_occurrence cdmtable
		where cdmtable.condition_source_concept_id = 0 
		/*violatedRowsEnd*/
		) violated_rows
) violated_row_count,
( 
	select COUNT(*) as num_rows
	from cy_imosphere_cdm_531.condition_occurrence cdmtable
) denominator
;

/*********
CONCEPT_RECORD_COMPLETENESS
number of 0s / total number of records 
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DRUG_EXPOSURE
cdmFieldName = DRUG_SOURCE_CONCEPT_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'DRUG_EXPOSURE.DRUG_SOURCE_CONCEPT_ID' as violating_field, 
		  cdmtable.* 
		from cy_imosphere_cdm_531.drug_exposure cdmtable
		where cdmtable.drug_source_concept_id = 0 
		/*violatedRowsEnd*/
		) violated_rows
) violated_row_count,
( 
	select COUNT(*) as num_rows
	from cy_imosphere_cdm_531.drug_exposure cdmtable
) denominator
;

/*********
CONCEPT_RECORD_COMPLETENESS
number of 0s / total number of records 
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_SOURCE_CONCEPT_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'PROCEDURE_OCCURRENCE.PROCEDURE_SOURCE_CONCEPT_ID' as violating_field, 
		  cdmtable.* 
		from cy_imosphere_cdm_531.procedure_occurrence cdmtable
		where cdmtable.procedure_source_concept_id = 0 
		/*violatedRowsEnd*/
		) violated_rows
) violated_row_count,
( 
	select COUNT(*) as num_rows
	from cy_imosphere_cdm_531.procedure_occurrence cdmtable
) denominator
;

/*********
CONCEPT_RECORD_COMPLETENESS
number of 0s / total number of records 
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DEVICE_EXPOSURE
cdmFieldName = DEVICE_SOURCE_CONCEPT_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'DEVICE_EXPOSURE.DEVICE_SOURCE_CONCEPT_ID' as violating_field, 
		  cdmtable.* 
		from cy_imosphere_cdm_531.device_exposure cdmtable
		where cdmtable.device_source_concept_id = 0 
		/*violatedRowsEnd*/
		) violated_rows
) violated_row_count,
( 
	select COUNT(*) as num_rows
	from cy_imosphere_cdm_531.device_exposure cdmtable
) denominator
;

/*********
CONCEPT_RECORD_COMPLETENESS
number of 0s / total number of records * for the OBSERVATION.unit_concept_id and MEASUREMENT.unit_concept_id the numerator and denominator are limited to records where value_as_number IS NOT NULL
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = MEASUREMENT
cdmFieldName = MEASUREMENT_SOURCE_CONCEPT_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'MEASUREMENT.MEASUREMENT_SOURCE_CONCEPT_ID' as violating_field, 
		  cdmtable.* 
		from cy_imosphere_cdm_531.measurement cdmtable
		where cdmtable.measurement_source_concept_id = 0 
		/*violatedRowsEnd*/
		) violated_rows
) violated_row_count,
( 
	select COUNT(*) as num_rows
	from cy_imosphere_cdm_531.measurement cdmtable
) denominator
;

/*********
CONCEPT_RECORD_COMPLETENESS
number of 0s / total number of records 
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_DETAIL
cdmFieldName = VISIT_DETAIL_SOURCE_CONCEPT_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'VISIT_DETAIL.VISIT_DETAIL_SOURCE_CONCEPT_ID' as violating_field, 
		  cdmtable.* 
		from cy_imosphere_cdm_531.visit_detail cdmtable
		where cdmtable.visit_detail_source_concept_id = 0 
		/*violatedRowsEnd*/
		) violated_rows
) violated_row_count,
( 
	select COUNT(*) as num_rows
	from cy_imosphere_cdm_531.visit_detail cdmtable
) denominator
;

/*********
CONCEPT_RECORD_COMPLETENESS
number of 0s / total number of records 
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_DETAIL
cdmFieldName = ADMITTING_SOURCE_CONCEPT_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'VISIT_DETAIL.ADMITTING_SOURCE_CONCEPT_ID' as violating_field, 
		  cdmtable.* 
		from cy_imosphere_cdm_531.visit_detail cdmtable
		where cdmtable.admitting_source_concept_id = 0 
		/*violatedRowsEnd*/
		) violated_rows
) violated_row_count,
( 
	select COUNT(*) as num_rows
	from cy_imosphere_cdm_531.visit_detail cdmtable
) denominator
;

/*********
CONCEPT_RECORD_COMPLETENESS
number of 0s / total number of records * for the OBSERVATION.unit_concept_id and MEASUREMENT.unit_concept_id the numerator and denominator are limited to records where value_as_number IS NOT NULL
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = OBSERVATION
cdmFieldName = OBSERVATION_SOURCE_CONCEPT_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'OBSERVATION.OBSERVATION_SOURCE_CONCEPT_ID' as violating_field, 
		  cdmtable.* 
		from cy_imosphere_cdm_531.observation cdmtable
		where cdmtable.observation_source_concept_id = 0 
		/*violatedRowsEnd*/
		) violated_rows
) violated_row_count,
( 
	select COUNT(*) as num_rows
	from cy_imosphere_cdm_531.observation cdmtable
) denominator
;

/*********
CONCEPT_RECORD_COMPLETENESS
number of 0s / total number of records 
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROVIDER
cdmFieldName = SPECIALTY_SOURCE_CONCEPT_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'PROVIDER.SPECIALTY_SOURCE_CONCEPT_ID' as violating_field, 
		  cdmtable.* 
		from cy_imosphere_cdm_531.provider cdmtable
		where cdmtable.specialty_source_concept_id = 0 
		/*violatedRowsEnd*/
		) violated_rows
) violated_row_count,
( 
	select COUNT(*) as num_rows
	from cy_imosphere_cdm_531.provider cdmtable
) denominator
;

