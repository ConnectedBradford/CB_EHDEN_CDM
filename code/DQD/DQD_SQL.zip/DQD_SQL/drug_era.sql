CREATE TEMP TABLE vee8ifhftmp_de
  AS WITH ctepredrugtarget  as (select d.drug_exposure_id
         as drug_exposure_id,d.person_id
         as person_id,c.concept_id  as ingredient_concept_id,d.drug_exposure_start_date  as drug_exposure_start_date,d.days_supply  as days_supply,coalesce(
            ---NULLIF returns NULL if both values are the same, otherwise it returns the first parameter
            nullif(drug_exposure_end_date, null),
            ---If drug_exposure_end_date != NULL, return drug_exposure_end_date, otherwise go to next case
            nullif(DATE_ADD(IF(SAFE_CAST(drug_exposure_start_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(drug_exposure_start_date  AS STRING)),SAFE_CAST(drug_exposure_start_date  AS DATE)), interval days_supply DAY), drug_exposure_start_date),
            ---If days_supply != NULL or 0, return drug_exposure_start_date + days_supply, otherwise go to next case
            DATE_ADD(IF(SAFE_CAST(drug_exposure_start_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(drug_exposure_start_date  AS STRING)),SAFE_CAST(drug_exposure_start_date  AS DATE)), interval 1 DAY)
            ---Add 1 day to the drug_exposure_start_date since there is no end_date or INTERVAL for the days_supply
        )  as drug_exposure_end_date from CY_IMOSPHERE_CDM_531.drug_exposure d
        join CY_CDM_VOCAB.concept_ancestor ca on ca.descendant_concept_id = d.drug_concept_id
        join CY_CDM_VOCAB.concept c on ca.ancestor_concept_id = c.concept_id
        where c.vocabulary_id = 'RxNorm' ---8 selects RxNorm from the vocabulary_id
        and c.concept_class_id = 'Ingredient'
        and d.drug_concept_id != 0 ---Our unmapped drug_concept_id's are set to 0, so we don't want different drugs wrapped up in the same era
        and coalesce(cast(d.days_supply as int64), 0) >= 0 ---We have cases where days_supply is negative, and this can set the end_date before the start_date, which we don't want. So we're just looking over those rows. This is a data-quality issue.
)
, ctesubexposureenddates   as (select person_id as person_id,ingredient_concept_id as ingredient_concept_id,event_date  as end_date from (
        select person_id, ingredient_concept_id, event_date, event_type,
        max(start_ordinal) over (partition by person_id, ingredient_concept_id
            order by event_date, event_type rows unbounded preceding) as start_ordinal,
        -- this pulls the current START down from the prior rows so that the NULLs
        -- from the END DATES will contain a value we can compare with
            row_number() over (partition by person_id, ingredient_concept_id
                order by event_date, event_type) as overall_ord
            -- this re-numbers the inner UNION so all rows are numbered ordered by the event date
        from (
            -- select the start dates, assigning a row number to each
            select person_id, ingredient_concept_id, drug_exposure_start_date as event_date,
            -1 as event_type,
            row_number() over (partition by person_id, ingredient_concept_id
                order by drug_exposure_start_date) as start_ordinal
            from ctepredrugtarget
            union all
            select person_id, ingredient_concept_id, drug_exposure_end_date, 1 as event_type, null
            from ctepredrugtarget
        ) rawdata
    ) e
    where (2 * e.start_ordinal) - e.overall_ord = 0
)
, ctedrugexposureends   as ( select dt.person_id
     as person_id,dt.ingredient_concept_id
     as drug_concept_id,dt.drug_exposure_start_date
     as drug_exposure_start_date,min(e.end_date)  as drug_sub_exposure_end_date  from ctepredrugtarget dt
join ctesubexposureenddates e on dt.person_id = e.person_id and dt.ingredient_concept_id = e.ingredient_concept_id and e.end_date >= dt.drug_exposure_start_date
 group by  dt.drug_exposure_id
        , dt.person_id
    , dt.ingredient_concept_id
    , dt.drug_exposure_start_date
 )
--------------------------------------------------------------------------------------------------------------
, ctesubexposures as (
  select row_number() over (
      partition by person_id, drug_concept_id, drug_sub_exposure_end_date 
      order by person_id
  ) as row_number,
  person_id as person_id,
  drug_concept_id as drug_concept_id,
  min(drug_exposure_start_date) as drug_sub_exposure_start_date,
  drug_sub_exposure_end_date as drug_sub_exposure_end_date,
  count(*) as drug_exposure_count  
  from ctedrugexposureends
  group by person_id, drug_concept_id, drug_sub_exposure_end_date
)
--------------------------------------------------------------------------------------------------------------
/*Everything above grouped exposures into sub_exposures if there was overlap between exposures.
 *So there was no persistence window. Now we can add the persistence window to calculate eras.
 */
--------------------------------------------------------------------------------------------------------------
, ctefinaltarget  as (select row_number as row_number,person_id as person_id,drug_concept_id as ingredient_concept_id,drug_sub_exposure_start_date as drug_sub_exposure_start_date,drug_sub_exposure_end_date as drug_sub_exposure_end_date,drug_exposure_count
         as drug_exposure_count,DATE_DIFF(IF(SAFE_CAST(drug_sub_exposure_end_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(drug_sub_exposure_end_date  AS STRING)),SAFE_CAST(drug_sub_exposure_end_date  AS DATE)), IF(SAFE_CAST(drug_sub_exposure_start_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(drug_sub_exposure_start_date  AS STRING)),SAFE_CAST(drug_sub_exposure_start_date  AS DATE)), DAY)  as days_exposed from ctesubexposures
)
--------------------------------------------------------------------------------------------------------------
, cteenddates   as (select person_id as person_id,ingredient_concept_id as ingredient_concept_id,DATE_ADD(IF(SAFE_CAST(event_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(event_date  AS STRING)),SAFE_CAST(event_date  AS DATE)), interval -30 DAY)  as end_date from (
        select person_id, ingredient_concept_id, event_date, event_type,
        max(start_ordinal) over (partition by person_id, ingredient_concept_id
            order by event_date, event_type rows unbounded preceding) as start_ordinal,
        -- this pulls the current START down from the prior rows so that the NULLs
        -- from the END DATES will contain a value we can compare with
            row_number() over (partition by person_id, ingredient_concept_id
                order by event_date, event_type) as overall_ord
            -- this re-numbers the inner UNION so all rows are numbered ordered by the event date
        from (
            -- select the start dates, assigning a row number to each
            select person_id, ingredient_concept_id, drug_sub_exposure_start_date as event_date,
            -1 as event_type,
            row_number() over (partition by person_id, ingredient_concept_id
                order by drug_sub_exposure_start_date) as start_ordinal
            from ctefinaltarget
            union all
            -- pad the end dates by 30 to allow a grace period for overlapping ranges.
            select person_id, ingredient_concept_id, DATE_ADD(IF(SAFE_CAST(drug_sub_exposure_end_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(drug_sub_exposure_end_date  AS STRING)),SAFE_CAST(drug_sub_exposure_end_date  AS DATE)), interval 30 DAY), 1 as event_type, null
            from ctefinaltarget
        ) rawdata
    ) e
    where (2 * e.start_ordinal) - e.overall_ord = 0
)
, ctedrugeraends   as ( select ft.person_id
     as person_id,ft.ingredient_concept_id
     as drug_concept_id,ft.drug_sub_exposure_start_date
     as drug_sub_exposure_start_date,min(e.end_date)  as drug_era_end_date,drug_exposure_count
     as drug_exposure_count,days_exposed
 as days_exposed  from ctefinaltarget ft
join cteenddates e on ft.person_id = e.person_id and ft.ingredient_concept_id = e.ingredient_concept_id and e.end_date >= ft.drug_sub_exposure_start_date
 group by  ft.person_id
    , ft.ingredient_concept_id
    , ft.drug_sub_exposure_start_date
    , 5, 6 )
  SELECT
    row_number()over(order by person_id) drug_era_id
    , person_id
    , drug_concept_id
    , drug_era_start_date
    , drug_era_end_date
    , drug_exposure_count
    , gap_days
  FROM (
  SELECT 
     person_id
    , drug_concept_id
    , min(drug_sub_exposure_start_date) as drug_era_start_date
    , drug_era_end_date
    , sum(drug_exposure_count) as drug_exposure_count
    , DATE_DIFF(IF(SAFE_CAST(drug_era_end_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(drug_era_end_date  AS STRING)),SAFE_CAST(drug_era_end_date  AS DATE)), IF(SAFE_CAST(min(drug_sub_exposure_start_date)  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(min(drug_sub_exposure_start_date)  AS STRING)),SAFE_CAST(min(drug_sub_exposure_start_date)  AS DATE)), DAY)-sum(days_exposed) as gap_days
 FROM ctedrugeraends dee
 group by  1, 2, 4 ) dee2;
--insert into CY_IMOSPHERE_CDM_531.drug_era(drug_era_id,person_id, drug_concept_id, drug_era_start_date, drug_era_end_date, drug_exposure_count, gap_days)
select * from vee8ifhftmp_de;