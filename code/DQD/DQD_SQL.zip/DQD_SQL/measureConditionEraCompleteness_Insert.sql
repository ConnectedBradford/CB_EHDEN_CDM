/*********
Table Level:  
MEASURE_CONDITION_ERA_COMPLETENESS
Determine what #/% of persons have condition_era built successfully 
for persons in condition_occurrence table
Parameters used in this template:
cdmTableName = CONDITION_ERA
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_PERSON_COMPLETENESS' level,
    'Determine what #/% of persons have at least one record in the cdmTable' check,
    'CONDITION_ERA' cdmTableName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.person_id) as num_violated_rows
	from
	(
		select distinct 
		co.person_id
		from CY_IMOSPHERE_CDM_531.condition_occurrence co
		left join CY_IMOSPHERE_CDM_531.condition_era cdmtable 
		on co.person_id = cdmtable.person_id
  	where cdmtable.person_id is null
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(distinct person_id) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence co
) denominator
;

