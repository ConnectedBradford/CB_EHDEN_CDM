/*********
FIELD_IS_PRIMARY_KEY
Primary Key - verify those fields where IS_PRIMARY_KEY == Yes, the values in that field are unique
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PERSON
cdmFieldName = PERSON_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'FIELD_IS_PRIMARY_KEY' level,
    'Primary Key - verify those fields where IS_PRIMARY_KEY == Yes, the values in that field are unique' check,
    'PERSON' cdmTableName,
'PERSON_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'PERSON.PERSON_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.person cdmtable
		where cdmtable.person_id in ( 
			  select person_id 
		    from CY_IMOSPHERE_CDM_531.person
			  group by  1 having COUNT(*) > 1 
		 )
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.person cdmtable
) denominator
;

/*********
FIELD_IS_PRIMARY_KEY
Primary Key - verify those fields where IS_PRIMARY_KEY == Yes, the values in that field are unique
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = OBSERVATION_PERIOD
cdmFieldName = OBSERVATION_PERIOD_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'FIELD_IS_PRIMARY_KEY' level,
    'Primary Key - verify those fields where IS_PRIMARY_KEY == Yes, the values in that field are unique' check,
    'OBSERVATION_PERIOD' cdmTableName,
'OBSERVATION_PERIOD_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'OBSERVATION_PERIOD.OBSERVATION_PERIOD_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.observation_period cdmtable
		where cdmtable.observation_period_id in ( 
			  select observation_period_id 
		    from CY_IMOSPHERE_CDM_531.observation_period
			  group by  1 having COUNT(*) > 1 
		 )
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.observation_period cdmtable
) denominator
;

/*********
FIELD_IS_PRIMARY_KEY
Primary Key - verify those fields where IS_PRIMARY_KEY == Yes, the values in that field are unique
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_OCCURRENCE
cdmFieldName = VISIT_OCCURRENCE_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'FIELD_IS_PRIMARY_KEY' level,
    'Primary Key - verify those fields where IS_PRIMARY_KEY == Yes, the values in that field are unique' check,
    'VISIT_OCCURRENCE' cdmTableName,
'VISIT_OCCURRENCE_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'VISIT_OCCURRENCE.VISIT_OCCURRENCE_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
		where cdmtable.visit_occurrence_id in ( 
			  select visit_occurrence_id 
		    from CY_IMOSPHERE_CDM_531.visit_occurrence
			  group by  1 having COUNT(*) > 1 
		 )
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
) denominator
;

/*********
FIELD_IS_PRIMARY_KEY
Primary Key - verify those fields where IS_PRIMARY_KEY == Yes, the values in that field are unique
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_OCCURRENCE_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'FIELD_IS_PRIMARY_KEY' level,
    'Primary Key - verify those fields where IS_PRIMARY_KEY == Yes, the values in that field are unique' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_OCCURRENCE_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'CONDITION_OCCURRENCE.CONDITION_OCCURRENCE_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
		where cdmtable.condition_occurrence_id in ( 
			  select condition_occurrence_id 
		    from CY_IMOSPHERE_CDM_531.condition_occurrence
			  group by  1 having COUNT(*) > 1 
		 )
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
) denominator
;

/*********
FIELD_IS_PRIMARY_KEY
Primary Key - verify those fields where IS_PRIMARY_KEY == Yes, the values in that field are unique
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DRUG_EXPOSURE
cdmFieldName = DRUG_EXPOSURE_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'FIELD_IS_PRIMARY_KEY' level,
    'Primary Key - verify those fields where IS_PRIMARY_KEY == Yes, the values in that field are unique' check,
    'DRUG_EXPOSURE' cdmTableName,
'DRUG_EXPOSURE_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'DRUG_EXPOSURE.DRUG_EXPOSURE_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
		where cdmtable.drug_exposure_id in ( 
			  select drug_exposure_id 
		    from CY_IMOSPHERE_CDM_531.drug_exposure
			  group by  1 having COUNT(*) > 1 
		 )
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
) denominator
;

/*********
FIELD_IS_PRIMARY_KEY
Primary Key - verify those fields where IS_PRIMARY_KEY == Yes, the values in that field are unique
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_OCCURRENCE_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'FIELD_IS_PRIMARY_KEY' level,
    'Primary Key - verify those fields where IS_PRIMARY_KEY == Yes, the values in that field are unique' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_OCCURRENCE_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'PROCEDURE_OCCURRENCE.PROCEDURE_OCCURRENCE_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
		where cdmtable.procedure_occurrence_id in ( 
			  select procedure_occurrence_id 
		    from CY_IMOSPHERE_CDM_531.procedure_occurrence
			  group by  1 having COUNT(*) > 1 
		 )
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
) denominator
;

/*********
FIELD_IS_PRIMARY_KEY
Primary Key - verify those fields where IS_PRIMARY_KEY == Yes, the values in that field are unique
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DEVICE_EXPOSURE
cdmFieldName = DEVICE_EXPOSURE_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'FIELD_IS_PRIMARY_KEY' level,
    'Primary Key - verify those fields where IS_PRIMARY_KEY == Yes, the values in that field are unique' check,
    'DEVICE_EXPOSURE' cdmTableName,
'DEVICE_EXPOSURE_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'DEVICE_EXPOSURE.DEVICE_EXPOSURE_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.device_exposure cdmtable
		where cdmtable.device_exposure_id in ( 
			  select device_exposure_id 
		    from CY_IMOSPHERE_CDM_531.device_exposure
			  group by  1 having COUNT(*) > 1 
		 )
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.device_exposure cdmtable
) denominator
;

/*********
FIELD_IS_PRIMARY_KEY
Primary Key - verify those fields where IS_PRIMARY_KEY == Yes, the values in that field are unique
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = MEASUREMENT
cdmFieldName = MEASUREMENT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'FIELD_IS_PRIMARY_KEY' level,
    'Primary Key - verify those fields where IS_PRIMARY_KEY == Yes, the values in that field are unique' check,
    'MEASUREMENT' cdmTableName,
'MEASUREMENT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'MEASUREMENT.MEASUREMENT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.measurement cdmtable
		where cdmtable.measurement_id in ( 
			  select measurement_id 
		    from CY_IMOSPHERE_CDM_531.measurement
			  group by  1 having COUNT(*) > 1 
		 )
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.measurement cdmtable
) denominator
;

/*********
FIELD_IS_PRIMARY_KEY
Primary Key - verify those fields where IS_PRIMARY_KEY == Yes, the values in that field are unique
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_DETAIL
cdmFieldName = VISIT_DETAIL_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'FIELD_IS_PRIMARY_KEY' level,
    'Primary Key - verify those fields where IS_PRIMARY_KEY == Yes, the values in that field are unique' check,
    'VISIT_DETAIL' cdmTableName,
'VISIT_DETAIL_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'VISIT_DETAIL.VISIT_DETAIL_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
		where cdmtable.visit_detail_id in ( 
			  select visit_detail_id 
		    from CY_IMOSPHERE_CDM_531.visit_detail
			  group by  1 having COUNT(*) > 1 
		 )
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
) denominator
;

/*********
FIELD_IS_PRIMARY_KEY
Primary Key - verify those fields where IS_PRIMARY_KEY == Yes, the values in that field are unique
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = NOTE
cdmFieldName = NOTE_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'FIELD_IS_PRIMARY_KEY' level,
    'Primary Key - verify those fields where IS_PRIMARY_KEY == Yes, the values in that field are unique' check,
    'NOTE' cdmTableName,
'NOTE_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'NOTE.NOTE_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.note cdmtable
		where cdmtable.note_id in ( 
			  select note_id 
		    from CY_IMOSPHERE_CDM_531.note
			  group by  1 having COUNT(*) > 1 
		 )
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.note cdmtable
) denominator
;

/*********
FIELD_IS_PRIMARY_KEY
Primary Key - verify those fields where IS_PRIMARY_KEY == Yes, the values in that field are unique
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = NOTE_NLP
cdmFieldName = NOTE_NLP_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'FIELD_IS_PRIMARY_KEY' level,
    'Primary Key - verify those fields where IS_PRIMARY_KEY == Yes, the values in that field are unique' check,
    'NOTE_NLP' cdmTableName,
'NOTE_NLP_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'NOTE_NLP.NOTE_NLP_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.note_nlp cdmtable
		where cdmtable.note_nlp_id in ( 
			  select note_nlp_id 
		    from CY_IMOSPHERE_CDM_531.note_nlp
			  group by  1 having COUNT(*) > 1 
		 )
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.note_nlp cdmtable
) denominator
;

/*********
FIELD_IS_PRIMARY_KEY
Primary Key - verify those fields where IS_PRIMARY_KEY == Yes, the values in that field are unique
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = OBSERVATION
cdmFieldName = OBSERVATION_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'FIELD_IS_PRIMARY_KEY' level,
    'Primary Key - verify those fields where IS_PRIMARY_KEY == Yes, the values in that field are unique' check,
    'OBSERVATION' cdmTableName,
'OBSERVATION_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'OBSERVATION.OBSERVATION_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.observation cdmtable
		where cdmtable.observation_id in ( 
			  select observation_id 
		    from CY_IMOSPHERE_CDM_531.observation
			  group by  1 having COUNT(*) > 1 
		 )
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.observation cdmtable
) denominator
;

/*********
FIELD_IS_PRIMARY_KEY
Primary Key - verify those fields where IS_PRIMARY_KEY == Yes, the values in that field are unique
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = LOCATION
cdmFieldName = LOCATION_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'FIELD_IS_PRIMARY_KEY' level,
    'Primary Key - verify those fields where IS_PRIMARY_KEY == Yes, the values in that field are unique' check,
    'LOCATION' cdmTableName,
'LOCATION_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'LOCATION.LOCATION_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.location cdmtable
		where cdmtable.location_id in ( 
			  select location_id 
		    from CY_IMOSPHERE_CDM_531.location
			  group by  1 having COUNT(*) > 1 
		 )
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.location cdmtable
) denominator
;

/*********
FIELD_IS_PRIMARY_KEY
Primary Key - verify those fields where IS_PRIMARY_KEY == Yes, the values in that field are unique
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CARE_SITE
cdmFieldName = CARE_SITE_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'FIELD_IS_PRIMARY_KEY' level,
    'Primary Key - verify those fields where IS_PRIMARY_KEY == Yes, the values in that field are unique' check,
    'CARE_SITE' cdmTableName,
'CARE_SITE_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'CARE_SITE.CARE_SITE_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.care_site cdmtable
		where cdmtable.care_site_id in ( 
			  select care_site_id 
		    from CY_IMOSPHERE_CDM_531.care_site
			  group by  1 having COUNT(*) > 1 
		 )
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.care_site cdmtable
) denominator
;

/*********
FIELD_IS_PRIMARY_KEY
Primary Key - verify those fields where IS_PRIMARY_KEY == Yes, the values in that field are unique
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROVIDER
cdmFieldName = PROVIDER_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'FIELD_IS_PRIMARY_KEY' level,
    'Primary Key - verify those fields where IS_PRIMARY_KEY == Yes, the values in that field are unique' check,
    'PROVIDER' cdmTableName,
'PROVIDER_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'PROVIDER.PROVIDER_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.provider cdmtable
		where cdmtable.provider_id in ( 
			  select provider_id 
		    from CY_IMOSPHERE_CDM_531.provider
			  group by  1 having COUNT(*) > 1 
		 )
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.provider cdmtable
) denominator
;

/*********
FIELD_IS_PRIMARY_KEY
Primary Key - verify those fields where IS_PRIMARY_KEY == Yes, the values in that field are unique
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PAYER_PLAN_PERIOD
cdmFieldName = PAYER_PLAN_PERIOD_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'FIELD_IS_PRIMARY_KEY' level,
    'Primary Key - verify those fields where IS_PRIMARY_KEY == Yes, the values in that field are unique' check,
    'PAYER_PLAN_PERIOD' cdmTableName,
'PAYER_PLAN_PERIOD_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'PAYER_PLAN_PERIOD.PAYER_PLAN_PERIOD_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.payer_plan_period cdmtable
		where cdmtable.payer_plan_period_id in ( 
			  select payer_plan_period_id 
		    from CY_IMOSPHERE_CDM_531.payer_plan_period
			  group by  1 having COUNT(*) > 1 
		 )
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.payer_plan_period cdmtable
) denominator
;

/*********
FIELD_IS_PRIMARY_KEY
Primary Key - verify those fields where IS_PRIMARY_KEY == Yes, the values in that field are unique
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DRUG_ERA
cdmFieldName = DRUG_ERA_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'FIELD_IS_PRIMARY_KEY' level,
    'Primary Key - verify those fields where IS_PRIMARY_KEY == Yes, the values in that field are unique' check,
    'DRUG_ERA' cdmTableName,
'DRUG_ERA_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'DRUG_ERA.DRUG_ERA_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.drug_era cdmtable
		where cdmtable.drug_era_id in ( 
			  select drug_era_id 
		    from CY_IMOSPHERE_CDM_531.drug_era
			  group by  1 having COUNT(*) > 1 
		 )
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.drug_era cdmtable
) denominator
;

/*********
FIELD_IS_PRIMARY_KEY
Primary Key - verify those fields where IS_PRIMARY_KEY == Yes, the values in that field are unique
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_ERA
cdmFieldName = CONDITION_ERA_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'FIELD_IS_PRIMARY_KEY' level,
    'Primary Key - verify those fields where IS_PRIMARY_KEY == Yes, the values in that field are unique' check,
    'CONDITION_ERA' cdmTableName,
'CONDITION_ERA_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'CONDITION_ERA.CONDITION_ERA_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_era cdmtable
		where cdmtable.condition_era_id in ( 
			  select condition_era_id 
		    from CY_IMOSPHERE_CDM_531.condition_era
			  group by  1 having COUNT(*) > 1 
		 )
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_era cdmtable
) denominator
;

