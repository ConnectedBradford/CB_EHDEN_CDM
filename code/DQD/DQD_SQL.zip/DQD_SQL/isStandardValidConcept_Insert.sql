/*********
FIELD_IS_STANDARD_VALID_CONCEPT
all standard concept id fields are standard and valid
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = PERSON
cdmFieldName = GENDER_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'FIELD_IS_STANDARD_VALID_CONCEPT' level,
    'all standard concept id fields are standard and valid' check,
    'PERSON' cdmTableName,
'GENDER_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'PERSON.GENDER_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.person cdmtable
	  	join CY_CDM_VOCAB.concept co 
	  	on cdmtable.gender_concept_id = co.concept_id
		where co.concept_id != 0 
			and (co.standard_concept != 'S' or co.invalid_reason is not null)
		/*violatedRowsEnd*/
  ) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.person cdmtable
) denominator
;

/*********
FIELD_IS_STANDARD_VALID_CONCEPT
all standard concept id fields are standard and valid
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = PERSON
cdmFieldName = RACE_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'FIELD_IS_STANDARD_VALID_CONCEPT' level,
    'all standard concept id fields are standard and valid' check,
    'PERSON' cdmTableName,
'RACE_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'PERSON.RACE_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.person cdmtable
	  	join CY_CDM_VOCAB.concept co 
	  	on cdmtable.race_concept_id = co.concept_id
		where co.concept_id != 0 
			and (co.standard_concept != 'S' or co.invalid_reason is not null)
		/*violatedRowsEnd*/
  ) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.person cdmtable
) denominator
;

/*********
FIELD_IS_STANDARD_VALID_CONCEPT
all standard concept id fields are standard and valid
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = PERSON
cdmFieldName = ETHNICITY_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'FIELD_IS_STANDARD_VALID_CONCEPT' level,
    'all standard concept id fields are standard and valid' check,
    'PERSON' cdmTableName,
'ETHNICITY_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'PERSON.ETHNICITY_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.person cdmtable
	  	join CY_CDM_VOCAB.concept co 
	  	on cdmtable.ethnicity_concept_id = co.concept_id
		where co.concept_id != 0 
			and (co.standard_concept != 'S' or co.invalid_reason is not null)
		/*violatedRowsEnd*/
  ) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.person cdmtable
) denominator
;

/*********
FIELD_IS_STANDARD_VALID_CONCEPT
all standard concept id fields are standard and valid
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = OBSERVATION_PERIOD
cdmFieldName = PERIOD_TYPE_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'FIELD_IS_STANDARD_VALID_CONCEPT' level,
    'all standard concept id fields are standard and valid' check,
    'OBSERVATION_PERIOD' cdmTableName,
'PERIOD_TYPE_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'OBSERVATION_PERIOD.PERIOD_TYPE_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.observation_period cdmtable
	  	join CY_CDM_VOCAB.concept co 
	  	on cdmtable.period_type_concept_id = co.concept_id
		where co.concept_id != 0 
			and (co.standard_concept != 'S' or co.invalid_reason is not null)
		/*violatedRowsEnd*/
  ) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.observation_period cdmtable
) denominator
;

/*********
FIELD_IS_STANDARD_VALID_CONCEPT
all standard concept id fields are standard and valid
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = VISIT_OCCURRENCE
cdmFieldName = VISIT_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'FIELD_IS_STANDARD_VALID_CONCEPT' level,
    'all standard concept id fields are standard and valid' check,
    'VISIT_OCCURRENCE' cdmTableName,
'VISIT_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'VISIT_OCCURRENCE.VISIT_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
	  	join CY_CDM_VOCAB.concept co 
	  	on cdmtable.visit_concept_id = co.concept_id
		where co.concept_id != 0 
			and (co.standard_concept != 'S' or co.invalid_reason is not null)
		/*violatedRowsEnd*/
  ) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
) denominator
;

/*********
FIELD_IS_STANDARD_VALID_CONCEPT
all standard concept id fields are standard and valid
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = VISIT_OCCURRENCE
cdmFieldName = VISIT_TYPE_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'FIELD_IS_STANDARD_VALID_CONCEPT' level,
    'all standard concept id fields are standard and valid' check,
    'VISIT_OCCURRENCE' cdmTableName,
'VISIT_TYPE_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'VISIT_OCCURRENCE.VISIT_TYPE_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
	  	join CY_CDM_VOCAB.concept co 
	  	on cdmtable.visit_type_concept_id = co.concept_id
		where co.concept_id != 0 
			and (co.standard_concept != 'S' or co.invalid_reason is not null)
		/*violatedRowsEnd*/
  ) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
) denominator
;

/*********
FIELD_IS_STANDARD_VALID_CONCEPT
all standard concept id fields are standard and valid
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = VISIT_OCCURRENCE
cdmFieldName = ADMITTING_SOURCE_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'FIELD_IS_STANDARD_VALID_CONCEPT' level,
    'all standard concept id fields are standard and valid' check,
    'VISIT_OCCURRENCE' cdmTableName,
'ADMITTING_SOURCE_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'VISIT_OCCURRENCE.ADMITTING_SOURCE_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
	  	join CY_CDM_VOCAB.concept co 
	  	on cdmtable.admitting_source_concept_id = co.concept_id
		where co.concept_id != 0 
			and (co.standard_concept != 'S' or co.invalid_reason is not null)
		/*violatedRowsEnd*/
  ) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
) denominator
;

/*********
FIELD_IS_STANDARD_VALID_CONCEPT
all standard concept id fields are standard and valid
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = VISIT_OCCURRENCE
cdmFieldName = DISCHARGE_TO_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'FIELD_IS_STANDARD_VALID_CONCEPT' level,
    'all standard concept id fields are standard and valid' check,
    'VISIT_OCCURRENCE' cdmTableName,
'DISCHARGE_TO_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'VISIT_OCCURRENCE.DISCHARGE_TO_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
	  	join CY_CDM_VOCAB.concept co 
	  	on cdmtable.discharge_to_concept_id = co.concept_id
		where co.concept_id != 0 
			and (co.standard_concept != 'S' or co.invalid_reason is not null)
		/*violatedRowsEnd*/
  ) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
) denominator
;

/*********
FIELD_IS_STANDARD_VALID_CONCEPT
all standard concept id fields are standard and valid
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'FIELD_IS_STANDARD_VALID_CONCEPT' level,
    'all standard concept id fields are standard and valid' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'CONDITION_OCCURRENCE.CONDITION_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	  	join CY_CDM_VOCAB.concept co 
	  	on cdmtable.condition_concept_id = co.concept_id
		where co.concept_id != 0 
			and (co.standard_concept != 'S' or co.invalid_reason is not null)
		/*violatedRowsEnd*/
  ) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
) denominator
;

/*********
FIELD_IS_STANDARD_VALID_CONCEPT
all standard concept id fields are standard and valid
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_TYPE_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'FIELD_IS_STANDARD_VALID_CONCEPT' level,
    'all standard concept id fields are standard and valid' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_TYPE_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'CONDITION_OCCURRENCE.CONDITION_TYPE_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	  	join CY_CDM_VOCAB.concept co 
	  	on cdmtable.condition_type_concept_id = co.concept_id
		where co.concept_id != 0 
			and (co.standard_concept != 'S' or co.invalid_reason is not null)
		/*violatedRowsEnd*/
  ) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
) denominator
;

/*********
FIELD_IS_STANDARD_VALID_CONCEPT
all standard concept id fields are standard and valid
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_STATUS_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'FIELD_IS_STANDARD_VALID_CONCEPT' level,
    'all standard concept id fields are standard and valid' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_STATUS_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'CONDITION_OCCURRENCE.CONDITION_STATUS_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	  	join CY_CDM_VOCAB.concept co 
	  	on cdmtable.condition_status_concept_id = co.concept_id
		where co.concept_id != 0 
			and (co.standard_concept != 'S' or co.invalid_reason is not null)
		/*violatedRowsEnd*/
  ) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
) denominator
;

/*********
FIELD_IS_STANDARD_VALID_CONCEPT
all standard concept id fields are standard and valid
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = DRUG_EXPOSURE
cdmFieldName = DRUG_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'FIELD_IS_STANDARD_VALID_CONCEPT' level,
    'all standard concept id fields are standard and valid' check,
    'DRUG_EXPOSURE' cdmTableName,
'DRUG_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'DRUG_EXPOSURE.DRUG_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
	  	join CY_CDM_VOCAB.concept co 
	  	on cdmtable.drug_concept_id = co.concept_id
		where co.concept_id != 0 
			and (co.standard_concept != 'S' or co.invalid_reason is not null)
		/*violatedRowsEnd*/
  ) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
) denominator
;

/*********
FIELD_IS_STANDARD_VALID_CONCEPT
all standard concept id fields are standard and valid
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = DRUG_EXPOSURE
cdmFieldName = DRUG_TYPE_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'FIELD_IS_STANDARD_VALID_CONCEPT' level,
    'all standard concept id fields are standard and valid' check,
    'DRUG_EXPOSURE' cdmTableName,
'DRUG_TYPE_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'DRUG_EXPOSURE.DRUG_TYPE_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
	  	join CY_CDM_VOCAB.concept co 
	  	on cdmtable.drug_type_concept_id = co.concept_id
		where co.concept_id != 0 
			and (co.standard_concept != 'S' or co.invalid_reason is not null)
		/*violatedRowsEnd*/
  ) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
) denominator
;

/*********
FIELD_IS_STANDARD_VALID_CONCEPT
all standard concept id fields are standard and valid
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = DRUG_EXPOSURE
cdmFieldName = ROUTE_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'FIELD_IS_STANDARD_VALID_CONCEPT' level,
    'all standard concept id fields are standard and valid' check,
    'DRUG_EXPOSURE' cdmTableName,
'ROUTE_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'DRUG_EXPOSURE.ROUTE_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
	  	join CY_CDM_VOCAB.concept co 
	  	on cdmtable.route_concept_id = co.concept_id
		where co.concept_id != 0 
			and (co.standard_concept != 'S' or co.invalid_reason is not null)
		/*violatedRowsEnd*/
  ) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
) denominator
;

/*********
FIELD_IS_STANDARD_VALID_CONCEPT
all standard concept id fields are standard and valid
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'FIELD_IS_STANDARD_VALID_CONCEPT' level,
    'all standard concept id fields are standard and valid' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'PROCEDURE_OCCURRENCE.PROCEDURE_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
	  	join CY_CDM_VOCAB.concept co 
	  	on cdmtable.procedure_concept_id = co.concept_id
		where co.concept_id != 0 
			and (co.standard_concept != 'S' or co.invalid_reason is not null)
		/*violatedRowsEnd*/
  ) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
) denominator
;

/*********
FIELD_IS_STANDARD_VALID_CONCEPT
all standard concept id fields are standard and valid
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_TYPE_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'FIELD_IS_STANDARD_VALID_CONCEPT' level,
    'all standard concept id fields are standard and valid' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_TYPE_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'PROCEDURE_OCCURRENCE.PROCEDURE_TYPE_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
	  	join CY_CDM_VOCAB.concept co 
	  	on cdmtable.procedure_type_concept_id = co.concept_id
		where co.concept_id != 0 
			and (co.standard_concept != 'S' or co.invalid_reason is not null)
		/*violatedRowsEnd*/
  ) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
) denominator
;

/*********
FIELD_IS_STANDARD_VALID_CONCEPT
all standard concept id fields are standard and valid
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = MODIFIER_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'FIELD_IS_STANDARD_VALID_CONCEPT' level,
    'all standard concept id fields are standard and valid' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'MODIFIER_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'PROCEDURE_OCCURRENCE.MODIFIER_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
	  	join CY_CDM_VOCAB.concept co 
	  	on cdmtable.modifier_concept_id = co.concept_id
		where co.concept_id != 0 
			and (co.standard_concept != 'S' or co.invalid_reason is not null)
		/*violatedRowsEnd*/
  ) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
) denominator
;

/*********
FIELD_IS_STANDARD_VALID_CONCEPT
all standard concept id fields are standard and valid
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = DEVICE_EXPOSURE
cdmFieldName = DEVICE_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'FIELD_IS_STANDARD_VALID_CONCEPT' level,
    'all standard concept id fields are standard and valid' check,
    'DEVICE_EXPOSURE' cdmTableName,
'DEVICE_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'DEVICE_EXPOSURE.DEVICE_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.device_exposure cdmtable
	  	join CY_CDM_VOCAB.concept co 
	  	on cdmtable.device_concept_id = co.concept_id
		where co.concept_id != 0 
			and (co.standard_concept != 'S' or co.invalid_reason is not null)
		/*violatedRowsEnd*/
  ) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.device_exposure cdmtable
) denominator
;

/*********
FIELD_IS_STANDARD_VALID_CONCEPT
all standard concept id fields are standard and valid
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = DEVICE_EXPOSURE
cdmFieldName = DEVICE_TYPE_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'FIELD_IS_STANDARD_VALID_CONCEPT' level,
    'all standard concept id fields are standard and valid' check,
    'DEVICE_EXPOSURE' cdmTableName,
'DEVICE_TYPE_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'DEVICE_EXPOSURE.DEVICE_TYPE_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.device_exposure cdmtable
	  	join CY_CDM_VOCAB.concept co 
	  	on cdmtable.device_type_concept_id = co.concept_id
		where co.concept_id != 0 
			and (co.standard_concept != 'S' or co.invalid_reason is not null)
		/*violatedRowsEnd*/
  ) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.device_exposure cdmtable
) denominator
;

/*********
FIELD_IS_STANDARD_VALID_CONCEPT
all standard concept id fields are standard and valid
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = MEASUREMENT
cdmFieldName = MEASUREMENT_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'FIELD_IS_STANDARD_VALID_CONCEPT' level,
    'all standard concept id fields are standard and valid' check,
    'MEASUREMENT' cdmTableName,
'MEASUREMENT_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'MEASUREMENT.MEASUREMENT_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.measurement cdmtable
	  	join CY_CDM_VOCAB.concept co 
	  	on cdmtable.measurement_concept_id = co.concept_id
		where co.concept_id != 0 
			and (co.standard_concept != 'S' or co.invalid_reason is not null)
		/*violatedRowsEnd*/
  ) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.measurement cdmtable
) denominator
;

/*********
FIELD_IS_STANDARD_VALID_CONCEPT
all standard concept id fields are standard and valid
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = MEASUREMENT
cdmFieldName = MEASUREMENT_TYPE_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'FIELD_IS_STANDARD_VALID_CONCEPT' level,
    'all standard concept id fields are standard and valid' check,
    'MEASUREMENT' cdmTableName,
'MEASUREMENT_TYPE_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'MEASUREMENT.MEASUREMENT_TYPE_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.measurement cdmtable
	  	join CY_CDM_VOCAB.concept co 
	  	on cdmtable.measurement_type_concept_id = co.concept_id
		where co.concept_id != 0 
			and (co.standard_concept != 'S' or co.invalid_reason is not null)
		/*violatedRowsEnd*/
  ) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.measurement cdmtable
) denominator
;

/*********
FIELD_IS_STANDARD_VALID_CONCEPT
all standard concept id fields are standard and valid
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = MEASUREMENT
cdmFieldName = OPERATOR_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'FIELD_IS_STANDARD_VALID_CONCEPT' level,
    'all standard concept id fields are standard and valid' check,
    'MEASUREMENT' cdmTableName,
'OPERATOR_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'MEASUREMENT.OPERATOR_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.measurement cdmtable
	  	join CY_CDM_VOCAB.concept co 
	  	on cdmtable.operator_concept_id = co.concept_id
		where co.concept_id != 0 
			and (co.standard_concept != 'S' or co.invalid_reason is not null)
		/*violatedRowsEnd*/
  ) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.measurement cdmtable
) denominator
;

/*********
FIELD_IS_STANDARD_VALID_CONCEPT
all standard concept id fields are standard and valid
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = MEASUREMENT
cdmFieldName = UNIT_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'FIELD_IS_STANDARD_VALID_CONCEPT' level,
    'all standard concept id fields are standard and valid' check,
    'MEASUREMENT' cdmTableName,
'UNIT_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'MEASUREMENT.UNIT_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.measurement cdmtable
	  	join CY_CDM_VOCAB.concept co 
	  	on cdmtable.unit_concept_id = co.concept_id
		where co.concept_id != 0 
			and (co.standard_concept != 'S' or co.invalid_reason is not null)
		/*violatedRowsEnd*/
  ) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.measurement cdmtable
) denominator
;

/*********
FIELD_IS_STANDARD_VALID_CONCEPT
all standard concept id fields are standard and valid
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = VISIT_DETAIL
cdmFieldName = VISIT_DETAIL_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'FIELD_IS_STANDARD_VALID_CONCEPT' level,
    'all standard concept id fields are standard and valid' check,
    'VISIT_DETAIL' cdmTableName,
'VISIT_DETAIL_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'VISIT_DETAIL.VISIT_DETAIL_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
	  	join CY_CDM_VOCAB.concept co 
	  	on cdmtable.visit_detail_concept_id = co.concept_id
		where co.concept_id != 0 
			and (co.standard_concept != 'S' or co.invalid_reason is not null)
		/*violatedRowsEnd*/
  ) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
) denominator
;

/*********
FIELD_IS_STANDARD_VALID_CONCEPT
all standard concept id fields are standard and valid
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = VISIT_DETAIL
cdmFieldName = VISIT_DETAIL_TYPE_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'FIELD_IS_STANDARD_VALID_CONCEPT' level,
    'all standard concept id fields are standard and valid' check,
    'VISIT_DETAIL' cdmTableName,
'VISIT_DETAIL_TYPE_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'VISIT_DETAIL.VISIT_DETAIL_TYPE_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
	  	join CY_CDM_VOCAB.concept co 
	  	on cdmtable.visit_detail_type_concept_id = co.concept_id
		where co.concept_id != 0 
			and (co.standard_concept != 'S' or co.invalid_reason is not null)
		/*violatedRowsEnd*/
  ) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
) denominator
;

/*********
FIELD_IS_STANDARD_VALID_CONCEPT
all standard concept id fields are standard and valid
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = VISIT_DETAIL
cdmFieldName = ADMITTING_SOURCE_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'FIELD_IS_STANDARD_VALID_CONCEPT' level,
    'all standard concept id fields are standard and valid' check,
    'VISIT_DETAIL' cdmTableName,
'ADMITTING_SOURCE_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'VISIT_DETAIL.ADMITTING_SOURCE_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
	  	join CY_CDM_VOCAB.concept co 
	  	on cdmtable.admitting_source_concept_id = co.concept_id
		where co.concept_id != 0 
			and (co.standard_concept != 'S' or co.invalid_reason is not null)
		/*violatedRowsEnd*/
  ) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
) denominator
;

/*********
FIELD_IS_STANDARD_VALID_CONCEPT
all standard concept id fields are standard and valid
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = VISIT_DETAIL
cdmFieldName = DISCHARGE_TO_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'FIELD_IS_STANDARD_VALID_CONCEPT' level,
    'all standard concept id fields are standard and valid' check,
    'VISIT_DETAIL' cdmTableName,
'DISCHARGE_TO_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'VISIT_DETAIL.DISCHARGE_TO_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
	  	join CY_CDM_VOCAB.concept co 
	  	on cdmtable.discharge_to_concept_id = co.concept_id
		where co.concept_id != 0 
			and (co.standard_concept != 'S' or co.invalid_reason is not null)
		/*violatedRowsEnd*/
  ) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
) denominator
;

/*********
FIELD_IS_STANDARD_VALID_CONCEPT
all standard concept id fields are standard and valid
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = NOTE
cdmFieldName = NOTE_TYPE_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'FIELD_IS_STANDARD_VALID_CONCEPT' level,
    'all standard concept id fields are standard and valid' check,
    'NOTE' cdmTableName,
'NOTE_TYPE_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'NOTE.NOTE_TYPE_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.note cdmtable
	  	join CY_CDM_VOCAB.concept co 
	  	on cdmtable.note_type_concept_id = co.concept_id
		where co.concept_id != 0 
			and (co.standard_concept != 'S' or co.invalid_reason is not null)
		/*violatedRowsEnd*/
  ) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.note cdmtable
) denominator
;

/*********
FIELD_IS_STANDARD_VALID_CONCEPT
all standard concept id fields are standard and valid
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = NOTE
cdmFieldName = NOTE_CLASS_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'FIELD_IS_STANDARD_VALID_CONCEPT' level,
    'all standard concept id fields are standard and valid' check,
    'NOTE' cdmTableName,
'NOTE_CLASS_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'NOTE.NOTE_CLASS_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.note cdmtable
	  	join CY_CDM_VOCAB.concept co 
	  	on cdmtable.note_class_concept_id = co.concept_id
		where co.concept_id != 0 
			and (co.standard_concept != 'S' or co.invalid_reason is not null)
		/*violatedRowsEnd*/
  ) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.note cdmtable
) denominator
;

/*********
FIELD_IS_STANDARD_VALID_CONCEPT
all standard concept id fields are standard and valid
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = NOTE
cdmFieldName = ENCODING_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'FIELD_IS_STANDARD_VALID_CONCEPT' level,
    'all standard concept id fields are standard and valid' check,
    'NOTE' cdmTableName,
'ENCODING_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'NOTE.ENCODING_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.note cdmtable
	  	join CY_CDM_VOCAB.concept co 
	  	on cdmtable.encoding_concept_id = co.concept_id
		where co.concept_id != 0 
			and (co.standard_concept != 'S' or co.invalid_reason is not null)
		/*violatedRowsEnd*/
  ) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.note cdmtable
) denominator
;

/*********
FIELD_IS_STANDARD_VALID_CONCEPT
all standard concept id fields are standard and valid
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = NOTE
cdmFieldName = LANGUAGE_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'FIELD_IS_STANDARD_VALID_CONCEPT' level,
    'all standard concept id fields are standard and valid' check,
    'NOTE' cdmTableName,
'LANGUAGE_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'NOTE.LANGUAGE_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.note cdmtable
	  	join CY_CDM_VOCAB.concept co 
	  	on cdmtable.language_concept_id = co.concept_id
		where co.concept_id != 0 
			and (co.standard_concept != 'S' or co.invalid_reason is not null)
		/*violatedRowsEnd*/
  ) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.note cdmtable
) denominator
;

/*********
FIELD_IS_STANDARD_VALID_CONCEPT
all standard concept id fields are standard and valid
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = NOTE_NLP
cdmFieldName = SECTION_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'FIELD_IS_STANDARD_VALID_CONCEPT' level,
    'all standard concept id fields are standard and valid' check,
    'NOTE_NLP' cdmTableName,
'SECTION_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'NOTE_NLP.SECTION_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.note_nlp cdmtable
	  	join CY_CDM_VOCAB.concept co 
	  	on cdmtable.section_concept_id = co.concept_id
		where co.concept_id != 0 
			and (co.standard_concept != 'S' or co.invalid_reason is not null)
		/*violatedRowsEnd*/
  ) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.note_nlp cdmtable
) denominator
;

/*********
FIELD_IS_STANDARD_VALID_CONCEPT
all standard concept id fields are standard and valid
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = NOTE_NLP
cdmFieldName = NOTE_NLP_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'FIELD_IS_STANDARD_VALID_CONCEPT' level,
    'all standard concept id fields are standard and valid' check,
    'NOTE_NLP' cdmTableName,
'NOTE_NLP_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'NOTE_NLP.NOTE_NLP_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.note_nlp cdmtable
	  	join CY_CDM_VOCAB.concept co 
	  	on cdmtable.note_nlp_concept_id = co.concept_id
		where co.concept_id != 0 
			and (co.standard_concept != 'S' or co.invalid_reason is not null)
		/*violatedRowsEnd*/
  ) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.note_nlp cdmtable
) denominator
;

/*********
FIELD_IS_STANDARD_VALID_CONCEPT
all standard concept id fields are standard and valid
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = OBSERVATION
cdmFieldName = OBSERVATION_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'FIELD_IS_STANDARD_VALID_CONCEPT' level,
    'all standard concept id fields are standard and valid' check,
    'OBSERVATION' cdmTableName,
'OBSERVATION_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'OBSERVATION.OBSERVATION_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.observation cdmtable
	  	join CY_CDM_VOCAB.concept co 
	  	on cdmtable.observation_concept_id = co.concept_id
		where co.concept_id != 0 
			and (co.standard_concept != 'S' or co.invalid_reason is not null)
		/*violatedRowsEnd*/
  ) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.observation cdmtable
) denominator
;

/*********
FIELD_IS_STANDARD_VALID_CONCEPT
all standard concept id fields are standard and valid
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = OBSERVATION
cdmFieldName = OBSERVATION_TYPE_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'FIELD_IS_STANDARD_VALID_CONCEPT' level,
    'all standard concept id fields are standard and valid' check,
    'OBSERVATION' cdmTableName,
'OBSERVATION_TYPE_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'OBSERVATION.OBSERVATION_TYPE_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.observation cdmtable
	  	join CY_CDM_VOCAB.concept co 
	  	on cdmtable.observation_type_concept_id = co.concept_id
		where co.concept_id != 0 
			and (co.standard_concept != 'S' or co.invalid_reason is not null)
		/*violatedRowsEnd*/
  ) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.observation cdmtable
) denominator
;

/*********
FIELD_IS_STANDARD_VALID_CONCEPT
all standard concept id fields are standard and valid
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = OBSERVATION
cdmFieldName = QUALIFIER_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'FIELD_IS_STANDARD_VALID_CONCEPT' level,
    'all standard concept id fields are standard and valid' check,
    'OBSERVATION' cdmTableName,
'QUALIFIER_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'OBSERVATION.QUALIFIER_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.observation cdmtable
	  	join CY_CDM_VOCAB.concept co 
	  	on cdmtable.qualifier_concept_id = co.concept_id
		where co.concept_id != 0 
			and (co.standard_concept != 'S' or co.invalid_reason is not null)
		/*violatedRowsEnd*/
  ) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.observation cdmtable
) denominator
;

/*********
FIELD_IS_STANDARD_VALID_CONCEPT
all standard concept id fields are standard and valid
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = OBSERVATION
cdmFieldName = UNIT_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'FIELD_IS_STANDARD_VALID_CONCEPT' level,
    'all standard concept id fields are standard and valid' check,
    'OBSERVATION' cdmTableName,
'UNIT_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'OBSERVATION.UNIT_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.observation cdmtable
	  	join CY_CDM_VOCAB.concept co 
	  	on cdmtable.unit_concept_id = co.concept_id
		where co.concept_id != 0 
			and (co.standard_concept != 'S' or co.invalid_reason is not null)
		/*violatedRowsEnd*/
  ) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.observation cdmtable
) denominator
;

/*********
FIELD_IS_STANDARD_VALID_CONCEPT
all standard concept id fields are standard and valid
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = CARE_SITE
cdmFieldName = PLACE_OF_SERVICE_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'FIELD_IS_STANDARD_VALID_CONCEPT' level,
    'all standard concept id fields are standard and valid' check,
    'CARE_SITE' cdmTableName,
'PLACE_OF_SERVICE_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'CARE_SITE.PLACE_OF_SERVICE_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.care_site cdmtable
	  	join CY_CDM_VOCAB.concept co 
	  	on cdmtable.place_of_service_concept_id = co.concept_id
		where co.concept_id != 0 
			and (co.standard_concept != 'S' or co.invalid_reason is not null)
		/*violatedRowsEnd*/
  ) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.care_site cdmtable
) denominator
;

/*********
FIELD_IS_STANDARD_VALID_CONCEPT
all standard concept id fields are standard and valid
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = PROVIDER
cdmFieldName = SPECIALTY_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'FIELD_IS_STANDARD_VALID_CONCEPT' level,
    'all standard concept id fields are standard and valid' check,
    'PROVIDER' cdmTableName,
'SPECIALTY_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'PROVIDER.SPECIALTY_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.provider cdmtable
	  	join CY_CDM_VOCAB.concept co 
	  	on cdmtable.specialty_concept_id = co.concept_id
		where co.concept_id != 0 
			and (co.standard_concept != 'S' or co.invalid_reason is not null)
		/*violatedRowsEnd*/
  ) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.provider cdmtable
) denominator
;

/*********
FIELD_IS_STANDARD_VALID_CONCEPT
all standard concept id fields are standard and valid
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = PROVIDER
cdmFieldName = GENDER_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'FIELD_IS_STANDARD_VALID_CONCEPT' level,
    'all standard concept id fields are standard and valid' check,
    'PROVIDER' cdmTableName,
'GENDER_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'PROVIDER.GENDER_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.provider cdmtable
	  	join CY_CDM_VOCAB.concept co 
	  	on cdmtable.gender_concept_id = co.concept_id
		where co.concept_id != 0 
			and (co.standard_concept != 'S' or co.invalid_reason is not null)
		/*violatedRowsEnd*/
  ) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.provider cdmtable
) denominator
;

/*********
FIELD_IS_STANDARD_VALID_CONCEPT
all standard concept id fields are standard and valid
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = DRUG_ERA
cdmFieldName = DRUG_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'FIELD_IS_STANDARD_VALID_CONCEPT' level,
    'all standard concept id fields are standard and valid' check,
    'DRUG_ERA' cdmTableName,
'DRUG_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'DRUG_ERA.DRUG_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.drug_era cdmtable
	  	join CY_CDM_VOCAB.concept co 
	  	on cdmtable.drug_concept_id = co.concept_id
		where co.concept_id != 0 
			and (co.standard_concept != 'S' or co.invalid_reason is not null)
		/*violatedRowsEnd*/
  ) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.drug_era cdmtable
) denominator
;

/*********
FIELD_IS_STANDARD_VALID_CONCEPT
all standard concept id fields are standard and valid
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = CONDITION_ERA
cdmFieldName = CONDITION_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'FIELD_IS_STANDARD_VALID_CONCEPT' level,
    'all standard concept id fields are standard and valid' check,
    'CONDITION_ERA' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'CONDITION_ERA.CONDITION_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_era cdmtable
	  	join CY_CDM_VOCAB.concept co 
	  	on cdmtable.condition_concept_id = co.concept_id
		where co.concept_id != 0 
			and (co.standard_concept != 'S' or co.invalid_reason is not null)
		/*violatedRowsEnd*/
  ) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_era cdmtable
) denominator
;

