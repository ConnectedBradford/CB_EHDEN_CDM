/*********
PLAUSIBLE_DURING_LIFE
get number of events that occur after death event (PLAUSIBLE_DURING_LIFE == Yes)
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = OBSERVATION_PERIOD
cdmFieldName = OBSERVATION_PERIOD_START_DATE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'PLAUSIBLE_DURING_LIFE' level,
    'get number of events that occur after death event (PLAUSIBLE_DURING_LIFE == Yes)' check,
    'OBSERVATION_PERIOD' cdmTableName,
'OBSERVATION_PERIOD_START_DATE' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'OBSERVATION_PERIOD.OBSERVATION_PERIOD_START_DATE' as violating_field, 
			cdmtable.*
    	from CY_IMOSPHERE_CDM_531.observation_period cdmtable
    	join CY_IMOSPHERE_CDM_531.death de on cdmtable.person_id = de.person_id
    	where IF(SAFE_CAST(cdmtable.observation_period_start_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.observation_period_start_date  AS STRING)),SAFE_CAST(cdmtable.observation_period_start_date  AS DATE)) > DATE_ADD(IF(SAFE_CAST(IF(SAFE_CAST(de.death_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(de.death_date  AS STRING)),SAFE_CAST(de.death_date  AS DATE))  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(IF(SAFE_CAST(de.death_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(de.death_date  AS STRING)),SAFE_CAST(de.death_date  AS DATE))  AS STRING)),SAFE_CAST(IF(SAFE_CAST(de.death_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(de.death_date  AS STRING)),SAFE_CAST(de.death_date  AS DATE))  AS DATE)), INTERVAL 60 DAY)
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.observation_period cdmtable
	where person_id in
		(select 
			person_id 
		from CY_IMOSPHERE_CDM_531.death)
) denominator
;

/*********
PLAUSIBLE_DURING_LIFE
get number of events that occur after death event (PLAUSIBLE_DURING_LIFE == Yes)
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = OBSERVATION_PERIOD
cdmFieldName = OBSERVATION_PERIOD_END_DATE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'PLAUSIBLE_DURING_LIFE' level,
    'get number of events that occur after death event (PLAUSIBLE_DURING_LIFE == Yes)' check,
    'OBSERVATION_PERIOD' cdmTableName,
'OBSERVATION_PERIOD_END_DATE' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'OBSERVATION_PERIOD.OBSERVATION_PERIOD_END_DATE' as violating_field, 
			cdmtable.*
    	from CY_IMOSPHERE_CDM_531.observation_period cdmtable
    	join CY_IMOSPHERE_CDM_531.death de on cdmtable.person_id = de.person_id
    	where IF(SAFE_CAST(cdmtable.observation_period_end_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.observation_period_end_date  AS STRING)),SAFE_CAST(cdmtable.observation_period_end_date  AS DATE)) > DATE_ADD(IF(SAFE_CAST(IF(SAFE_CAST(de.death_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(de.death_date  AS STRING)),SAFE_CAST(de.death_date  AS DATE))  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(IF(SAFE_CAST(de.death_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(de.death_date  AS STRING)),SAFE_CAST(de.death_date  AS DATE))  AS STRING)),SAFE_CAST(IF(SAFE_CAST(de.death_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(de.death_date  AS STRING)),SAFE_CAST(de.death_date  AS DATE))  AS DATE)), INTERVAL 60 DAY)
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.observation_period cdmtable
	where person_id in
		(select 
			person_id 
		from CY_IMOSPHERE_CDM_531.death)
) denominator
;

/*********
PLAUSIBLE_DURING_LIFE
get number of events that occur after death event (PLAUSIBLE_DURING_LIFE == Yes)
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_OCCURRENCE
cdmFieldName = VISIT_START_DATE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'PLAUSIBLE_DURING_LIFE' level,
    'get number of events that occur after death event (PLAUSIBLE_DURING_LIFE == Yes)' check,
    'VISIT_OCCURRENCE' cdmTableName,
'VISIT_START_DATE' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'VISIT_OCCURRENCE.VISIT_START_DATE' as violating_field, 
			cdmtable.*
    	from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
    	join CY_IMOSPHERE_CDM_531.death de on cdmtable.person_id = de.person_id
    	where IF(SAFE_CAST(cdmtable.visit_start_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.visit_start_date  AS STRING)),SAFE_CAST(cdmtable.visit_start_date  AS DATE)) > DATE_ADD(IF(SAFE_CAST(IF(SAFE_CAST(de.death_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(de.death_date  AS STRING)),SAFE_CAST(de.death_date  AS DATE))  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(IF(SAFE_CAST(de.death_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(de.death_date  AS STRING)),SAFE_CAST(de.death_date  AS DATE))  AS STRING)),SAFE_CAST(IF(SAFE_CAST(de.death_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(de.death_date  AS STRING)),SAFE_CAST(de.death_date  AS DATE))  AS DATE)), INTERVAL 60 DAY)
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
	where person_id in
		(select 
			person_id 
		from CY_IMOSPHERE_CDM_531.death)
) denominator
;

/*********
PLAUSIBLE_DURING_LIFE
get number of events that occur after death event (PLAUSIBLE_DURING_LIFE == Yes)
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_OCCURRENCE
cdmFieldName = VISIT_START_DATETIME
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'PLAUSIBLE_DURING_LIFE' level,
    'get number of events that occur after death event (PLAUSIBLE_DURING_LIFE == Yes)' check,
    'VISIT_OCCURRENCE' cdmTableName,
'VISIT_START_DATETIME' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'VISIT_OCCURRENCE.VISIT_START_DATETIME' as violating_field, 
			cdmtable.*
    	from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
    	join CY_IMOSPHERE_CDM_531.death de on cdmtable.person_id = de.person_id
    	where IF(SAFE_CAST(cdmtable.visit_start_datetime  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.visit_start_datetime  AS STRING)),SAFE_CAST(cdmtable.visit_start_datetime  AS DATE)) > DATE_ADD(IF(SAFE_CAST(IF(SAFE_CAST(de.death_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(de.death_date  AS STRING)),SAFE_CAST(de.death_date  AS DATE))  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(IF(SAFE_CAST(de.death_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(de.death_date  AS STRING)),SAFE_CAST(de.death_date  AS DATE))  AS STRING)),SAFE_CAST(IF(SAFE_CAST(de.death_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(de.death_date  AS STRING)),SAFE_CAST(de.death_date  AS DATE))  AS DATE)), INTERVAL 60 DAY)
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
	where person_id in
		(select 
			person_id 
		from CY_IMOSPHERE_CDM_531.death)
) denominator
;

/*********
PLAUSIBLE_DURING_LIFE
get number of events that occur after death event (PLAUSIBLE_DURING_LIFE == Yes)
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_OCCURRENCE
cdmFieldName = VISIT_END_DATE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'PLAUSIBLE_DURING_LIFE' level,
    'get number of events that occur after death event (PLAUSIBLE_DURING_LIFE == Yes)' check,
    'VISIT_OCCURRENCE' cdmTableName,
'VISIT_END_DATE' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'VISIT_OCCURRENCE.VISIT_END_DATE' as violating_field, 
			cdmtable.*
    	from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
    	join CY_IMOSPHERE_CDM_531.death de on cdmtable.person_id = de.person_id
    	where IF(SAFE_CAST(cdmtable.visit_end_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.visit_end_date  AS STRING)),SAFE_CAST(cdmtable.visit_end_date  AS DATE)) > DATE_ADD(IF(SAFE_CAST(IF(SAFE_CAST(de.death_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(de.death_date  AS STRING)),SAFE_CAST(de.death_date  AS DATE))  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(IF(SAFE_CAST(de.death_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(de.death_date  AS STRING)),SAFE_CAST(de.death_date  AS DATE))  AS STRING)),SAFE_CAST(IF(SAFE_CAST(de.death_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(de.death_date  AS STRING)),SAFE_CAST(de.death_date  AS DATE))  AS DATE)), INTERVAL 60 DAY)
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
	where person_id in
		(select 
			person_id 
		from CY_IMOSPHERE_CDM_531.death)
) denominator
;

/*********
PLAUSIBLE_DURING_LIFE
get number of events that occur after death event (PLAUSIBLE_DURING_LIFE == Yes)
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_OCCURRENCE
cdmFieldName = VISIT_END_DATETIME
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'PLAUSIBLE_DURING_LIFE' level,
    'get number of events that occur after death event (PLAUSIBLE_DURING_LIFE == Yes)' check,
    'VISIT_OCCURRENCE' cdmTableName,
'VISIT_END_DATETIME' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'VISIT_OCCURRENCE.VISIT_END_DATETIME' as violating_field, 
			cdmtable.*
    	from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
    	join CY_IMOSPHERE_CDM_531.death de on cdmtable.person_id = de.person_id
    	where IF(SAFE_CAST(cdmtable.visit_end_datetime  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.visit_end_datetime  AS STRING)),SAFE_CAST(cdmtable.visit_end_datetime  AS DATE)) > DATE_ADD(IF(SAFE_CAST(IF(SAFE_CAST(de.death_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(de.death_date  AS STRING)),SAFE_CAST(de.death_date  AS DATE))  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(IF(SAFE_CAST(de.death_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(de.death_date  AS STRING)),SAFE_CAST(de.death_date  AS DATE))  AS STRING)),SAFE_CAST(IF(SAFE_CAST(de.death_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(de.death_date  AS STRING)),SAFE_CAST(de.death_date  AS DATE))  AS DATE)), INTERVAL 60 DAY)
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
	where person_id in
		(select 
			person_id 
		from CY_IMOSPHERE_CDM_531.death)
) denominator
;

/*********
PLAUSIBLE_DURING_LIFE
get number of events that occur after death event (PLAUSIBLE_DURING_LIFE == Yes)
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_START_DATE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'PLAUSIBLE_DURING_LIFE' level,
    'get number of events that occur after death event (PLAUSIBLE_DURING_LIFE == Yes)' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_START_DATE' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'CONDITION_OCCURRENCE.CONDITION_START_DATE' as violating_field, 
			cdmtable.*
    	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
    	join CY_IMOSPHERE_CDM_531.death de on cdmtable.person_id = de.person_id
    	where IF(SAFE_CAST(cdmtable.condition_start_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.condition_start_date  AS STRING)),SAFE_CAST(cdmtable.condition_start_date  AS DATE)) > DATE_ADD(IF(SAFE_CAST(IF(SAFE_CAST(de.death_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(de.death_date  AS STRING)),SAFE_CAST(de.death_date  AS DATE))  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(IF(SAFE_CAST(de.death_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(de.death_date  AS STRING)),SAFE_CAST(de.death_date  AS DATE))  AS STRING)),SAFE_CAST(IF(SAFE_CAST(de.death_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(de.death_date  AS STRING)),SAFE_CAST(de.death_date  AS DATE))  AS DATE)), INTERVAL 60 DAY)
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where person_id in
		(select 
			person_id 
		from CY_IMOSPHERE_CDM_531.death)
) denominator
;

/*********
PLAUSIBLE_DURING_LIFE
get number of events that occur after death event (PLAUSIBLE_DURING_LIFE == Yes)
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_START_DATETIME
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'PLAUSIBLE_DURING_LIFE' level,
    'get number of events that occur after death event (PLAUSIBLE_DURING_LIFE == Yes)' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_START_DATETIME' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'CONDITION_OCCURRENCE.CONDITION_START_DATETIME' as violating_field, 
			cdmtable.*
    	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
    	join CY_IMOSPHERE_CDM_531.death de on cdmtable.person_id = de.person_id
    	where IF(SAFE_CAST(cdmtable.condition_start_datetime  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.condition_start_datetime  AS STRING)),SAFE_CAST(cdmtable.condition_start_datetime  AS DATE)) > DATE_ADD(IF(SAFE_CAST(IF(SAFE_CAST(de.death_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(de.death_date  AS STRING)),SAFE_CAST(de.death_date  AS DATE))  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(IF(SAFE_CAST(de.death_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(de.death_date  AS STRING)),SAFE_CAST(de.death_date  AS DATE))  AS STRING)),SAFE_CAST(IF(SAFE_CAST(de.death_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(de.death_date  AS STRING)),SAFE_CAST(de.death_date  AS DATE))  AS DATE)), INTERVAL 60 DAY)
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where person_id in
		(select 
			person_id 
		from CY_IMOSPHERE_CDM_531.death)
) denominator
;

/*********
PLAUSIBLE_DURING_LIFE
get number of events that occur after death event (PLAUSIBLE_DURING_LIFE == Yes)
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_END_DATE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'PLAUSIBLE_DURING_LIFE' level,
    'get number of events that occur after death event (PLAUSIBLE_DURING_LIFE == Yes)' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_END_DATE' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'CONDITION_OCCURRENCE.CONDITION_END_DATE' as violating_field, 
			cdmtable.*
    	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
    	join CY_IMOSPHERE_CDM_531.death de on cdmtable.person_id = de.person_id
    	where IF(SAFE_CAST(cdmtable.condition_end_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.condition_end_date  AS STRING)),SAFE_CAST(cdmtable.condition_end_date  AS DATE)) > DATE_ADD(IF(SAFE_CAST(IF(SAFE_CAST(de.death_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(de.death_date  AS STRING)),SAFE_CAST(de.death_date  AS DATE))  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(IF(SAFE_CAST(de.death_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(de.death_date  AS STRING)),SAFE_CAST(de.death_date  AS DATE))  AS STRING)),SAFE_CAST(IF(SAFE_CAST(de.death_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(de.death_date  AS STRING)),SAFE_CAST(de.death_date  AS DATE))  AS DATE)), INTERVAL 60 DAY)
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where person_id in
		(select 
			person_id 
		from CY_IMOSPHERE_CDM_531.death)
) denominator
;

/*********
PLAUSIBLE_DURING_LIFE
get number of events that occur after death event (PLAUSIBLE_DURING_LIFE == Yes)
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_END_DATETIME
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'PLAUSIBLE_DURING_LIFE' level,
    'get number of events that occur after death event (PLAUSIBLE_DURING_LIFE == Yes)' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_END_DATETIME' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'CONDITION_OCCURRENCE.CONDITION_END_DATETIME' as violating_field, 
			cdmtable.*
    	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
    	join CY_IMOSPHERE_CDM_531.death de on cdmtable.person_id = de.person_id
    	where IF(SAFE_CAST(cdmtable.condition_end_datetime  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.condition_end_datetime  AS STRING)),SAFE_CAST(cdmtable.condition_end_datetime  AS DATE)) > DATE_ADD(IF(SAFE_CAST(IF(SAFE_CAST(de.death_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(de.death_date  AS STRING)),SAFE_CAST(de.death_date  AS DATE))  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(IF(SAFE_CAST(de.death_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(de.death_date  AS STRING)),SAFE_CAST(de.death_date  AS DATE))  AS STRING)),SAFE_CAST(IF(SAFE_CAST(de.death_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(de.death_date  AS STRING)),SAFE_CAST(de.death_date  AS DATE))  AS DATE)), INTERVAL 60 DAY)
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where person_id in
		(select 
			person_id 
		from CY_IMOSPHERE_CDM_531.death)
) denominator
;

/*********
PLAUSIBLE_DURING_LIFE
get number of events that occur after death event (PLAUSIBLE_DURING_LIFE == Yes)
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DRUG_EXPOSURE
cdmFieldName = DRUG_EXPOSURE_START_DATE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'PLAUSIBLE_DURING_LIFE' level,
    'get number of events that occur after death event (PLAUSIBLE_DURING_LIFE == Yes)' check,
    'DRUG_EXPOSURE' cdmTableName,
'DRUG_EXPOSURE_START_DATE' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'DRUG_EXPOSURE.DRUG_EXPOSURE_START_DATE' as violating_field, 
			cdmtable.*
    	from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
    	join CY_IMOSPHERE_CDM_531.death de on cdmtable.person_id = de.person_id
    	where IF(SAFE_CAST(cdmtable.drug_exposure_start_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.drug_exposure_start_date  AS STRING)),SAFE_CAST(cdmtable.drug_exposure_start_date  AS DATE)) > DATE_ADD(IF(SAFE_CAST(IF(SAFE_CAST(de.death_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(de.death_date  AS STRING)),SAFE_CAST(de.death_date  AS DATE))  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(IF(SAFE_CAST(de.death_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(de.death_date  AS STRING)),SAFE_CAST(de.death_date  AS DATE))  AS STRING)),SAFE_CAST(IF(SAFE_CAST(de.death_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(de.death_date  AS STRING)),SAFE_CAST(de.death_date  AS DATE))  AS DATE)), INTERVAL 60 DAY)
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
	where person_id in
		(select 
			person_id 
		from CY_IMOSPHERE_CDM_531.death)
) denominator
;

/*********
PLAUSIBLE_DURING_LIFE
get number of events that occur after death event (PLAUSIBLE_DURING_LIFE == Yes)
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DRUG_EXPOSURE
cdmFieldName = DRUG_EXPOSURE_START_DATETIME
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'PLAUSIBLE_DURING_LIFE' level,
    'get number of events that occur after death event (PLAUSIBLE_DURING_LIFE == Yes)' check,
    'DRUG_EXPOSURE' cdmTableName,
'DRUG_EXPOSURE_START_DATETIME' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'DRUG_EXPOSURE.DRUG_EXPOSURE_START_DATETIME' as violating_field, 
			cdmtable.*
    	from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
    	join CY_IMOSPHERE_CDM_531.death de on cdmtable.person_id = de.person_id
    	where IF(SAFE_CAST(cdmtable.drug_exposure_start_datetime  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.drug_exposure_start_datetime  AS STRING)),SAFE_CAST(cdmtable.drug_exposure_start_datetime  AS DATE)) > DATE_ADD(IF(SAFE_CAST(IF(SAFE_CAST(de.death_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(de.death_date  AS STRING)),SAFE_CAST(de.death_date  AS DATE))  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(IF(SAFE_CAST(de.death_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(de.death_date  AS STRING)),SAFE_CAST(de.death_date  AS DATE))  AS STRING)),SAFE_CAST(IF(SAFE_CAST(de.death_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(de.death_date  AS STRING)),SAFE_CAST(de.death_date  AS DATE))  AS DATE)), INTERVAL 60 DAY)
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
	where person_id in
		(select 
			person_id 
		from CY_IMOSPHERE_CDM_531.death)
) denominator
;

/*********
PLAUSIBLE_DURING_LIFE
get number of events that occur after death event (PLAUSIBLE_DURING_LIFE == Yes)
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DRUG_EXPOSURE
cdmFieldName = DRUG_EXPOSURE_END_DATE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'PLAUSIBLE_DURING_LIFE' level,
    'get number of events that occur after death event (PLAUSIBLE_DURING_LIFE == Yes)' check,
    'DRUG_EXPOSURE' cdmTableName,
'DRUG_EXPOSURE_END_DATE' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'DRUG_EXPOSURE.DRUG_EXPOSURE_END_DATE' as violating_field, 
			cdmtable.*
    	from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
    	join CY_IMOSPHERE_CDM_531.death de on cdmtable.person_id = de.person_id
    	where IF(SAFE_CAST(cdmtable.drug_exposure_end_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.drug_exposure_end_date  AS STRING)),SAFE_CAST(cdmtable.drug_exposure_end_date  AS DATE)) > DATE_ADD(IF(SAFE_CAST(IF(SAFE_CAST(de.death_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(de.death_date  AS STRING)),SAFE_CAST(de.death_date  AS DATE))  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(IF(SAFE_CAST(de.death_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(de.death_date  AS STRING)),SAFE_CAST(de.death_date  AS DATE))  AS STRING)),SAFE_CAST(IF(SAFE_CAST(de.death_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(de.death_date  AS STRING)),SAFE_CAST(de.death_date  AS DATE))  AS DATE)), INTERVAL 60 DAY)
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
	where person_id in
		(select 
			person_id 
		from CY_IMOSPHERE_CDM_531.death)
) denominator
;

/*********
PLAUSIBLE_DURING_LIFE
get number of events that occur after death event (PLAUSIBLE_DURING_LIFE == Yes)
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DRUG_EXPOSURE
cdmFieldName = DRUG_EXPOSURE_END_DATETIME
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'PLAUSIBLE_DURING_LIFE' level,
    'get number of events that occur after death event (PLAUSIBLE_DURING_LIFE == Yes)' check,
    'DRUG_EXPOSURE' cdmTableName,
'DRUG_EXPOSURE_END_DATETIME' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'DRUG_EXPOSURE.DRUG_EXPOSURE_END_DATETIME' as violating_field, 
			cdmtable.*
    	from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
    	join CY_IMOSPHERE_CDM_531.death de on cdmtable.person_id = de.person_id
    	where IF(SAFE_CAST(cdmtable.drug_exposure_end_datetime  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.drug_exposure_end_datetime  AS STRING)),SAFE_CAST(cdmtable.drug_exposure_end_datetime  AS DATE)) > DATE_ADD(IF(SAFE_CAST(IF(SAFE_CAST(de.death_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(de.death_date  AS STRING)),SAFE_CAST(de.death_date  AS DATE))  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(IF(SAFE_CAST(de.death_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(de.death_date  AS STRING)),SAFE_CAST(de.death_date  AS DATE))  AS STRING)),SAFE_CAST(IF(SAFE_CAST(de.death_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(de.death_date  AS STRING)),SAFE_CAST(de.death_date  AS DATE))  AS DATE)), INTERVAL 60 DAY)
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
	where person_id in
		(select 
			person_id 
		from CY_IMOSPHERE_CDM_531.death)
) denominator
;

/*********
PLAUSIBLE_DURING_LIFE
get number of events that occur after death event (PLAUSIBLE_DURING_LIFE == Yes)
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DRUG_EXPOSURE
cdmFieldName = VERBATIM_END_DATE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'PLAUSIBLE_DURING_LIFE' level,
    'get number of events that occur after death event (PLAUSIBLE_DURING_LIFE == Yes)' check,
    'DRUG_EXPOSURE' cdmTableName,
'VERBATIM_END_DATE' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'DRUG_EXPOSURE.VERBATIM_END_DATE' as violating_field, 
			cdmtable.*
    	from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
    	join CY_IMOSPHERE_CDM_531.death de on cdmtable.person_id = de.person_id
    	where IF(SAFE_CAST(cdmtable.verbatim_end_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.verbatim_end_date  AS STRING)),SAFE_CAST(cdmtable.verbatim_end_date  AS DATE)) > DATE_ADD(IF(SAFE_CAST(IF(SAFE_CAST(de.death_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(de.death_date  AS STRING)),SAFE_CAST(de.death_date  AS DATE))  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(IF(SAFE_CAST(de.death_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(de.death_date  AS STRING)),SAFE_CAST(de.death_date  AS DATE))  AS STRING)),SAFE_CAST(IF(SAFE_CAST(de.death_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(de.death_date  AS STRING)),SAFE_CAST(de.death_date  AS DATE))  AS DATE)), INTERVAL 60 DAY)
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
	where person_id in
		(select 
			person_id 
		from CY_IMOSPHERE_CDM_531.death)
) denominator
;

/*********
PLAUSIBLE_DURING_LIFE
get number of events that occur after death event (PLAUSIBLE_DURING_LIFE == Yes)
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_DATE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'PLAUSIBLE_DURING_LIFE' level,
    'get number of events that occur after death event (PLAUSIBLE_DURING_LIFE == Yes)' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_DATE' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'PROCEDURE_OCCURRENCE.PROCEDURE_DATE' as violating_field, 
			cdmtable.*
    	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
    	join CY_IMOSPHERE_CDM_531.death de on cdmtable.person_id = de.person_id
    	where IF(SAFE_CAST(cdmtable.procedure_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.procedure_date  AS STRING)),SAFE_CAST(cdmtable.procedure_date  AS DATE)) > DATE_ADD(IF(SAFE_CAST(IF(SAFE_CAST(de.death_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(de.death_date  AS STRING)),SAFE_CAST(de.death_date  AS DATE))  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(IF(SAFE_CAST(de.death_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(de.death_date  AS STRING)),SAFE_CAST(de.death_date  AS DATE))  AS STRING)),SAFE_CAST(IF(SAFE_CAST(de.death_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(de.death_date  AS STRING)),SAFE_CAST(de.death_date  AS DATE))  AS DATE)), INTERVAL 60 DAY)
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
	where person_id in
		(select 
			person_id 
		from CY_IMOSPHERE_CDM_531.death)
) denominator
;

/*********
PLAUSIBLE_DURING_LIFE
get number of events that occur after death event (PLAUSIBLE_DURING_LIFE == Yes)
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_DATETIME
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'PLAUSIBLE_DURING_LIFE' level,
    'get number of events that occur after death event (PLAUSIBLE_DURING_LIFE == Yes)' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_DATETIME' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'PROCEDURE_OCCURRENCE.PROCEDURE_DATETIME' as violating_field, 
			cdmtable.*
    	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
    	join CY_IMOSPHERE_CDM_531.death de on cdmtable.person_id = de.person_id
    	where IF(SAFE_CAST(cdmtable.procedure_datetime  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.procedure_datetime  AS STRING)),SAFE_CAST(cdmtable.procedure_datetime  AS DATE)) > DATE_ADD(IF(SAFE_CAST(IF(SAFE_CAST(de.death_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(de.death_date  AS STRING)),SAFE_CAST(de.death_date  AS DATE))  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(IF(SAFE_CAST(de.death_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(de.death_date  AS STRING)),SAFE_CAST(de.death_date  AS DATE))  AS STRING)),SAFE_CAST(IF(SAFE_CAST(de.death_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(de.death_date  AS STRING)),SAFE_CAST(de.death_date  AS DATE))  AS DATE)), INTERVAL 60 DAY)
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
	where person_id in
		(select 
			person_id 
		from CY_IMOSPHERE_CDM_531.death)
) denominator
;

/*********
PLAUSIBLE_DURING_LIFE
get number of events that occur after death event (PLAUSIBLE_DURING_LIFE == Yes)
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DEVICE_EXPOSURE
cdmFieldName = DEVICE_EXPOSURE_START_DATE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'PLAUSIBLE_DURING_LIFE' level,
    'get number of events that occur after death event (PLAUSIBLE_DURING_LIFE == Yes)' check,
    'DEVICE_EXPOSURE' cdmTableName,
'DEVICE_EXPOSURE_START_DATE' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'DEVICE_EXPOSURE.DEVICE_EXPOSURE_START_DATE' as violating_field, 
			cdmtable.*
    	from CY_IMOSPHERE_CDM_531.device_exposure cdmtable
    	join CY_IMOSPHERE_CDM_531.death de on cdmtable.person_id = de.person_id
    	where IF(SAFE_CAST(cdmtable.device_exposure_start_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.device_exposure_start_date  AS STRING)),SAFE_CAST(cdmtable.device_exposure_start_date  AS DATE)) > DATE_ADD(IF(SAFE_CAST(IF(SAFE_CAST(de.death_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(de.death_date  AS STRING)),SAFE_CAST(de.death_date  AS DATE))  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(IF(SAFE_CAST(de.death_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(de.death_date  AS STRING)),SAFE_CAST(de.death_date  AS DATE))  AS STRING)),SAFE_CAST(IF(SAFE_CAST(de.death_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(de.death_date  AS STRING)),SAFE_CAST(de.death_date  AS DATE))  AS DATE)), INTERVAL 60 DAY)
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.device_exposure cdmtable
	where person_id in
		(select 
			person_id 
		from CY_IMOSPHERE_CDM_531.death)
) denominator
;

/*********
PLAUSIBLE_DURING_LIFE
get number of events that occur after death event (PLAUSIBLE_DURING_LIFE == Yes)
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DEVICE_EXPOSURE
cdmFieldName = DEVICE_EXPOSURE_START_DATETIME
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'PLAUSIBLE_DURING_LIFE' level,
    'get number of events that occur after death event (PLAUSIBLE_DURING_LIFE == Yes)' check,
    'DEVICE_EXPOSURE' cdmTableName,
'DEVICE_EXPOSURE_START_DATETIME' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'DEVICE_EXPOSURE.DEVICE_EXPOSURE_START_DATETIME' as violating_field, 
			cdmtable.*
    	from CY_IMOSPHERE_CDM_531.device_exposure cdmtable
    	join CY_IMOSPHERE_CDM_531.death de on cdmtable.person_id = de.person_id
    	where IF(SAFE_CAST(cdmtable.device_exposure_start_datetime  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.device_exposure_start_datetime  AS STRING)),SAFE_CAST(cdmtable.device_exposure_start_datetime  AS DATE)) > DATE_ADD(IF(SAFE_CAST(IF(SAFE_CAST(de.death_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(de.death_date  AS STRING)),SAFE_CAST(de.death_date  AS DATE))  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(IF(SAFE_CAST(de.death_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(de.death_date  AS STRING)),SAFE_CAST(de.death_date  AS DATE))  AS STRING)),SAFE_CAST(IF(SAFE_CAST(de.death_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(de.death_date  AS STRING)),SAFE_CAST(de.death_date  AS DATE))  AS DATE)), INTERVAL 60 DAY)
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.device_exposure cdmtable
	where person_id in
		(select 
			person_id 
		from CY_IMOSPHERE_CDM_531.death)
) denominator
;

/*********
PLAUSIBLE_DURING_LIFE
get number of events that occur after death event (PLAUSIBLE_DURING_LIFE == Yes)
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DEVICE_EXPOSURE
cdmFieldName = DEVICE_EXPOSURE_END_DATE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'PLAUSIBLE_DURING_LIFE' level,
    'get number of events that occur after death event (PLAUSIBLE_DURING_LIFE == Yes)' check,
    'DEVICE_EXPOSURE' cdmTableName,
'DEVICE_EXPOSURE_END_DATE' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'DEVICE_EXPOSURE.DEVICE_EXPOSURE_END_DATE' as violating_field, 
			cdmtable.*
    	from CY_IMOSPHERE_CDM_531.device_exposure cdmtable
    	join CY_IMOSPHERE_CDM_531.death de on cdmtable.person_id = de.person_id
    	where IF(SAFE_CAST(cdmtable.device_exposure_end_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.device_exposure_end_date  AS STRING)),SAFE_CAST(cdmtable.device_exposure_end_date  AS DATE)) > DATE_ADD(IF(SAFE_CAST(IF(SAFE_CAST(de.death_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(de.death_date  AS STRING)),SAFE_CAST(de.death_date  AS DATE))  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(IF(SAFE_CAST(de.death_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(de.death_date  AS STRING)),SAFE_CAST(de.death_date  AS DATE))  AS STRING)),SAFE_CAST(IF(SAFE_CAST(de.death_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(de.death_date  AS STRING)),SAFE_CAST(de.death_date  AS DATE))  AS DATE)), INTERVAL 60 DAY)
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.device_exposure cdmtable
	where person_id in
		(select 
			person_id 
		from CY_IMOSPHERE_CDM_531.death)
) denominator
;

/*********
PLAUSIBLE_DURING_LIFE
get number of events that occur after death event (PLAUSIBLE_DURING_LIFE == Yes)
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DEVICE_EXPOSURE
cdmFieldName = DEVICE_EXPOSURE_END_DATETIME
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'PLAUSIBLE_DURING_LIFE' level,
    'get number of events that occur after death event (PLAUSIBLE_DURING_LIFE == Yes)' check,
    'DEVICE_EXPOSURE' cdmTableName,
'DEVICE_EXPOSURE_END_DATETIME' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'DEVICE_EXPOSURE.DEVICE_EXPOSURE_END_DATETIME' as violating_field, 
			cdmtable.*
    	from CY_IMOSPHERE_CDM_531.device_exposure cdmtable
    	join CY_IMOSPHERE_CDM_531.death de on cdmtable.person_id = de.person_id
    	where IF(SAFE_CAST(cdmtable.device_exposure_end_datetime  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.device_exposure_end_datetime  AS STRING)),SAFE_CAST(cdmtable.device_exposure_end_datetime  AS DATE)) > DATE_ADD(IF(SAFE_CAST(IF(SAFE_CAST(de.death_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(de.death_date  AS STRING)),SAFE_CAST(de.death_date  AS DATE))  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(IF(SAFE_CAST(de.death_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(de.death_date  AS STRING)),SAFE_CAST(de.death_date  AS DATE))  AS STRING)),SAFE_CAST(IF(SAFE_CAST(de.death_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(de.death_date  AS STRING)),SAFE_CAST(de.death_date  AS DATE))  AS DATE)), INTERVAL 60 DAY)
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.device_exposure cdmtable
	where person_id in
		(select 
			person_id 
		from CY_IMOSPHERE_CDM_531.death)
) denominator
;

/*********
PLAUSIBLE_DURING_LIFE
get number of events that occur after death event (PLAUSIBLE_DURING_LIFE == Yes)
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_DETAIL
cdmFieldName = VISIT_DETAIL_START_DATE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'PLAUSIBLE_DURING_LIFE' level,
    'get number of events that occur after death event (PLAUSIBLE_DURING_LIFE == Yes)' check,
    'VISIT_DETAIL' cdmTableName,
'VISIT_DETAIL_START_DATE' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'VISIT_DETAIL.VISIT_DETAIL_START_DATE' as violating_field, 
			cdmtable.*
    	from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
    	join CY_IMOSPHERE_CDM_531.death de on cdmtable.person_id = de.person_id
    	where IF(SAFE_CAST(cdmtable.visit_detail_start_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.visit_detail_start_date  AS STRING)),SAFE_CAST(cdmtable.visit_detail_start_date  AS DATE)) > DATE_ADD(IF(SAFE_CAST(IF(SAFE_CAST(de.death_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(de.death_date  AS STRING)),SAFE_CAST(de.death_date  AS DATE))  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(IF(SAFE_CAST(de.death_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(de.death_date  AS STRING)),SAFE_CAST(de.death_date  AS DATE))  AS STRING)),SAFE_CAST(IF(SAFE_CAST(de.death_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(de.death_date  AS STRING)),SAFE_CAST(de.death_date  AS DATE))  AS DATE)), INTERVAL 60 DAY)
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
	where person_id in
		(select 
			person_id 
		from CY_IMOSPHERE_CDM_531.death)
) denominator
;

/*********
PLAUSIBLE_DURING_LIFE
get number of events that occur after death event (PLAUSIBLE_DURING_LIFE == Yes)
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_DETAIL
cdmFieldName = VISIT_DETAIL_START_DATETIME
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'PLAUSIBLE_DURING_LIFE' level,
    'get number of events that occur after death event (PLAUSIBLE_DURING_LIFE == Yes)' check,
    'VISIT_DETAIL' cdmTableName,
'VISIT_DETAIL_START_DATETIME' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'VISIT_DETAIL.VISIT_DETAIL_START_DATETIME' as violating_field, 
			cdmtable.*
    	from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
    	join CY_IMOSPHERE_CDM_531.death de on cdmtable.person_id = de.person_id
    	where IF(SAFE_CAST(cdmtable.visit_detail_start_datetime  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.visit_detail_start_datetime  AS STRING)),SAFE_CAST(cdmtable.visit_detail_start_datetime  AS DATE)) > DATE_ADD(IF(SAFE_CAST(IF(SAFE_CAST(de.death_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(de.death_date  AS STRING)),SAFE_CAST(de.death_date  AS DATE))  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(IF(SAFE_CAST(de.death_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(de.death_date  AS STRING)),SAFE_CAST(de.death_date  AS DATE))  AS STRING)),SAFE_CAST(IF(SAFE_CAST(de.death_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(de.death_date  AS STRING)),SAFE_CAST(de.death_date  AS DATE))  AS DATE)), INTERVAL 60 DAY)
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
	where person_id in
		(select 
			person_id 
		from CY_IMOSPHERE_CDM_531.death)
) denominator
;

/*********
PLAUSIBLE_DURING_LIFE
get number of events that occur after death event (PLAUSIBLE_DURING_LIFE == Yes)
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_DETAIL
cdmFieldName = VISIT_DETAIL_END_DATE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'PLAUSIBLE_DURING_LIFE' level,
    'get number of events that occur after death event (PLAUSIBLE_DURING_LIFE == Yes)' check,
    'VISIT_DETAIL' cdmTableName,
'VISIT_DETAIL_END_DATE' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'VISIT_DETAIL.VISIT_DETAIL_END_DATE' as violating_field, 
			cdmtable.*
    	from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
    	join CY_IMOSPHERE_CDM_531.death de on cdmtable.person_id = de.person_id
    	where IF(SAFE_CAST(cdmtable.visit_detail_end_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.visit_detail_end_date  AS STRING)),SAFE_CAST(cdmtable.visit_detail_end_date  AS DATE)) > DATE_ADD(IF(SAFE_CAST(IF(SAFE_CAST(de.death_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(de.death_date  AS STRING)),SAFE_CAST(de.death_date  AS DATE))  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(IF(SAFE_CAST(de.death_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(de.death_date  AS STRING)),SAFE_CAST(de.death_date  AS DATE))  AS STRING)),SAFE_CAST(IF(SAFE_CAST(de.death_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(de.death_date  AS STRING)),SAFE_CAST(de.death_date  AS DATE))  AS DATE)), INTERVAL 60 DAY)
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
	where person_id in
		(select 
			person_id 
		from CY_IMOSPHERE_CDM_531.death)
) denominator
;

/*********
PLAUSIBLE_DURING_LIFE
get number of events that occur after death event (PLAUSIBLE_DURING_LIFE == Yes)
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_DETAIL
cdmFieldName = VISIT_DETAIL_END_DATETIME
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'PLAUSIBLE_DURING_LIFE' level,
    'get number of events that occur after death event (PLAUSIBLE_DURING_LIFE == Yes)' check,
    'VISIT_DETAIL' cdmTableName,
'VISIT_DETAIL_END_DATETIME' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'VISIT_DETAIL.VISIT_DETAIL_END_DATETIME' as violating_field, 
			cdmtable.*
    	from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
    	join CY_IMOSPHERE_CDM_531.death de on cdmtable.person_id = de.person_id
    	where IF(SAFE_CAST(cdmtable.visit_detail_end_datetime  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.visit_detail_end_datetime  AS STRING)),SAFE_CAST(cdmtable.visit_detail_end_datetime  AS DATE)) > DATE_ADD(IF(SAFE_CAST(IF(SAFE_CAST(de.death_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(de.death_date  AS STRING)),SAFE_CAST(de.death_date  AS DATE))  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(IF(SAFE_CAST(de.death_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(de.death_date  AS STRING)),SAFE_CAST(de.death_date  AS DATE))  AS STRING)),SAFE_CAST(IF(SAFE_CAST(de.death_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(de.death_date  AS STRING)),SAFE_CAST(de.death_date  AS DATE))  AS DATE)), INTERVAL 60 DAY)
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
	where person_id in
		(select 
			person_id 
		from CY_IMOSPHERE_CDM_531.death)
) denominator
;

/*********
PLAUSIBLE_DURING_LIFE
get number of events that occur after death event (PLAUSIBLE_DURING_LIFE == Yes)
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DRUG_ERA
cdmFieldName = DRUG_ERA_START_DATE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'PLAUSIBLE_DURING_LIFE' level,
    'get number of events that occur after death event (PLAUSIBLE_DURING_LIFE == Yes)' check,
    'DRUG_ERA' cdmTableName,
'DRUG_ERA_START_DATE' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'DRUG_ERA.DRUG_ERA_START_DATE' as violating_field, 
			cdmtable.*
    	from CY_IMOSPHERE_CDM_531.drug_era cdmtable
    	join CY_IMOSPHERE_CDM_531.death de on cdmtable.person_id = de.person_id
    	where IF(SAFE_CAST(cdmtable.drug_era_start_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.drug_era_start_date  AS STRING)),SAFE_CAST(cdmtable.drug_era_start_date  AS DATE)) > DATE_ADD(IF(SAFE_CAST(IF(SAFE_CAST(de.death_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(de.death_date  AS STRING)),SAFE_CAST(de.death_date  AS DATE))  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(IF(SAFE_CAST(de.death_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(de.death_date  AS STRING)),SAFE_CAST(de.death_date  AS DATE))  AS STRING)),SAFE_CAST(IF(SAFE_CAST(de.death_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(de.death_date  AS STRING)),SAFE_CAST(de.death_date  AS DATE))  AS DATE)), INTERVAL 60 DAY)
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.drug_era cdmtable
	where person_id in
		(select 
			person_id 
		from CY_IMOSPHERE_CDM_531.death)
) denominator
;

/*********
PLAUSIBLE_DURING_LIFE
get number of events that occur after death event (PLAUSIBLE_DURING_LIFE == Yes)
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_ERA
cdmFieldName = CONDITION_ERA_START_DATE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'PLAUSIBLE_DURING_LIFE' level,
    'get number of events that occur after death event (PLAUSIBLE_DURING_LIFE == Yes)' check,
    'CONDITION_ERA' cdmTableName,
'CONDITION_ERA_START_DATE' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'CONDITION_ERA.CONDITION_ERA_START_DATE' as violating_field, 
			cdmtable.*
    	from CY_IMOSPHERE_CDM_531.condition_era cdmtable
    	join CY_IMOSPHERE_CDM_531.death de on cdmtable.person_id = de.person_id
    	where IF(SAFE_CAST(cdmtable.condition_era_start_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.condition_era_start_date  AS STRING)),SAFE_CAST(cdmtable.condition_era_start_date  AS DATE)) > DATE_ADD(IF(SAFE_CAST(IF(SAFE_CAST(de.death_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(de.death_date  AS STRING)),SAFE_CAST(de.death_date  AS DATE))  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(IF(SAFE_CAST(de.death_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(de.death_date  AS STRING)),SAFE_CAST(de.death_date  AS DATE))  AS STRING)),SAFE_CAST(IF(SAFE_CAST(de.death_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(de.death_date  AS STRING)),SAFE_CAST(de.death_date  AS DATE))  AS DATE)), INTERVAL 60 DAY)
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_era cdmtable
	where person_id in
		(select 
			person_id 
		from CY_IMOSPHERE_CDM_531.death)
) denominator
;

