/*********
TABLE LEVEL check:
CDM_TABLE - verify the table exists
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PERSON
**********/
select 
  num_violated_rows, 
  case 
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows 
  end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
  select 
    num_violated_rows 
  from
  (
    select
      case 
        when COUNT(*) = 0 then 0
        else 0
    end as num_violated_rows
    from CY_IMOSPHERE_CDM_531.person cdmtable
  ) violated_rows
) violated_row_count,
( 
	select 1 as num_rows
) denominator
;

/*********
TABLE LEVEL check:
CDM_TABLE - verify the table exists
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = OBSERVATION_PERIOD
**********/
select 
  num_violated_rows, 
  case 
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows 
  end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
  select 
    num_violated_rows 
  from
  (
    select
      case 
        when COUNT(*) = 0 then 0
        else 0
    end as num_violated_rows
    from CY_IMOSPHERE_CDM_531.observation_period cdmtable
  ) violated_rows
) violated_row_count,
( 
	select 1 as num_rows
) denominator
;

/*********
TABLE LEVEL check:
CDM_TABLE - verify the table exists
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_OCCURRENCE
**********/
select 
  num_violated_rows, 
  case 
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows 
  end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
  select 
    num_violated_rows 
  from
  (
    select
      case 
        when COUNT(*) = 0 then 0
        else 0
    end as num_violated_rows
    from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
  ) violated_rows
) violated_row_count,
( 
	select 1 as num_rows
) denominator
;

/*********
TABLE LEVEL check:
CDM_TABLE - verify the table exists
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
**********/
select 
  num_violated_rows, 
  case 
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows 
  end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
  select 
    num_violated_rows 
  from
  (
    select
      case 
        when COUNT(*) = 0 then 0
        else 0
    end as num_violated_rows
    from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
  ) violated_rows
) violated_row_count,
( 
	select 1 as num_rows
) denominator
;

/*********
TABLE LEVEL check:
CDM_TABLE - verify the table exists
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DRUG_EXPOSURE
**********/
select 
  num_violated_rows, 
  case 
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows 
  end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
  select 
    num_violated_rows 
  from
  (
    select
      case 
        when COUNT(*) = 0 then 0
        else 0
    end as num_violated_rows
    from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
  ) violated_rows
) violated_row_count,
( 
	select 1 as num_rows
) denominator
;

/*********
TABLE LEVEL check:
CDM_TABLE - verify the table exists
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
**********/
select 
  num_violated_rows, 
  case 
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows 
  end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
  select 
    num_violated_rows 
  from
  (
    select
      case 
        when COUNT(*) = 0 then 0
        else 0
    end as num_violated_rows
    from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
  ) violated_rows
) violated_row_count,
( 
	select 1 as num_rows
) denominator
;

/*********
TABLE LEVEL check:
CDM_TABLE - verify the table exists
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DEVICE_EXPOSURE
**********/
select 
  num_violated_rows, 
  case 
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows 
  end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
  select 
    num_violated_rows 
  from
  (
    select
      case 
        when COUNT(*) = 0 then 0
        else 0
    end as num_violated_rows
    from CY_IMOSPHERE_CDM_531.device_exposure cdmtable
  ) violated_rows
) violated_row_count,
( 
	select 1 as num_rows
) denominator
;

/*********
TABLE LEVEL check:
CDM_TABLE - verify the table exists
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = MEASUREMENT
**********/
select 
  num_violated_rows, 
  case 
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows 
  end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
  select 
    num_violated_rows 
  from
  (
    select
      case 
        when COUNT(*) = 0 then 0
        else 0
    end as num_violated_rows
    from CY_IMOSPHERE_CDM_531.measurement cdmtable
  ) violated_rows
) violated_row_count,
( 
	select 1 as num_rows
) denominator
;

/*********
TABLE LEVEL check:
CDM_TABLE - verify the table exists
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_DETAIL
**********/
select 
  num_violated_rows, 
  case 
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows 
  end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
  select 
    num_violated_rows 
  from
  (
    select
      case 
        when COUNT(*) = 0 then 0
        else 0
    end as num_violated_rows
    from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
  ) violated_rows
) violated_row_count,
( 
	select 1 as num_rows
) denominator
;

/*********
TABLE LEVEL check:
CDM_TABLE - verify the table exists
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = NOTE
**********/
select 
  num_violated_rows, 
  case 
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows 
  end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
  select 
    num_violated_rows 
  from
  (
    select
      case 
        when COUNT(*) = 0 then 0
        else 0
    end as num_violated_rows
    from CY_IMOSPHERE_CDM_531.note cdmtable
  ) violated_rows
) violated_row_count,
( 
	select 1 as num_rows
) denominator
;

/*********
TABLE LEVEL check:
CDM_TABLE - verify the table exists
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = NOTE_NLP
**********/
select 
  num_violated_rows, 
  case 
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows 
  end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
  select 
    num_violated_rows 
  from
  (
    select
      case 
        when COUNT(*) = 0 then 0
        else 0
    end as num_violated_rows
    from CY_IMOSPHERE_CDM_531.note_nlp cdmtable
  ) violated_rows
) violated_row_count,
( 
	select 1 as num_rows
) denominator
;

/*********
TABLE LEVEL check:
CDM_TABLE - verify the table exists
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = OBSERVATION
**********/
select 
  num_violated_rows, 
  case 
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows 
  end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
  select 
    num_violated_rows 
  from
  (
    select
      case 
        when COUNT(*) = 0 then 0
        else 0
    end as num_violated_rows
    from CY_IMOSPHERE_CDM_531.observation cdmtable
  ) violated_rows
) violated_row_count,
( 
	select 1 as num_rows
) denominator
;

/*********
TABLE LEVEL check:
CDM_TABLE - verify the table exists
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = FACT_RELATIONSHIP
**********/
select 
  num_violated_rows, 
  case 
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows 
  end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
  select 
    num_violated_rows 
  from
  (
    select
      case 
        when COUNT(*) = 0 then 0
        else 0
    end as num_violated_rows
    from CY_IMOSPHERE_CDM_531.fact_relationship cdmtable
  ) violated_rows
) violated_row_count,
( 
	select 1 as num_rows
) denominator
;

/*********
TABLE LEVEL check:
CDM_TABLE - verify the table exists
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = LOCATION
**********/
select 
  num_violated_rows, 
  case 
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows 
  end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
  select 
    num_violated_rows 
  from
  (
    select
      case 
        when COUNT(*) = 0 then 0
        else 0
    end as num_violated_rows
    from CY_IMOSPHERE_CDM_531.location cdmtable
  ) violated_rows
) violated_row_count,
( 
	select 1 as num_rows
) denominator
;

/*********
TABLE LEVEL check:
CDM_TABLE - verify the table exists
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CARE_SITE
**********/
select 
  num_violated_rows, 
  case 
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows 
  end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
  select 
    num_violated_rows 
  from
  (
    select
      case 
        when COUNT(*) = 0 then 0
        else 0
    end as num_violated_rows
    from CY_IMOSPHERE_CDM_531.care_site cdmtable
  ) violated_rows
) violated_row_count,
( 
	select 1 as num_rows
) denominator
;

/*********
TABLE LEVEL check:
CDM_TABLE - verify the table exists
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROVIDER
**********/
select 
  num_violated_rows, 
  case 
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows 
  end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
  select 
    num_violated_rows 
  from
  (
    select
      case 
        when COUNT(*) = 0 then 0
        else 0
    end as num_violated_rows
    from CY_IMOSPHERE_CDM_531.provider cdmtable
  ) violated_rows
) violated_row_count,
( 
	select 1 as num_rows
) denominator
;

/*********
TABLE LEVEL check:
CDM_TABLE - verify the table exists
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PAYER_PLAN_PERIOD
**********/
select 
  num_violated_rows, 
  case 
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows 
  end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
  select 
    num_violated_rows 
  from
  (
    select
      case 
        when COUNT(*) = 0 then 0
        else 0
    end as num_violated_rows
    from CY_IMOSPHERE_CDM_531.payer_plan_period cdmtable
  ) violated_rows
) violated_row_count,
( 
	select 1 as num_rows
) denominator
;

/*********
TABLE LEVEL check:
CDM_TABLE - verify the table exists
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DRUG_ERA
**********/
select 
  num_violated_rows, 
  case 
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows 
  end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
  select 
    num_violated_rows 
  from
  (
    select
      case 
        when COUNT(*) = 0 then 0
        else 0
    end as num_violated_rows
    from CY_IMOSPHERE_CDM_531.drug_era cdmtable
  ) violated_rows
) violated_row_count,
( 
	select 1 as num_rows
) denominator
;

/*********
TABLE LEVEL check:
CDM_TABLE - verify the table exists
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_ERA
**********/
select 
  num_violated_rows, 
  case 
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows 
  end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
  select 
    num_violated_rows 
  from
  (
    select
      case 
        when COUNT(*) = 0 then 0
        else 0
    end as num_violated_rows
    from CY_IMOSPHERE_CDM_531.condition_era cdmtable
  ) violated_rows
) violated_row_count,
( 
	select 1 as num_rows
) denominator
;

