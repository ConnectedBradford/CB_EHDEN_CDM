/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = PERSON
cdmFieldName = GENDER_CONCEPT_ID
fkTableName = CONCEPT
fkFieldName = CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'PERSON' cdmTableName,
'GENDER_CONCEPT_ID' cdmFieldName,
'CONCEPT' fkTableName,
'CONCEPT_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'PERSON.GENDER_CONCEPT_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.person cdmtable
		  left join CY_CDM_VOCAB.concept fktable
		  on cdmtable.gender_concept_id = fktable.concept_id
		where fktable.concept_id is null 
		  and cdmtable.gender_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.person cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = PERSON
cdmFieldName = RACE_CONCEPT_ID
fkTableName = CONCEPT
fkFieldName = CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'PERSON' cdmTableName,
'RACE_CONCEPT_ID' cdmFieldName,
'CONCEPT' fkTableName,
'CONCEPT_ID' fkFieldName,
    	num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'PERSON.RACE_CONCEPT_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.person cdmtable
		  left join CY_CDM_VOCAB.concept fktable
		  on cdmtable.race_concept_id = fktable.concept_id
		where fktable.concept_id is null 
		  and cdmtable.race_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.person cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = PERSON
cdmFieldName = ETHNICITY_CONCEPT_ID
fkTableName = CONCEPT
fkFieldName = CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'PERSON' cdmTableName,
'ETHNICITY_CONCEPT_ID' cdmFieldName,
'CONCEPT' fkTableName,
'CONCEPT_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'PERSON.ETHNICITY_CONCEPT_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.person cdmtable
		  left join CY_CDM_VOCAB.concept fktable
		  on cdmtable.ethnicity_concept_id = fktable.concept_id
		where fktable.concept_id is null 
		  and cdmtable.ethnicity_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.person cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PERSON
cdmFieldName = LOCATION_ID
fkTableName = LOCATION
fkFieldName = LOCATION_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'PERSON' cdmTableName,
'LOCATION_ID' cdmFieldName,
'LOCATION' fkTableName,
'LOCATION_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'PERSON.LOCATION_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.person cdmtable
		  left join CY_IMOSPHERE_CDM_531.location fktable
		  on cdmtable.location_id = fktable.location_id
		where fktable.location_id is null 
		  and cdmtable.location_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.person cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PERSON
cdmFieldName = PROVIDER_ID
fkTableName = PROVIDER
fkFieldName = PROVIDER_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'PERSON' cdmTableName,
'PROVIDER_ID' cdmFieldName,
'PROVIDER' fkTableName,
'PROVIDER_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'PERSON.PROVIDER_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.person cdmtable
		  left join CY_IMOSPHERE_CDM_531.provider fktable
		  on cdmtable.provider_id = fktable.provider_id
		where fktable.provider_id is null 
		  and cdmtable.provider_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.person cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PERSON
cdmFieldName = CARE_SITE_ID
fkTableName = CARE_SITE
fkFieldName = CARE_SITE_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'PERSON' cdmTableName,
'CARE_SITE_ID' cdmFieldName,
'CARE_SITE' fkTableName,
'CARE_SITE_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'PERSON.CARE_SITE_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.person cdmtable
		  left join CY_IMOSPHERE_CDM_531.care_site fktable
		  on cdmtable.care_site_id = fktable.care_site_id
		where fktable.care_site_id is null 
		  and cdmtable.care_site_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.person cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = PERSON
cdmFieldName = GENDER_SOURCE_CONCEPT_ID
fkTableName = CONCEPT
fkFieldName = CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'PERSON' cdmTableName,
'GENDER_SOURCE_CONCEPT_ID' cdmFieldName,
'CONCEPT' fkTableName,
'CONCEPT_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'PERSON.GENDER_SOURCE_CONCEPT_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.person cdmtable
		  left join CY_CDM_VOCAB.concept fktable
		  on cdmtable.gender_source_concept_id = fktable.concept_id
		where fktable.concept_id is null 
		  and cdmtable.gender_source_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.person cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = PERSON
cdmFieldName = RACE_SOURCE_CONCEPT_ID
fkTableName = CONCEPT
fkFieldName = CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'PERSON' cdmTableName,
'RACE_SOURCE_CONCEPT_ID' cdmFieldName,
'CONCEPT' fkTableName,
'CONCEPT_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'PERSON.RACE_SOURCE_CONCEPT_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.person cdmtable
		  left join CY_CDM_VOCAB.concept fktable
		  on cdmtable.race_source_concept_id = fktable.concept_id
		where fktable.concept_id is null 
		  and cdmtable.race_source_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.person cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = PERSON
cdmFieldName = ETHNICITY_SOURCE_CONCEPT_ID
fkTableName = CONCEPT
fkFieldName = CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'PERSON' cdmTableName,
'ETHNICITY_SOURCE_CONCEPT_ID' cdmFieldName,
'CONCEPT' fkTableName,
'CONCEPT_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'PERSON.ETHNICITY_SOURCE_CONCEPT_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.person cdmtable
		  left join CY_CDM_VOCAB.concept fktable
		  on cdmtable.ethnicity_source_concept_id = fktable.concept_id
		where fktable.concept_id is null 
		  and cdmtable.ethnicity_source_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.person cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = OBSERVATION_PERIOD
cdmFieldName = PERSON_ID
fkTableName = PERSON
fkFieldName = PERSON_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'OBSERVATION_PERIOD' cdmTableName,
'PERSON_ID' cdmFieldName,
'PERSON' fkTableName,
'PERSON_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'OBSERVATION_PERIOD.PERSON_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.observation_period cdmtable
		  left join CY_IMOSPHERE_CDM_531.person fktable
		  on cdmtable.person_id = fktable.person_id
		where fktable.person_id is null 
		  and cdmtable.person_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.observation_period cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = OBSERVATION_PERIOD
cdmFieldName = PERIOD_TYPE_CONCEPT_ID
fkTableName = CONCEPT
fkFieldName = CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'OBSERVATION_PERIOD' cdmTableName,
'PERIOD_TYPE_CONCEPT_ID' cdmFieldName,
'CONCEPT' fkTableName,
'CONCEPT_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'OBSERVATION_PERIOD.PERIOD_TYPE_CONCEPT_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.observation_period cdmtable
		  left join CY_CDM_VOCAB.concept fktable
		  on cdmtable.period_type_concept_id = fktable.concept_id
		where fktable.concept_id is null 
		  and cdmtable.period_type_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.observation_period cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_OCCURRENCE
cdmFieldName = PERSON_ID
fkTableName = PERSON
fkFieldName = PERSON_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'VISIT_OCCURRENCE' cdmTableName,
'PERSON_ID' cdmFieldName,
'PERSON' fkTableName,
'PERSON_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'VISIT_OCCURRENCE.PERSON_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
		  left join CY_IMOSPHERE_CDM_531.person fktable
		  on cdmtable.person_id = fktable.person_id
		where fktable.person_id is null 
		  and cdmtable.person_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = VISIT_OCCURRENCE
cdmFieldName = VISIT_CONCEPT_ID
fkTableName = CONCEPT
fkFieldName = CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'VISIT_OCCURRENCE' cdmTableName,
'VISIT_CONCEPT_ID' cdmFieldName,
'CONCEPT' fkTableName,
'CONCEPT_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'VISIT_OCCURRENCE.VISIT_CONCEPT_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
		  left join CY_CDM_VOCAB.concept fktable
		  on cdmtable.visit_concept_id = fktable.concept_id
		where fktable.concept_id is null 
		  and cdmtable.visit_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = VISIT_OCCURRENCE
cdmFieldName = VISIT_TYPE_CONCEPT_ID
fkTableName = CONCEPT
fkFieldName = CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'VISIT_OCCURRENCE' cdmTableName,
'VISIT_TYPE_CONCEPT_ID' cdmFieldName,
'CONCEPT' fkTableName,
'CONCEPT_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'VISIT_OCCURRENCE.VISIT_TYPE_CONCEPT_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
		  left join CY_CDM_VOCAB.concept fktable
		  on cdmtable.visit_type_concept_id = fktable.concept_id
		where fktable.concept_id is null 
		  and cdmtable.visit_type_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_OCCURRENCE
cdmFieldName = PROVIDER_ID
fkTableName = PROVIDER
fkFieldName = PROVIDER_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'VISIT_OCCURRENCE' cdmTableName,
'PROVIDER_ID' cdmFieldName,
'PROVIDER' fkTableName,
'PROVIDER_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'VISIT_OCCURRENCE.PROVIDER_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
		  left join CY_IMOSPHERE_CDM_531.provider fktable
		  on cdmtable.provider_id = fktable.provider_id
		where fktable.provider_id is null 
		  and cdmtable.provider_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_OCCURRENCE
cdmFieldName = CARE_SITE_ID
fkTableName = CARE_SITE
fkFieldName = CARE_SITE_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'VISIT_OCCURRENCE' cdmTableName,
'CARE_SITE_ID' cdmFieldName,
'CARE_SITE' fkTableName,
'CARE_SITE_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'VISIT_OCCURRENCE.CARE_SITE_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
		  left join CY_IMOSPHERE_CDM_531.care_site fktable
		  on cdmtable.care_site_id = fktable.care_site_id
		where fktable.care_site_id is null 
		  and cdmtable.care_site_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = VISIT_OCCURRENCE
cdmFieldName = VISIT_SOURCE_CONCEPT_ID
fkTableName = CONCEPT
fkFieldName = CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'VISIT_OCCURRENCE' cdmTableName,
'VISIT_SOURCE_CONCEPT_ID' cdmFieldName,
'CONCEPT' fkTableName,
'CONCEPT_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'VISIT_OCCURRENCE.VISIT_SOURCE_CONCEPT_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
		  left join CY_CDM_VOCAB.concept fktable
		  on cdmtable.visit_source_concept_id = fktable.concept_id
		where fktable.concept_id is null 
		  and cdmtable.visit_source_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = VISIT_OCCURRENCE
cdmFieldName = ADMITTING_SOURCE_CONCEPT_ID
fkTableName = CONCEPT
fkFieldName = CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'VISIT_OCCURRENCE' cdmTableName,
'ADMITTING_SOURCE_CONCEPT_ID' cdmFieldName,
'CONCEPT' fkTableName,
'CONCEPT_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'VISIT_OCCURRENCE.ADMITTING_SOURCE_CONCEPT_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
		  left join CY_CDM_VOCAB.concept fktable
		  on cdmtable.admitting_source_concept_id = fktable.concept_id
		where fktable.concept_id is null 
		  and cdmtable.admitting_source_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = VISIT_OCCURRENCE
cdmFieldName = DISCHARGE_TO_CONCEPT_ID
fkTableName = CONCEPT
fkFieldName = CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'VISIT_OCCURRENCE' cdmTableName,
'DISCHARGE_TO_CONCEPT_ID' cdmFieldName,
'CONCEPT' fkTableName,
'CONCEPT_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'VISIT_OCCURRENCE.DISCHARGE_TO_CONCEPT_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
		  left join CY_CDM_VOCAB.concept fktable
		  on cdmtable.discharge_to_concept_id = fktable.concept_id
		where fktable.concept_id is null 
		  and cdmtable.discharge_to_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_OCCURRENCE
cdmFieldName = PRECEDING_VISIT_OCCURRENCE_ID
fkTableName = VISIT_OCCURRENCE
fkFieldName = VISIT_OCCURRENCE_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'VISIT_OCCURRENCE' cdmTableName,
'PRECEDING_VISIT_OCCURRENCE_ID' cdmFieldName,
'VISIT_OCCURRENCE' fkTableName,
'VISIT_OCCURRENCE_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'VISIT_OCCURRENCE.PRECEDING_VISIT_OCCURRENCE_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
		  left join CY_IMOSPHERE_CDM_531.visit_occurrence fktable
		  on cdmtable.preceding_visit_occurrence_id = fktable.visit_occurrence_id
		where fktable.visit_occurrence_id is null 
		  and cdmtable.preceding_visit_occurrence_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = PERSON_ID
fkTableName = PERSON
fkFieldName = PERSON_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'PERSON_ID' cdmFieldName,
'PERSON' fkTableName,
'PERSON_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'CONDITION_OCCURRENCE.PERSON_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
		  left join CY_IMOSPHERE_CDM_531.person fktable
		  on cdmtable.person_id = fktable.person_id
		where fktable.person_id is null 
		  and cdmtable.person_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
fkTableName = CONCEPT
fkFieldName = CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'CONCEPT' fkTableName,
'CONCEPT_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'CONDITION_OCCURRENCE.CONDITION_CONCEPT_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
		  left join CY_CDM_VOCAB.concept fktable
		  on cdmtable.condition_concept_id = fktable.concept_id
		where fktable.concept_id is null 
		  and cdmtable.condition_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_TYPE_CONCEPT_ID
fkTableName = CONCEPT
fkFieldName = CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_TYPE_CONCEPT_ID' cdmFieldName,
'CONCEPT' fkTableName,
'CONCEPT_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'CONDITION_OCCURRENCE.CONDITION_TYPE_CONCEPT_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
		  left join CY_CDM_VOCAB.concept fktable
		  on cdmtable.condition_type_concept_id = fktable.concept_id
		where fktable.concept_id is null 
		  and cdmtable.condition_type_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_STATUS_CONCEPT_ID
fkTableName = CONCEPT
fkFieldName = CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_STATUS_CONCEPT_ID' cdmFieldName,
'CONCEPT' fkTableName,
'CONCEPT_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'CONDITION_OCCURRENCE.CONDITION_STATUS_CONCEPT_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
		  left join CY_CDM_VOCAB.concept fktable
		  on cdmtable.condition_status_concept_id = fktable.concept_id
		where fktable.concept_id is null 
		  and cdmtable.condition_status_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = PROVIDER_ID
fkTableName = PROVIDER
fkFieldName = PROVIDER_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'PROVIDER_ID' cdmFieldName,
'PROVIDER' fkTableName,
'PROVIDER_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'CONDITION_OCCURRENCE.PROVIDER_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
		  left join CY_IMOSPHERE_CDM_531.provider fktable
		  on cdmtable.provider_id = fktable.provider_id
		where fktable.provider_id is null 
		  and cdmtable.provider_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = VISIT_OCCURRENCE_ID
fkTableName = VISIT_OCCURRENCE
fkFieldName = VISIT_OCCURRENCE_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'VISIT_OCCURRENCE_ID' cdmFieldName,
'VISIT_OCCURRENCE' fkTableName,
'VISIT_OCCURRENCE_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'CONDITION_OCCURRENCE.VISIT_OCCURRENCE_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
		  left join CY_IMOSPHERE_CDM_531.visit_occurrence fktable
		  on cdmtable.visit_occurrence_id = fktable.visit_occurrence_id
		where fktable.visit_occurrence_id is null 
		  and cdmtable.visit_occurrence_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = VISIT_DETAIL_ID
fkTableName = VISIT_DETAIL
fkFieldName = VISIT_DETAIL_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'VISIT_DETAIL_ID' cdmFieldName,
'VISIT_DETAIL' fkTableName,
'VISIT_DETAIL_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'CONDITION_OCCURRENCE.VISIT_DETAIL_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
		  left join CY_IMOSPHERE_CDM_531.visit_detail fktable
		  on cdmtable.visit_detail_id = fktable.visit_detail_id
		where fktable.visit_detail_id is null 
		  and cdmtable.visit_detail_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_SOURCE_CONCEPT_ID
fkTableName = CONCEPT
fkFieldName = CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_SOURCE_CONCEPT_ID' cdmFieldName,
'CONCEPT' fkTableName,
'CONCEPT_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'CONDITION_OCCURRENCE.CONDITION_SOURCE_CONCEPT_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
		  left join CY_CDM_VOCAB.concept fktable
		  on cdmtable.condition_source_concept_id = fktable.concept_id
		where fktable.concept_id is null 
		  and cdmtable.condition_source_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DRUG_EXPOSURE
cdmFieldName = PERSON_ID
fkTableName = PERSON
fkFieldName = PERSON_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'DRUG_EXPOSURE' cdmTableName,
'PERSON_ID' cdmFieldName,
'PERSON' fkTableName,
'PERSON_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'DRUG_EXPOSURE.PERSON_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
		  left join CY_IMOSPHERE_CDM_531.person fktable
		  on cdmtable.person_id = fktable.person_id
		where fktable.person_id is null 
		  and cdmtable.person_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = DRUG_EXPOSURE
cdmFieldName = DRUG_CONCEPT_ID
fkTableName = CONCEPT
fkFieldName = CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'DRUG_EXPOSURE' cdmTableName,
'DRUG_CONCEPT_ID' cdmFieldName,
'CONCEPT' fkTableName,
'CONCEPT_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'DRUG_EXPOSURE.DRUG_CONCEPT_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
		  left join CY_CDM_VOCAB.concept fktable
		  on cdmtable.drug_concept_id = fktable.concept_id
		where fktable.concept_id is null 
		  and cdmtable.drug_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = DRUG_EXPOSURE
cdmFieldName = DRUG_TYPE_CONCEPT_ID
fkTableName = CONCEPT
fkFieldName = CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'DRUG_EXPOSURE' cdmTableName,
'DRUG_TYPE_CONCEPT_ID' cdmFieldName,
'CONCEPT' fkTableName,
'CONCEPT_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'DRUG_EXPOSURE.DRUG_TYPE_CONCEPT_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
		  left join CY_CDM_VOCAB.concept fktable
		  on cdmtable.drug_type_concept_id = fktable.concept_id
		where fktable.concept_id is null 
		  and cdmtable.drug_type_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = DRUG_EXPOSURE
cdmFieldName = ROUTE_CONCEPT_ID
fkTableName = CONCEPT
fkFieldName = CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'DRUG_EXPOSURE' cdmTableName,
'ROUTE_CONCEPT_ID' cdmFieldName,
'CONCEPT' fkTableName,
'CONCEPT_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'DRUG_EXPOSURE.ROUTE_CONCEPT_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
		  left join CY_CDM_VOCAB.concept fktable
		  on cdmtable.route_concept_id = fktable.concept_id
		where fktable.concept_id is null 
		  and cdmtable.route_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DRUG_EXPOSURE
cdmFieldName = PROVIDER_ID
fkTableName = PROVIDER
fkFieldName = PROVIDER_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'DRUG_EXPOSURE' cdmTableName,
'PROVIDER_ID' cdmFieldName,
'PROVIDER' fkTableName,
'PROVIDER_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'DRUG_EXPOSURE.PROVIDER_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
		  left join CY_IMOSPHERE_CDM_531.provider fktable
		  on cdmtable.provider_id = fktable.provider_id
		where fktable.provider_id is null 
		  and cdmtable.provider_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DRUG_EXPOSURE
cdmFieldName = VISIT_OCCURRENCE_ID
fkTableName = VISIT_OCCURRENCE
fkFieldName = VISIT_OCCURRENCE_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'DRUG_EXPOSURE' cdmTableName,
'VISIT_OCCURRENCE_ID' cdmFieldName,
'VISIT_OCCURRENCE' fkTableName,
'VISIT_OCCURRENCE_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'DRUG_EXPOSURE.VISIT_OCCURRENCE_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
		  left join CY_IMOSPHERE_CDM_531.visit_occurrence fktable
		  on cdmtable.visit_occurrence_id = fktable.visit_occurrence_id
		where fktable.visit_occurrence_id is null 
		  and cdmtable.visit_occurrence_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DRUG_EXPOSURE
cdmFieldName = VISIT_DETAIL_ID
fkTableName = VISIT_DETAIL
fkFieldName = VISIT_DETAIL_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'DRUG_EXPOSURE' cdmTableName,
'VISIT_DETAIL_ID' cdmFieldName,
'VISIT_DETAIL' fkTableName,
'VISIT_DETAIL_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'DRUG_EXPOSURE.VISIT_DETAIL_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
		  left join CY_IMOSPHERE_CDM_531.visit_detail fktable
		  on cdmtable.visit_detail_id = fktable.visit_detail_id
		where fktable.visit_detail_id is null 
		  and cdmtable.visit_detail_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = DRUG_EXPOSURE
cdmFieldName = DRUG_SOURCE_CONCEPT_ID
fkTableName = CONCEPT
fkFieldName = CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'DRUG_EXPOSURE' cdmTableName,
'DRUG_SOURCE_CONCEPT_ID' cdmFieldName,
'CONCEPT' fkTableName,
'CONCEPT_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'DRUG_EXPOSURE.DRUG_SOURCE_CONCEPT_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
		  left join CY_CDM_VOCAB.concept fktable
		  on cdmtable.drug_source_concept_id = fktable.concept_id
		where fktable.concept_id is null 
		  and cdmtable.drug_source_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PERSON_ID
fkTableName = PERSON
fkFieldName = PERSON_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PERSON_ID' cdmFieldName,
'PERSON' fkTableName,
'PERSON_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'PROCEDURE_OCCURRENCE.PERSON_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
		  left join CY_IMOSPHERE_CDM_531.person fktable
		  on cdmtable.person_id = fktable.person_id
		where fktable.person_id is null 
		  and cdmtable.person_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_CONCEPT_ID
fkTableName = CONCEPT
fkFieldName = CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_CONCEPT_ID' cdmFieldName,
'CONCEPT' fkTableName,
'CONCEPT_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'PROCEDURE_OCCURRENCE.PROCEDURE_CONCEPT_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
		  left join CY_CDM_VOCAB.concept fktable
		  on cdmtable.procedure_concept_id = fktable.concept_id
		where fktable.concept_id is null 
		  and cdmtable.procedure_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_TYPE_CONCEPT_ID
fkTableName = CONCEPT
fkFieldName = CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_TYPE_CONCEPT_ID' cdmFieldName,
'CONCEPT' fkTableName,
'CONCEPT_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'PROCEDURE_OCCURRENCE.PROCEDURE_TYPE_CONCEPT_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
		  left join CY_CDM_VOCAB.concept fktable
		  on cdmtable.procedure_type_concept_id = fktable.concept_id
		where fktable.concept_id is null 
		  and cdmtable.procedure_type_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = MODIFIER_CONCEPT_ID
fkTableName = CONCEPT
fkFieldName = CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'MODIFIER_CONCEPT_ID' cdmFieldName,
'CONCEPT' fkTableName,
'CONCEPT_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'PROCEDURE_OCCURRENCE.MODIFIER_CONCEPT_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
		  left join CY_CDM_VOCAB.concept fktable
		  on cdmtable.modifier_concept_id = fktable.concept_id
		where fktable.concept_id is null 
		  and cdmtable.modifier_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROVIDER_ID
fkTableName = PROVIDER
fkFieldName = PROVIDER_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROVIDER_ID' cdmFieldName,
'PROVIDER' fkTableName,
'PROVIDER_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'PROCEDURE_OCCURRENCE.PROVIDER_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
		  left join CY_IMOSPHERE_CDM_531.provider fktable
		  on cdmtable.provider_id = fktable.provider_id
		where fktable.provider_id is null 
		  and cdmtable.provider_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = VISIT_OCCURRENCE_ID
fkTableName = VISIT_OCCURRENCE
fkFieldName = VISIT_OCCURRENCE_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'VISIT_OCCURRENCE_ID' cdmFieldName,
'VISIT_OCCURRENCE' fkTableName,
'VISIT_OCCURRENCE_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'PROCEDURE_OCCURRENCE.VISIT_OCCURRENCE_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
		  left join CY_IMOSPHERE_CDM_531.visit_occurrence fktable
		  on cdmtable.visit_occurrence_id = fktable.visit_occurrence_id
		where fktable.visit_occurrence_id is null 
		  and cdmtable.visit_occurrence_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = VISIT_DETAIL_ID
fkTableName = VISIT_DETAIL
fkFieldName = VISIT_DETAIL_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'VISIT_DETAIL_ID' cdmFieldName,
'VISIT_DETAIL' fkTableName,
'VISIT_DETAIL_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'PROCEDURE_OCCURRENCE.VISIT_DETAIL_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
		  left join CY_IMOSPHERE_CDM_531.visit_detail fktable
		  on cdmtable.visit_detail_id = fktable.visit_detail_id
		where fktable.visit_detail_id is null 
		  and cdmtable.visit_detail_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_SOURCE_CONCEPT_ID
fkTableName = CONCEPT
fkFieldName = CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_SOURCE_CONCEPT_ID' cdmFieldName,
'CONCEPT' fkTableName,
'CONCEPT_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'PROCEDURE_OCCURRENCE.PROCEDURE_SOURCE_CONCEPT_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
		  left join CY_CDM_VOCAB.concept fktable
		  on cdmtable.procedure_source_concept_id = fktable.concept_id
		where fktable.concept_id is null 
		  and cdmtable.procedure_source_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DEVICE_EXPOSURE
cdmFieldName = PERSON_ID
fkTableName = PERSON
fkFieldName = PERSON_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'DEVICE_EXPOSURE' cdmTableName,
'PERSON_ID' cdmFieldName,
'PERSON' fkTableName,
'PERSON_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'DEVICE_EXPOSURE.PERSON_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.device_exposure cdmtable
		  left join CY_IMOSPHERE_CDM_531.person fktable
		  on cdmtable.person_id = fktable.person_id
		where fktable.person_id is null 
		  and cdmtable.person_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.device_exposure cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = DEVICE_EXPOSURE
cdmFieldName = DEVICE_CONCEPT_ID
fkTableName = CONCEPT
fkFieldName = CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'DEVICE_EXPOSURE' cdmTableName,
'DEVICE_CONCEPT_ID' cdmFieldName,
'CONCEPT' fkTableName,
'CONCEPT_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'DEVICE_EXPOSURE.DEVICE_CONCEPT_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.device_exposure cdmtable
		  left join CY_CDM_VOCAB.concept fktable
		  on cdmtable.device_concept_id = fktable.concept_id
		where fktable.concept_id is null 
		  and cdmtable.device_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.device_exposure cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = DEVICE_EXPOSURE
cdmFieldName = DEVICE_TYPE_CONCEPT_ID
fkTableName = CONCEPT
fkFieldName = CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'DEVICE_EXPOSURE' cdmTableName,
'DEVICE_TYPE_CONCEPT_ID' cdmFieldName,
'CONCEPT' fkTableName,
'CONCEPT_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'DEVICE_EXPOSURE.DEVICE_TYPE_CONCEPT_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.device_exposure cdmtable
		  left join CY_CDM_VOCAB.concept fktable
		  on cdmtable.device_type_concept_id = fktable.concept_id
		where fktable.concept_id is null 
		  and cdmtable.device_type_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.device_exposure cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DEVICE_EXPOSURE
cdmFieldName = PROVIDER_ID
fkTableName = PROVIDER
fkFieldName = PROVIDER_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'DEVICE_EXPOSURE' cdmTableName,
'PROVIDER_ID' cdmFieldName,
'PROVIDER' fkTableName,
'PROVIDER_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'DEVICE_EXPOSURE.PROVIDER_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.device_exposure cdmtable
		  left join CY_IMOSPHERE_CDM_531.provider fktable
		  on cdmtable.provider_id = fktable.provider_id
		where fktable.provider_id is null 
		  and cdmtable.provider_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.device_exposure cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DEVICE_EXPOSURE
cdmFieldName = VISIT_OCCURRENCE_ID
fkTableName = VISIT_OCCURRENCE
fkFieldName = VISIT_OCCURRENCE_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'DEVICE_EXPOSURE' cdmTableName,
'VISIT_OCCURRENCE_ID' cdmFieldName,
'VISIT_OCCURRENCE' fkTableName,
'VISIT_OCCURRENCE_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'DEVICE_EXPOSURE.VISIT_OCCURRENCE_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.device_exposure cdmtable
		  left join CY_IMOSPHERE_CDM_531.visit_occurrence fktable
		  on cdmtable.visit_occurrence_id = fktable.visit_occurrence_id
		where fktable.visit_occurrence_id is null 
		  and cdmtable.visit_occurrence_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.device_exposure cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DEVICE_EXPOSURE
cdmFieldName = VISIT_DETAIL_ID
fkTableName = VISIT_DETAIL
fkFieldName = VISIT_DETAIL_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'DEVICE_EXPOSURE' cdmTableName,
'VISIT_DETAIL_ID' cdmFieldName,
'VISIT_DETAIL' fkTableName,
'VISIT_DETAIL_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'DEVICE_EXPOSURE.VISIT_DETAIL_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.device_exposure cdmtable
		  left join CY_IMOSPHERE_CDM_531.visit_detail fktable
		  on cdmtable.visit_detail_id = fktable.visit_detail_id
		where fktable.visit_detail_id is null 
		  and cdmtable.visit_detail_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.device_exposure cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = DEVICE_EXPOSURE
cdmFieldName = DEVICE_SOURCE_CONCEPT_ID
fkTableName = CONCEPT
fkFieldName = CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'DEVICE_EXPOSURE' cdmTableName,
'DEVICE_SOURCE_CONCEPT_ID' cdmFieldName,
'CONCEPT' fkTableName,
'CONCEPT_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'DEVICE_EXPOSURE.DEVICE_SOURCE_CONCEPT_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.device_exposure cdmtable
		  left join CY_CDM_VOCAB.concept fktable
		  on cdmtable.device_source_concept_id = fktable.concept_id
		where fktable.concept_id is null 
		  and cdmtable.device_source_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.device_exposure cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = MEASUREMENT
cdmFieldName = PERSON_ID
fkTableName = PERSON
fkFieldName = PERSON_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'MEASUREMENT' cdmTableName,
'PERSON_ID' cdmFieldName,
'PERSON' fkTableName,
'PERSON_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'MEASUREMENT.PERSON_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.measurement cdmtable
		  left join CY_IMOSPHERE_CDM_531.person fktable
		  on cdmtable.person_id = fktable.person_id
		where fktable.person_id is null 
		  and cdmtable.person_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.measurement cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = MEASUREMENT
cdmFieldName = MEASUREMENT_CONCEPT_ID
fkTableName = CONCEPT
fkFieldName = CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'MEASUREMENT' cdmTableName,
'MEASUREMENT_CONCEPT_ID' cdmFieldName,
'CONCEPT' fkTableName,
'CONCEPT_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'MEASUREMENT.MEASUREMENT_CONCEPT_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.measurement cdmtable
		  left join CY_CDM_VOCAB.concept fktable
		  on cdmtable.measurement_concept_id = fktable.concept_id
		where fktable.concept_id is null 
		  and cdmtable.measurement_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.measurement cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = MEASUREMENT
cdmFieldName = MEASUREMENT_TYPE_CONCEPT_ID
fkTableName = CONCEPT
fkFieldName = CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'MEASUREMENT' cdmTableName,
'MEASUREMENT_TYPE_CONCEPT_ID' cdmFieldName,
'CONCEPT' fkTableName,
'CONCEPT_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'MEASUREMENT.MEASUREMENT_TYPE_CONCEPT_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.measurement cdmtable
		  left join CY_CDM_VOCAB.concept fktable
		  on cdmtable.measurement_type_concept_id = fktable.concept_id
		where fktable.concept_id is null 
		  and cdmtable.measurement_type_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.measurement cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = MEASUREMENT
cdmFieldName = OPERATOR_CONCEPT_ID
fkTableName = CONCEPT
fkFieldName = CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'MEASUREMENT' cdmTableName,
'OPERATOR_CONCEPT_ID' cdmFieldName,
'CONCEPT' fkTableName,
'CONCEPT_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'MEASUREMENT.OPERATOR_CONCEPT_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.measurement cdmtable
		  left join CY_CDM_VOCAB.concept fktable
		  on cdmtable.operator_concept_id = fktable.concept_id
		where fktable.concept_id is null 
		  and cdmtable.operator_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.measurement cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = MEASUREMENT
cdmFieldName = VALUE_AS_CONCEPT_ID
fkTableName = CONCEPT
fkFieldName = CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'MEASUREMENT' cdmTableName,
'VALUE_AS_CONCEPT_ID' cdmFieldName,
'CONCEPT' fkTableName,
'CONCEPT_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'MEASUREMENT.VALUE_AS_CONCEPT_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.measurement cdmtable
		  left join CY_CDM_VOCAB.concept fktable
		  on cdmtable.value_as_concept_id = fktable.concept_id
		where fktable.concept_id is null 
		  and cdmtable.value_as_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.measurement cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = MEASUREMENT
cdmFieldName = UNIT_CONCEPT_ID
fkTableName = CONCEPT
fkFieldName = CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'MEASUREMENT' cdmTableName,
'UNIT_CONCEPT_ID' cdmFieldName,
'CONCEPT' fkTableName,
'CONCEPT_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'MEASUREMENT.UNIT_CONCEPT_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.measurement cdmtable
		  left join CY_CDM_VOCAB.concept fktable
		  on cdmtable.unit_concept_id = fktable.concept_id
		where fktable.concept_id is null 
		  and cdmtable.unit_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.measurement cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = MEASUREMENT
cdmFieldName = PROVIDER_ID
fkTableName = PROVIDER
fkFieldName = PROVIDER_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'MEASUREMENT' cdmTableName,
'PROVIDER_ID' cdmFieldName,
'PROVIDER' fkTableName,
'PROVIDER_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'MEASUREMENT.PROVIDER_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.measurement cdmtable
		  left join CY_IMOSPHERE_CDM_531.provider fktable
		  on cdmtable.provider_id = fktable.provider_id
		where fktable.provider_id is null 
		  and cdmtable.provider_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.measurement cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = MEASUREMENT
cdmFieldName = VISIT_OCCURRENCE_ID
fkTableName = VISIT_OCCURRENCE
fkFieldName = VISIT_OCCURRENCE_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'MEASUREMENT' cdmTableName,
'VISIT_OCCURRENCE_ID' cdmFieldName,
'VISIT_OCCURRENCE' fkTableName,
'VISIT_OCCURRENCE_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'MEASUREMENT.VISIT_OCCURRENCE_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.measurement cdmtable
		  left join CY_IMOSPHERE_CDM_531.visit_occurrence fktable
		  on cdmtable.visit_occurrence_id = fktable.visit_occurrence_id
		where fktable.visit_occurrence_id is null 
		  and cdmtable.visit_occurrence_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.measurement cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = MEASUREMENT
cdmFieldName = VISIT_DETAIL_ID
fkTableName = VISIT_DETAIL
fkFieldName = VISIT_DETAIL_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'MEASUREMENT' cdmTableName,
'VISIT_DETAIL_ID' cdmFieldName,
'VISIT_DETAIL' fkTableName,
'VISIT_DETAIL_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'MEASUREMENT.VISIT_DETAIL_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.measurement cdmtable
		  left join CY_IMOSPHERE_CDM_531.visit_detail fktable
		  on cdmtable.visit_detail_id = fktable.visit_detail_id
		where fktable.visit_detail_id is null 
		  and cdmtable.visit_detail_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.measurement cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = MEASUREMENT
cdmFieldName = MEASUREMENT_SOURCE_CONCEPT_ID
fkTableName = CONCEPT
fkFieldName = CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'MEASUREMENT' cdmTableName,
'MEASUREMENT_SOURCE_CONCEPT_ID' cdmFieldName,
'CONCEPT' fkTableName,
'CONCEPT_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'MEASUREMENT.MEASUREMENT_SOURCE_CONCEPT_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.measurement cdmtable
		  left join CY_CDM_VOCAB.concept fktable
		  on cdmtable.measurement_source_concept_id = fktable.concept_id
		where fktable.concept_id is null 
		  and cdmtable.measurement_source_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.measurement cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_DETAIL
cdmFieldName = PERSON_ID
fkTableName = PERSON
fkFieldName = PERSON_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'VISIT_DETAIL' cdmTableName,
'PERSON_ID' cdmFieldName,
'PERSON' fkTableName,
'PERSON_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'VISIT_DETAIL.PERSON_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
		  left join CY_IMOSPHERE_CDM_531.person fktable
		  on cdmtable.person_id = fktable.person_id
		where fktable.person_id is null 
		  and cdmtable.person_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = VISIT_DETAIL
cdmFieldName = VISIT_DETAIL_CONCEPT_ID
fkTableName = CONCEPT
fkFieldName = CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'VISIT_DETAIL' cdmTableName,
'VISIT_DETAIL_CONCEPT_ID' cdmFieldName,
'CONCEPT' fkTableName,
'CONCEPT_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'VISIT_DETAIL.VISIT_DETAIL_CONCEPT_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
		  left join CY_CDM_VOCAB.concept fktable
		  on cdmtable.visit_detail_concept_id = fktable.concept_id
		where fktable.concept_id is null 
		  and cdmtable.visit_detail_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = VISIT_DETAIL
cdmFieldName = VISIT_DETAIL_TYPE_CONCEPT_ID
fkTableName = CONCEPT
fkFieldName = CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'VISIT_DETAIL' cdmTableName,
'VISIT_DETAIL_TYPE_CONCEPT_ID' cdmFieldName,
'CONCEPT' fkTableName,
'CONCEPT_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'VISIT_DETAIL.VISIT_DETAIL_TYPE_CONCEPT_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
		  left join CY_CDM_VOCAB.concept fktable
		  on cdmtable.visit_detail_type_concept_id = fktable.concept_id
		where fktable.concept_id is null 
		  and cdmtable.visit_detail_type_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_DETAIL
cdmFieldName = PROVIDER_ID
fkTableName = PROVIDER
fkFieldName = PROVIDER_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'VISIT_DETAIL' cdmTableName,
'PROVIDER_ID' cdmFieldName,
'PROVIDER' fkTableName,
'PROVIDER_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'VISIT_DETAIL.PROVIDER_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
		  left join CY_IMOSPHERE_CDM_531.provider fktable
		  on cdmtable.provider_id = fktable.provider_id
		where fktable.provider_id is null 
		  and cdmtable.provider_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_DETAIL
cdmFieldName = CARE_SITE_ID
fkTableName = CARE_SITE
fkFieldName = CARE_SITE_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'VISIT_DETAIL' cdmTableName,
'CARE_SITE_ID' cdmFieldName,
'CARE_SITE' fkTableName,
'CARE_SITE_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'VISIT_DETAIL.CARE_SITE_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
		  left join CY_IMOSPHERE_CDM_531.care_site fktable
		  on cdmtable.care_site_id = fktable.care_site_id
		where fktable.care_site_id is null 
		  and cdmtable.care_site_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = VISIT_DETAIL
cdmFieldName = VISIT_DETAIL_SOURCE_CONCEPT_ID
fkTableName = CONCEPT
fkFieldName = CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'VISIT_DETAIL' cdmTableName,
'VISIT_DETAIL_SOURCE_CONCEPT_ID' cdmFieldName,
'CONCEPT' fkTableName,
'CONCEPT_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'VISIT_DETAIL.VISIT_DETAIL_SOURCE_CONCEPT_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
		  left join CY_CDM_VOCAB.concept fktable
		  on cdmtable.visit_detail_source_concept_id = fktable.concept_id
		where fktable.concept_id is null 
		  and cdmtable.visit_detail_source_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = VISIT_DETAIL
cdmFieldName = ADMITTING_SOURCE_CONCEPT_ID
fkTableName = CONCEPT
fkFieldName = CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'VISIT_DETAIL' cdmTableName,
'ADMITTING_SOURCE_CONCEPT_ID' cdmFieldName,
'CONCEPT' fkTableName,
'CONCEPT_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'VISIT_DETAIL.ADMITTING_SOURCE_CONCEPT_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
		  left join CY_CDM_VOCAB.concept fktable
		  on cdmtable.admitting_source_concept_id = fktable.concept_id
		where fktable.concept_id is null 
		  and cdmtable.admitting_source_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = VISIT_DETAIL
cdmFieldName = DISCHARGE_TO_CONCEPT_ID
fkTableName = CONCEPT
fkFieldName = CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'VISIT_DETAIL' cdmTableName,
'DISCHARGE_TO_CONCEPT_ID' cdmFieldName,
'CONCEPT' fkTableName,
'CONCEPT_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'VISIT_DETAIL.DISCHARGE_TO_CONCEPT_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
		  left join CY_CDM_VOCAB.concept fktable
		  on cdmtable.discharge_to_concept_id = fktable.concept_id
		where fktable.concept_id is null 
		  and cdmtable.discharge_to_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_DETAIL
cdmFieldName = PRECEDING_VISIT_DETAIL_ID
fkTableName = VISIT_DETAIL
fkFieldName = VISIT_DETAIL_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'VISIT_DETAIL' cdmTableName,
'PRECEDING_VISIT_DETAIL_ID' cdmFieldName,
'VISIT_DETAIL' fkTableName,
'VISIT_DETAIL_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'VISIT_DETAIL.PRECEDING_VISIT_DETAIL_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
		  left join CY_IMOSPHERE_CDM_531.visit_detail fktable
		  on cdmtable.preceding_visit_detail_id = fktable.visit_detail_id
		where fktable.visit_detail_id is null 
		  and cdmtable.preceding_visit_detail_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_DETAIL
cdmFieldName = VISIT_DETAIL_PARENT_ID
fkTableName = VISIT_DETAIL
fkFieldName = VISIT_DETAIL_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'VISIT_DETAIL' cdmTableName,
'VISIT_DETAIL_PARENT_ID' cdmFieldName,
'VISIT_DETAIL' fkTableName,
'VISIT_DETAIL_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'VISIT_DETAIL.VISIT_DETAIL_PARENT_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
		  left join CY_IMOSPHERE_CDM_531.visit_detail fktable
		  on cdmtable.visit_detail_parent_id = fktable.visit_detail_id
		where fktable.visit_detail_id is null 
		  and cdmtable.visit_detail_parent_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_DETAIL
cdmFieldName = VISIT_OCCURRENCE_ID
fkTableName = VISIT_OCCURRENCE
fkFieldName = VISIT_OCCURRENCE_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'VISIT_DETAIL' cdmTableName,
'VISIT_OCCURRENCE_ID' cdmFieldName,
'VISIT_OCCURRENCE' fkTableName,
'VISIT_OCCURRENCE_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'VISIT_DETAIL.VISIT_OCCURRENCE_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
		  left join CY_IMOSPHERE_CDM_531.visit_occurrence fktable
		  on cdmtable.visit_occurrence_id = fktable.visit_occurrence_id
		where fktable.visit_occurrence_id is null 
		  and cdmtable.visit_occurrence_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = NOTE
cdmFieldName = PERSON_ID
fkTableName = PERSON
fkFieldName = PERSON_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'NOTE' cdmTableName,
'PERSON_ID' cdmFieldName,
'PERSON' fkTableName,
'PERSON_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'NOTE.PERSON_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.note cdmtable
		  left join CY_IMOSPHERE_CDM_531.person fktable
		  on cdmtable.person_id = fktable.person_id
		where fktable.person_id is null 
		  and cdmtable.person_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.note cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = NOTE
cdmFieldName = NOTE_TYPE_CONCEPT_ID
fkTableName = CONCEPT
fkFieldName = CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'NOTE' cdmTableName,
'NOTE_TYPE_CONCEPT_ID' cdmFieldName,
'CONCEPT' fkTableName,
'CONCEPT_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'NOTE.NOTE_TYPE_CONCEPT_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.note cdmtable
		  left join CY_CDM_VOCAB.concept fktable
		  on cdmtable.note_type_concept_id = fktable.concept_id
		where fktable.concept_id is null 
		  and cdmtable.note_type_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.note cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = NOTE
cdmFieldName = NOTE_CLASS_CONCEPT_ID
fkTableName = CONCEPT
fkFieldName = CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'NOTE' cdmTableName,
'NOTE_CLASS_CONCEPT_ID' cdmFieldName,
'CONCEPT' fkTableName,
'CONCEPT_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'NOTE.NOTE_CLASS_CONCEPT_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.note cdmtable
		  left join CY_CDM_VOCAB.concept fktable
		  on cdmtable.note_class_concept_id = fktable.concept_id
		where fktable.concept_id is null 
		  and cdmtable.note_class_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.note cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = NOTE
cdmFieldName = ENCODING_CONCEPT_ID
fkTableName = CONCEPT
fkFieldName = CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'NOTE' cdmTableName,
'ENCODING_CONCEPT_ID' cdmFieldName,
'CONCEPT' fkTableName,
'CONCEPT_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'NOTE.ENCODING_CONCEPT_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.note cdmtable
		  left join CY_CDM_VOCAB.concept fktable
		  on cdmtable.encoding_concept_id = fktable.concept_id
		where fktable.concept_id is null 
		  and cdmtable.encoding_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.note cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = NOTE
cdmFieldName = LANGUAGE_CONCEPT_ID
fkTableName = CONCEPT
fkFieldName = CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'NOTE' cdmTableName,
'LANGUAGE_CONCEPT_ID' cdmFieldName,
'CONCEPT' fkTableName,
'CONCEPT_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'NOTE.LANGUAGE_CONCEPT_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.note cdmtable
		  left join CY_CDM_VOCAB.concept fktable
		  on cdmtable.language_concept_id = fktable.concept_id
		where fktable.concept_id is null 
		  and cdmtable.language_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.note cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = NOTE
cdmFieldName = PROVIDER_ID
fkTableName = PROVIDER
fkFieldName = PROVIDER_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'NOTE' cdmTableName,
'PROVIDER_ID' cdmFieldName,
'PROVIDER' fkTableName,
'PROVIDER_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'NOTE.PROVIDER_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.note cdmtable
		  left join CY_IMOSPHERE_CDM_531.provider fktable
		  on cdmtable.provider_id = fktable.provider_id
		where fktable.provider_id is null 
		  and cdmtable.provider_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.note cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = NOTE
cdmFieldName = VISIT_OCCURRENCE_ID
fkTableName = VISIT_OCCURRENCE
fkFieldName = VISIT_OCCURRENCE_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'NOTE' cdmTableName,
'VISIT_OCCURRENCE_ID' cdmFieldName,
'VISIT_OCCURRENCE' fkTableName,
'VISIT_OCCURRENCE_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'NOTE.VISIT_OCCURRENCE_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.note cdmtable
		  left join CY_IMOSPHERE_CDM_531.visit_occurrence fktable
		  on cdmtable.visit_occurrence_id = fktable.visit_occurrence_id
		where fktable.visit_occurrence_id is null 
		  and cdmtable.visit_occurrence_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.note cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = NOTE
cdmFieldName = VISIT_DETAIL_ID
fkTableName = VISIT_DETAIL
fkFieldName = VISIT_DETAIL_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'NOTE' cdmTableName,
'VISIT_DETAIL_ID' cdmFieldName,
'VISIT_DETAIL' fkTableName,
'VISIT_DETAIL_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'NOTE.VISIT_DETAIL_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.note cdmtable
		  left join CY_IMOSPHERE_CDM_531.visit_detail fktable
		  on cdmtable.visit_detail_id = fktable.visit_detail_id
		where fktable.visit_detail_id is null 
		  and cdmtable.visit_detail_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.note cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = NOTE_NLP
cdmFieldName = NOTE_ID
fkTableName = NOTE
fkFieldName = NOTE_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'NOTE_NLP' cdmTableName,
'NOTE_ID' cdmFieldName,
'NOTE' fkTableName,
'NOTE_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'NOTE_NLP.NOTE_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.note_nlp cdmtable
		  left join CY_IMOSPHERE_CDM_531.note fktable
		  on cdmtable.note_id = fktable.note_id
		where fktable.note_id is null 
		  and cdmtable.note_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.note_nlp cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = NOTE_NLP
cdmFieldName = SECTION_CONCEPT_ID
fkTableName = CONCEPT
fkFieldName = CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'NOTE_NLP' cdmTableName,
'SECTION_CONCEPT_ID' cdmFieldName,
'CONCEPT' fkTableName,
'CONCEPT_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'NOTE_NLP.SECTION_CONCEPT_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.note_nlp cdmtable
		  left join CY_CDM_VOCAB.concept fktable
		  on cdmtable.section_concept_id = fktable.concept_id
		where fktable.concept_id is null 
		  and cdmtable.section_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.note_nlp cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = NOTE_NLP
cdmFieldName = NOTE_NLP_CONCEPT_ID
fkTableName = CONCEPT
fkFieldName = CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'NOTE_NLP' cdmTableName,
'NOTE_NLP_CONCEPT_ID' cdmFieldName,
'CONCEPT' fkTableName,
'CONCEPT_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'NOTE_NLP.NOTE_NLP_CONCEPT_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.note_nlp cdmtable
		  left join CY_CDM_VOCAB.concept fktable
		  on cdmtable.note_nlp_concept_id = fktable.concept_id
		where fktable.concept_id is null 
		  and cdmtable.note_nlp_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.note_nlp cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = NOTE_NLP
cdmFieldName = NOTE_NLP_SOURCE_CONCEPT_ID
fkTableName = CONCEPT
fkFieldName = CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'NOTE_NLP' cdmTableName,
'NOTE_NLP_SOURCE_CONCEPT_ID' cdmFieldName,
'CONCEPT' fkTableName,
'CONCEPT_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'NOTE_NLP.NOTE_NLP_SOURCE_CONCEPT_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.note_nlp cdmtable
		  left join CY_CDM_VOCAB.concept fktable
		  on cdmtable.note_nlp_source_concept_id = fktable.concept_id
		where fktable.concept_id is null 
		  and cdmtable.note_nlp_source_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.note_nlp cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = OBSERVATION
cdmFieldName = PERSON_ID
fkTableName = PERSON
fkFieldName = PERSON_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'OBSERVATION' cdmTableName,
'PERSON_ID' cdmFieldName,
'PERSON' fkTableName,
'PERSON_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'OBSERVATION.PERSON_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.observation cdmtable
		  left join CY_IMOSPHERE_CDM_531.person fktable
		  on cdmtable.person_id = fktable.person_id
		where fktable.person_id is null 
		  and cdmtable.person_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.observation cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = OBSERVATION
cdmFieldName = OBSERVATION_CONCEPT_ID
fkTableName = CONCEPT
fkFieldName = CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'OBSERVATION' cdmTableName,
'OBSERVATION_CONCEPT_ID' cdmFieldName,
'CONCEPT' fkTableName,
'CONCEPT_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'OBSERVATION.OBSERVATION_CONCEPT_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.observation cdmtable
		  left join CY_CDM_VOCAB.concept fktable
		  on cdmtable.observation_concept_id = fktable.concept_id
		where fktable.concept_id is null 
		  and cdmtable.observation_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.observation cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = OBSERVATION
cdmFieldName = OBSERVATION_TYPE_CONCEPT_ID
fkTableName = CONCEPT
fkFieldName = CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'OBSERVATION' cdmTableName,
'OBSERVATION_TYPE_CONCEPT_ID' cdmFieldName,
'CONCEPT' fkTableName,
'CONCEPT_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'OBSERVATION.OBSERVATION_TYPE_CONCEPT_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.observation cdmtable
		  left join CY_CDM_VOCAB.concept fktable
		  on cdmtable.observation_type_concept_id = fktable.concept_id
		where fktable.concept_id is null 
		  and cdmtable.observation_type_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.observation cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = OBSERVATION
cdmFieldName = VALUE_AS_CONCEPT_ID
fkTableName = CONCEPT
fkFieldName = CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'OBSERVATION' cdmTableName,
'VALUE_AS_CONCEPT_ID' cdmFieldName,
'CONCEPT' fkTableName,
'CONCEPT_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'OBSERVATION.VALUE_AS_CONCEPT_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.observation cdmtable
		  left join CY_CDM_VOCAB.concept fktable
		  on cdmtable.value_as_concept_id = fktable.concept_id
		where fktable.concept_id is null 
		  and cdmtable.value_as_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.observation cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = OBSERVATION
cdmFieldName = QUALIFIER_CONCEPT_ID
fkTableName = CONCEPT
fkFieldName = CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'OBSERVATION' cdmTableName,
'QUALIFIER_CONCEPT_ID' cdmFieldName,
'CONCEPT' fkTableName,
'CONCEPT_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'OBSERVATION.QUALIFIER_CONCEPT_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.observation cdmtable
		  left join CY_CDM_VOCAB.concept fktable
		  on cdmtable.qualifier_concept_id = fktable.concept_id
		where fktable.concept_id is null 
		  and cdmtable.qualifier_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.observation cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = OBSERVATION
cdmFieldName = UNIT_CONCEPT_ID
fkTableName = CONCEPT
fkFieldName = CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'OBSERVATION' cdmTableName,
'UNIT_CONCEPT_ID' cdmFieldName,
'CONCEPT' fkTableName,
'CONCEPT_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'OBSERVATION.UNIT_CONCEPT_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.observation cdmtable
		  left join CY_CDM_VOCAB.concept fktable
		  on cdmtable.unit_concept_id = fktable.concept_id
		where fktable.concept_id is null 
		  and cdmtable.unit_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.observation cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = OBSERVATION
cdmFieldName = PROVIDER_ID
fkTableName = PROVIDER
fkFieldName = PROVIDER_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'OBSERVATION' cdmTableName,
'PROVIDER_ID' cdmFieldName,
'PROVIDER' fkTableName,
'PROVIDER_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'OBSERVATION.PROVIDER_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.observation cdmtable
		  left join CY_IMOSPHERE_CDM_531.provider fktable
		  on cdmtable.provider_id = fktable.provider_id
		where fktable.provider_id is null 
		  and cdmtable.provider_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.observation cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = OBSERVATION
cdmFieldName = VISIT_OCCURRENCE_ID
fkTableName = VISIT_OCCURRENCE
fkFieldName = VISIT_OCCURRENCE_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'OBSERVATION' cdmTableName,
'VISIT_OCCURRENCE_ID' cdmFieldName,
'VISIT_OCCURRENCE' fkTableName,
'VISIT_OCCURRENCE_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'OBSERVATION.VISIT_OCCURRENCE_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.observation cdmtable
		  left join CY_IMOSPHERE_CDM_531.visit_occurrence fktable
		  on cdmtable.visit_occurrence_id = fktable.visit_occurrence_id
		where fktable.visit_occurrence_id is null 
		  and cdmtable.visit_occurrence_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.observation cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = OBSERVATION
cdmFieldName = VISIT_DETAIL_ID
fkTableName = VISIT_DETAIL
fkFieldName = VISIT_DETAIL_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'OBSERVATION' cdmTableName,
'VISIT_DETAIL_ID' cdmFieldName,
'VISIT_DETAIL' fkTableName,
'VISIT_DETAIL_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'OBSERVATION.VISIT_DETAIL_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.observation cdmtable
		  left join CY_IMOSPHERE_CDM_531.visit_detail fktable
		  on cdmtable.visit_detail_id = fktable.visit_detail_id
		where fktable.visit_detail_id is null 
		  and cdmtable.visit_detail_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.observation cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = OBSERVATION
cdmFieldName = OBSERVATION_SOURCE_CONCEPT_ID
fkTableName = CONCEPT
fkFieldName = CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'OBSERVATION' cdmTableName,
'OBSERVATION_SOURCE_CONCEPT_ID' cdmFieldName,
'CONCEPT' fkTableName,
'CONCEPT_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'OBSERVATION.OBSERVATION_SOURCE_CONCEPT_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.observation cdmtable
		  left join CY_CDM_VOCAB.concept fktable
		  on cdmtable.observation_source_concept_id = fktable.concept_id
		where fktable.concept_id is null 
		  and cdmtable.observation_source_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.observation cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = FACT_RELATIONSHIP
cdmFieldName = DOMAIN_CONCEPT_ID_1
fkTableName = CONCEPT
fkFieldName = CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'FACT_RELATIONSHIP' cdmTableName,
'DOMAIN_CONCEPT_ID_1' cdmFieldName,
'CONCEPT' fkTableName,
'CONCEPT_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'FACT_RELATIONSHIP.DOMAIN_CONCEPT_ID_1' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.fact_relationship cdmtable
		  left join CY_CDM_VOCAB.concept fktable
		  on cdmtable.domain_concept_id_1 = fktable.concept_id
		where fktable.concept_id is null 
		  and cdmtable.domain_concept_id_1 is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.fact_relationship cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = FACT_RELATIONSHIP
cdmFieldName = DOMAIN_CONCEPT_ID_2
fkTableName = CONCEPT
fkFieldName = CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'FACT_RELATIONSHIP' cdmTableName,
'DOMAIN_CONCEPT_ID_2' cdmFieldName,
'CONCEPT' fkTableName,
'CONCEPT_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'FACT_RELATIONSHIP.DOMAIN_CONCEPT_ID_2' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.fact_relationship cdmtable
		  left join CY_CDM_VOCAB.concept fktable
		  on cdmtable.domain_concept_id_2 = fktable.concept_id
		where fktable.concept_id is null 
		  and cdmtable.domain_concept_id_2 is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.fact_relationship cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = FACT_RELATIONSHIP
cdmFieldName = RELATIONSHIP_CONCEPT_ID
fkTableName = CONCEPT
fkFieldName = CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'FACT_RELATIONSHIP' cdmTableName,
'RELATIONSHIP_CONCEPT_ID' cdmFieldName,
'CONCEPT' fkTableName,
'CONCEPT_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'FACT_RELATIONSHIP.RELATIONSHIP_CONCEPT_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.fact_relationship cdmtable
		  left join CY_CDM_VOCAB.concept fktable
		  on cdmtable.relationship_concept_id = fktable.concept_id
		where fktable.concept_id is null 
		  and cdmtable.relationship_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.fact_relationship cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = CARE_SITE
cdmFieldName = PLACE_OF_SERVICE_CONCEPT_ID
fkTableName = CONCEPT
fkFieldName = CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'CARE_SITE' cdmTableName,
'PLACE_OF_SERVICE_CONCEPT_ID' cdmFieldName,
'CONCEPT' fkTableName,
'CONCEPT_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'CARE_SITE.PLACE_OF_SERVICE_CONCEPT_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.care_site cdmtable
		  left join CY_CDM_VOCAB.concept fktable
		  on cdmtable.place_of_service_concept_id = fktable.concept_id
		where fktable.concept_id is null 
		  and cdmtable.place_of_service_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.care_site cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CARE_SITE
cdmFieldName = LOCATION_ID
fkTableName = LOCATION
fkFieldName = LOCATION_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'CARE_SITE' cdmTableName,
'LOCATION_ID' cdmFieldName,
'LOCATION' fkTableName,
'LOCATION_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'CARE_SITE.LOCATION_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.care_site cdmtable
		  left join CY_IMOSPHERE_CDM_531.location fktable
		  on cdmtable.location_id = fktable.location_id
		where fktable.location_id is null 
		  and cdmtable.location_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.care_site cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = PROVIDER
cdmFieldName = SPECIALTY_CONCEPT_ID
fkTableName = CONCEPT
fkFieldName = CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'PROVIDER' cdmTableName,
'SPECIALTY_CONCEPT_ID' cdmFieldName,
'CONCEPT' fkTableName,
'CONCEPT_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'PROVIDER.SPECIALTY_CONCEPT_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.provider cdmtable
		  left join CY_CDM_VOCAB.concept fktable
		  on cdmtable.specialty_concept_id = fktable.concept_id
		where fktable.concept_id is null 
		  and cdmtable.specialty_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.provider cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROVIDER
cdmFieldName = CARE_SITE_ID
fkTableName = CARE_SITE
fkFieldName = CARE_SITE_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'PROVIDER' cdmTableName,
'CARE_SITE_ID' cdmFieldName,
'CARE_SITE' fkTableName,
'CARE_SITE_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'PROVIDER.CARE_SITE_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.provider cdmtable
		  left join CY_IMOSPHERE_CDM_531.care_site fktable
		  on cdmtable.care_site_id = fktable.care_site_id
		where fktable.care_site_id is null 
		  and cdmtable.care_site_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.provider cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = PROVIDER
cdmFieldName = GENDER_CONCEPT_ID
fkTableName = CONCEPT
fkFieldName = CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'PROVIDER' cdmTableName,
'GENDER_CONCEPT_ID' cdmFieldName,
'CONCEPT' fkTableName,
'CONCEPT_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'PROVIDER.GENDER_CONCEPT_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.provider cdmtable
		  left join CY_CDM_VOCAB.concept fktable
		  on cdmtable.gender_concept_id = fktable.concept_id
		where fktable.concept_id is null 
		  and cdmtable.gender_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.provider cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = PROVIDER
cdmFieldName = SPECIALTY_SOURCE_CONCEPT_ID
fkTableName = CONCEPT
fkFieldName = CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'PROVIDER' cdmTableName,
'SPECIALTY_SOURCE_CONCEPT_ID' cdmFieldName,
'CONCEPT' fkTableName,
'CONCEPT_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'PROVIDER.SPECIALTY_SOURCE_CONCEPT_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.provider cdmtable
		  left join CY_CDM_VOCAB.concept fktable
		  on cdmtable.specialty_source_concept_id = fktable.concept_id
		where fktable.concept_id is null 
		  and cdmtable.specialty_source_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.provider cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = PROVIDER
cdmFieldName = GENDER_SOURCE_CONCEPT_ID
fkTableName = CONCEPT
fkFieldName = CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'PROVIDER' cdmTableName,
'GENDER_SOURCE_CONCEPT_ID' cdmFieldName,
'CONCEPT' fkTableName,
'CONCEPT_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'PROVIDER.GENDER_SOURCE_CONCEPT_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.provider cdmtable
		  left join CY_CDM_VOCAB.concept fktable
		  on cdmtable.gender_source_concept_id = fktable.concept_id
		where fktable.concept_id is null 
		  and cdmtable.gender_source_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.provider cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PAYER_PLAN_PERIOD
cdmFieldName = PERSON_ID
fkTableName = PERSON
fkFieldName = PERSON_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'PAYER_PLAN_PERIOD' cdmTableName,
'PERSON_ID' cdmFieldName,
'PERSON' fkTableName,
'PERSON_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'PAYER_PLAN_PERIOD.PERSON_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.payer_plan_period cdmtable
		  left join CY_IMOSPHERE_CDM_531.person fktable
		  on cdmtable.person_id = fktable.person_id
		where fktable.person_id is null 
		  and cdmtable.person_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.payer_plan_period cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = PAYER_PLAN_PERIOD
cdmFieldName = PAYER_CONCEPT_ID
fkTableName = CONCEPT
fkFieldName = CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'PAYER_PLAN_PERIOD' cdmTableName,
'PAYER_CONCEPT_ID' cdmFieldName,
'CONCEPT' fkTableName,
'CONCEPT_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'PAYER_PLAN_PERIOD.PAYER_CONCEPT_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.payer_plan_period cdmtable
		  left join CY_CDM_VOCAB.concept fktable
		  on cdmtable.payer_concept_id = fktable.concept_id
		where fktable.concept_id is null 
		  and cdmtable.payer_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.payer_plan_period cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = PAYER_PLAN_PERIOD
cdmFieldName = PAYER_SOURCE_CONCEPT_ID
fkTableName = CONCEPT
fkFieldName = CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'PAYER_PLAN_PERIOD' cdmTableName,
'PAYER_SOURCE_CONCEPT_ID' cdmFieldName,
'CONCEPT' fkTableName,
'CONCEPT_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'PAYER_PLAN_PERIOD.PAYER_SOURCE_CONCEPT_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.payer_plan_period cdmtable
		  left join CY_CDM_VOCAB.concept fktable
		  on cdmtable.payer_source_concept_id = fktable.concept_id
		where fktable.concept_id is null 
		  and cdmtable.payer_source_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.payer_plan_period cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = PAYER_PLAN_PERIOD
cdmFieldName = PLAN_CONCEPT_ID
fkTableName = CONCEPT
fkFieldName = CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'PAYER_PLAN_PERIOD' cdmTableName,
'PLAN_CONCEPT_ID' cdmFieldName,
'CONCEPT' fkTableName,
'CONCEPT_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'PAYER_PLAN_PERIOD.PLAN_CONCEPT_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.payer_plan_period cdmtable
		  left join CY_CDM_VOCAB.concept fktable
		  on cdmtable.plan_concept_id = fktable.concept_id
		where fktable.concept_id is null 
		  and cdmtable.plan_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.payer_plan_period cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = PAYER_PLAN_PERIOD
cdmFieldName = PLAN_SOURCE_CONCEPT_ID
fkTableName = CONCEPT
fkFieldName = CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'PAYER_PLAN_PERIOD' cdmTableName,
'PLAN_SOURCE_CONCEPT_ID' cdmFieldName,
'CONCEPT' fkTableName,
'CONCEPT_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'PAYER_PLAN_PERIOD.PLAN_SOURCE_CONCEPT_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.payer_plan_period cdmtable
		  left join CY_CDM_VOCAB.concept fktable
		  on cdmtable.plan_source_concept_id = fktable.concept_id
		where fktable.concept_id is null 
		  and cdmtable.plan_source_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.payer_plan_period cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = PAYER_PLAN_PERIOD
cdmFieldName = SPONSOR_CONCEPT_ID
fkTableName = CONCEPT
fkFieldName = CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'PAYER_PLAN_PERIOD' cdmTableName,
'SPONSOR_CONCEPT_ID' cdmFieldName,
'CONCEPT' fkTableName,
'CONCEPT_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'PAYER_PLAN_PERIOD.SPONSOR_CONCEPT_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.payer_plan_period cdmtable
		  left join CY_CDM_VOCAB.concept fktable
		  on cdmtable.sponsor_concept_id = fktable.concept_id
		where fktable.concept_id is null 
		  and cdmtable.sponsor_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.payer_plan_period cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = PAYER_PLAN_PERIOD
cdmFieldName = SPONSOR_SOURCE_CONCEPT_ID
fkTableName = CONCEPT
fkFieldName = CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'PAYER_PLAN_PERIOD' cdmTableName,
'SPONSOR_SOURCE_CONCEPT_ID' cdmFieldName,
'CONCEPT' fkTableName,
'CONCEPT_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'PAYER_PLAN_PERIOD.SPONSOR_SOURCE_CONCEPT_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.payer_plan_period cdmtable
		  left join CY_CDM_VOCAB.concept fktable
		  on cdmtable.sponsor_source_concept_id = fktable.concept_id
		where fktable.concept_id is null 
		  and cdmtable.sponsor_source_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.payer_plan_period cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = PAYER_PLAN_PERIOD
cdmFieldName = STOP_REASON_CONCEPT_ID
fkTableName = CONCEPT
fkFieldName = CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'PAYER_PLAN_PERIOD' cdmTableName,
'STOP_REASON_CONCEPT_ID' cdmFieldName,
'CONCEPT' fkTableName,
'CONCEPT_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'PAYER_PLAN_PERIOD.STOP_REASON_CONCEPT_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.payer_plan_period cdmtable
		  left join CY_CDM_VOCAB.concept fktable
		  on cdmtable.stop_reason_concept_id = fktable.concept_id
		where fktable.concept_id is null 
		  and cdmtable.stop_reason_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.payer_plan_period cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = PAYER_PLAN_PERIOD
cdmFieldName = STOP_REASON_SOURCE_CONCEPT_ID
fkTableName = CONCEPT
fkFieldName = CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'PAYER_PLAN_PERIOD' cdmTableName,
'STOP_REASON_SOURCE_CONCEPT_ID' cdmFieldName,
'CONCEPT' fkTableName,
'CONCEPT_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'PAYER_PLAN_PERIOD.STOP_REASON_SOURCE_CONCEPT_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.payer_plan_period cdmtable
		  left join CY_CDM_VOCAB.concept fktable
		  on cdmtable.stop_reason_source_concept_id = fktable.concept_id
		where fktable.concept_id is null 
		  and cdmtable.stop_reason_source_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.payer_plan_period cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DRUG_ERA
cdmFieldName = PERSON_ID
fkTableName = PERSON
fkFieldName = PERSON_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'DRUG_ERA' cdmTableName,
'PERSON_ID' cdmFieldName,
'PERSON' fkTableName,
'PERSON_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'DRUG_ERA.PERSON_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.drug_era cdmtable
		  left join CY_IMOSPHERE_CDM_531.person fktable
		  on cdmtable.person_id = fktable.person_id
		where fktable.person_id is null 
		  and cdmtable.person_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.drug_era cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = DRUG_ERA
cdmFieldName = DRUG_CONCEPT_ID
fkTableName = CONCEPT
fkFieldName = CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'DRUG_ERA' cdmTableName,
'DRUG_CONCEPT_ID' cdmFieldName,
'CONCEPT' fkTableName,
'CONCEPT_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'DRUG_ERA.DRUG_CONCEPT_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.drug_era cdmtable
		  left join CY_CDM_VOCAB.concept fktable
		  on cdmtable.drug_concept_id = fktable.concept_id
		where fktable.concept_id is null 
		  and cdmtable.drug_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.drug_era cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_ERA
cdmFieldName = PERSON_ID
fkTableName = PERSON
fkFieldName = PERSON_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'CONDITION_ERA' cdmTableName,
'PERSON_ID' cdmFieldName,
'PERSON' fkTableName,
'PERSON_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'CONDITION_ERA.PERSON_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.condition_era cdmtable
		  left join CY_IMOSPHERE_CDM_531.person fktable
		  on cdmtable.person_id = fktable.person_id
		where fktable.person_id is null 
		  and cdmtable.person_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_era cdmtable
) denominator
;

/*********
IS_FOREIGN_KEY
Foreign key check
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_CDM_VOCAB
cdmTableName = CONDITION_ERA
cdmFieldName = CONDITION_CONCEPT_ID
fkTableName = CONCEPT
fkFieldName = CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
fkTableName,
fkFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'IS_FOREIGN_KEY' level,
    'Foreign key' check,
    'CONDITION_ERA' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'CONCEPT' fkTableName,
'CONCEPT_ID' fkFieldName,
       num_violated_rows,
  case
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows
  end as pct_violated_rows,
  denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'CONDITION_ERA.CONDITION_CONCEPT_ID' as violating_field, 
		  cdmtable.*
		from CY_IMOSPHERE_CDM_531.condition_era cdmtable
		  left join CY_CDM_VOCAB.concept fktable
		  on cdmtable.condition_concept_id = fktable.concept_id
		where fktable.concept_id is null 
		  and cdmtable.condition_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_era cdmtable
) denominator
;

