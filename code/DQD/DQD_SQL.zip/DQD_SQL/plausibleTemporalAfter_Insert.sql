/*********
PLAUSIBLE_TEMPORAL_AFTER
get number of records and the proportion to total number of eligible records with datetimes that do not occur on or after their corresponding datetimes
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = OBSERVATION_PERIOD
cdmFieldName = OBSERVATION_PERIOD_START_DATE
plausibleTemporalAfterTableName = PERSON
plausibleTemporalAfterFieldName = BIRTH_DATETIME
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
plausibleTemporalAfterTableName,
plausibleTemporalAfterFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'PLAUSIBLE_TEMPORAL_AFTER' level,
    'get number of records and the proportion to total number of eligible records with datetimes that do not occur on or after their corresponding datetimes' check,
    'OBSERVATION_PERIOD' cdmTableName,
'OBSERVATION_PERIOD_START_DATE' cdmFieldName,
'PERSON' plausibleTemporalAfterTableName,
'BIRTH_DATETIME' plausibleTemporalAfterFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'OBSERVATION_PERIOD.OBSERVATION_PERIOD_START_DATE' as violating_field, 
			cdmtable.*
    	from CY_IMOSPHERE_CDM_531.observation_period cdmtable
				join CY_IMOSPHERE_CDM_531.person plausibletable on cdmtable.person_id = plausibletable.person_id
    where 
			coalesce(
				IF(SAFE_CAST(plausibletable.birth_datetime  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(plausibletable.birth_datetime  AS STRING)),SAFE_CAST(plausibletable.birth_datetime  AS DATE)),
				parse_date('%Y%m%d', concat(plausibletable.year_of_birth,'-06-01'))
			) 
		 > IF(SAFE_CAST(cdmtable.observation_period_start_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.observation_period_start_date  AS STRING)),SAFE_CAST(cdmtable.observation_period_start_date  AS DATE))
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.observation_period cdmtable
) denominator
;

/*********
PLAUSIBLE_TEMPORAL_AFTER
get number of records and the proportion to total number of eligible records with datetimes that do not occur on or after their corresponding datetimes
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = OBSERVATION_PERIOD
cdmFieldName = OBSERVATION_PERIOD_END_DATE
plausibleTemporalAfterTableName = OBSERVATION_PERIOD
plausibleTemporalAfterFieldName = OBSERVATION_PERIOD_START_DATE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
plausibleTemporalAfterTableName,
plausibleTemporalAfterFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'PLAUSIBLE_TEMPORAL_AFTER' level,
    'get number of records and the proportion to total number of eligible records with datetimes that do not occur on or after their corresponding datetimes' check,
    'OBSERVATION_PERIOD' cdmTableName,
'OBSERVATION_PERIOD_END_DATE' cdmFieldName,
'OBSERVATION_PERIOD' plausibleTemporalAfterTableName,
'OBSERVATION_PERIOD_START_DATE' plausibleTemporalAfterFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'OBSERVATION_PERIOD.OBSERVATION_PERIOD_END_DATE' as violating_field, 
			cdmtable.*
    	from CY_IMOSPHERE_CDM_531.observation_period cdmtable
    where 
			IF(SAFE_CAST(cdmtable.observation_period_start_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.observation_period_start_date  AS STRING)),SAFE_CAST(cdmtable.observation_period_start_date  AS DATE))
		 > IF(SAFE_CAST(cdmtable.observation_period_end_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.observation_period_end_date  AS STRING)),SAFE_CAST(cdmtable.observation_period_end_date  AS DATE))
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.observation_period cdmtable
) denominator
;

/*********
PLAUSIBLE_TEMPORAL_AFTER
get number of records and the proportion to total number of eligible records with datetimes that do not occur on or after their corresponding datetimes
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_OCCURRENCE
cdmFieldName = VISIT_START_DATE
plausibleTemporalAfterTableName = PERSON
plausibleTemporalAfterFieldName = BIRTH_DATETIME
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
plausibleTemporalAfterTableName,
plausibleTemporalAfterFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'PLAUSIBLE_TEMPORAL_AFTER' level,
    'get number of records and the proportion to total number of eligible records with datetimes that do not occur on or after their corresponding datetimes' check,
    'VISIT_OCCURRENCE' cdmTableName,
'VISIT_START_DATE' cdmFieldName,
'PERSON' plausibleTemporalAfterTableName,
'BIRTH_DATETIME' plausibleTemporalAfterFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'VISIT_OCCURRENCE.VISIT_START_DATE' as violating_field, 
			cdmtable.*
    	from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
				join CY_IMOSPHERE_CDM_531.person plausibletable on cdmtable.person_id = plausibletable.person_id
    where 
			coalesce(
				IF(SAFE_CAST(plausibletable.birth_datetime  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(plausibletable.birth_datetime  AS STRING)),SAFE_CAST(plausibletable.birth_datetime  AS DATE)),
				parse_date('%Y%m%d', concat(plausibletable.year_of_birth,'-06-01'))
			) 
		 > IF(SAFE_CAST(cdmtable.visit_start_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.visit_start_date  AS STRING)),SAFE_CAST(cdmtable.visit_start_date  AS DATE))
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
) denominator
;

/*********
PLAUSIBLE_TEMPORAL_AFTER
get number of records and the proportion to total number of eligible records with datetimes that do not occur on or after their corresponding datetimes
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_OCCURRENCE
cdmFieldName = VISIT_START_DATETIME
plausibleTemporalAfterTableName = PERSON
plausibleTemporalAfterFieldName = BIRTH_DATETIME
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
plausibleTemporalAfterTableName,
plausibleTemporalAfterFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'PLAUSIBLE_TEMPORAL_AFTER' level,
    'get number of records and the proportion to total number of eligible records with datetimes that do not occur on or after their corresponding datetimes' check,
    'VISIT_OCCURRENCE' cdmTableName,
'VISIT_START_DATETIME' cdmFieldName,
'PERSON' plausibleTemporalAfterTableName,
'BIRTH_DATETIME' plausibleTemporalAfterFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'VISIT_OCCURRENCE.VISIT_START_DATETIME' as violating_field, 
			cdmtable.*
    	from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
				join CY_IMOSPHERE_CDM_531.person plausibletable on cdmtable.person_id = plausibletable.person_id
    where 
			coalesce(
				IF(SAFE_CAST(plausibletable.birth_datetime  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(plausibletable.birth_datetime  AS STRING)),SAFE_CAST(plausibletable.birth_datetime  AS DATE)),
				parse_date('%Y%m%d', concat(plausibletable.year_of_birth,'-06-01'))
			) 
		 > IF(SAFE_CAST(cdmtable.visit_start_datetime  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.visit_start_datetime  AS STRING)),SAFE_CAST(cdmtable.visit_start_datetime  AS DATE))
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
) denominator
;

/*********
PLAUSIBLE_TEMPORAL_AFTER
get number of records and the proportion to total number of eligible records with datetimes that do not occur on or after their corresponding datetimes
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_OCCURRENCE
cdmFieldName = VISIT_END_DATE
plausibleTemporalAfterTableName = VISIT_OCCURRENCE
plausibleTemporalAfterFieldName = VISIT_START_DATE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
plausibleTemporalAfterTableName,
plausibleTemporalAfterFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'PLAUSIBLE_TEMPORAL_AFTER' level,
    'get number of records and the proportion to total number of eligible records with datetimes that do not occur on or after their corresponding datetimes' check,
    'VISIT_OCCURRENCE' cdmTableName,
'VISIT_END_DATE' cdmFieldName,
'VISIT_OCCURRENCE' plausibleTemporalAfterTableName,
'VISIT_START_DATE' plausibleTemporalAfterFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'VISIT_OCCURRENCE.VISIT_END_DATE' as violating_field, 
			cdmtable.*
    	from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
    where 
			IF(SAFE_CAST(cdmtable.visit_start_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.visit_start_date  AS STRING)),SAFE_CAST(cdmtable.visit_start_date  AS DATE))
		 > IF(SAFE_CAST(cdmtable.visit_end_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.visit_end_date  AS STRING)),SAFE_CAST(cdmtable.visit_end_date  AS DATE))
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
) denominator
;

/*********
PLAUSIBLE_TEMPORAL_AFTER
get number of records and the proportion to total number of eligible records with datetimes that do not occur on or after their corresponding datetimes
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_OCCURRENCE
cdmFieldName = VISIT_END_DATETIME
plausibleTemporalAfterTableName = VISIT_OCCURRENCE
plausibleTemporalAfterFieldName = VISIT_START_DATETIME
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
plausibleTemporalAfterTableName,
plausibleTemporalAfterFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'PLAUSIBLE_TEMPORAL_AFTER' level,
    'get number of records and the proportion to total number of eligible records with datetimes that do not occur on or after their corresponding datetimes' check,
    'VISIT_OCCURRENCE' cdmTableName,
'VISIT_END_DATETIME' cdmFieldName,
'VISIT_OCCURRENCE' plausibleTemporalAfterTableName,
'VISIT_START_DATETIME' plausibleTemporalAfterFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'VISIT_OCCURRENCE.VISIT_END_DATETIME' as violating_field, 
			cdmtable.*
    	from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
    where 
			IF(SAFE_CAST(cdmtable.visit_start_datetime  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.visit_start_datetime  AS STRING)),SAFE_CAST(cdmtable.visit_start_datetime  AS DATE))
		 > IF(SAFE_CAST(cdmtable.visit_end_datetime  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.visit_end_datetime  AS STRING)),SAFE_CAST(cdmtable.visit_end_datetime  AS DATE))
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
) denominator
;

/*********
PLAUSIBLE_TEMPORAL_AFTER
get number of records and the proportion to total number of eligible records with datetimes that do not occur on or after their corresponding datetimes
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_START_DATE
plausibleTemporalAfterTableName = PERSON
plausibleTemporalAfterFieldName = BIRTH_DATETIME
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
plausibleTemporalAfterTableName,
plausibleTemporalAfterFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'PLAUSIBLE_TEMPORAL_AFTER' level,
    'get number of records and the proportion to total number of eligible records with datetimes that do not occur on or after their corresponding datetimes' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_START_DATE' cdmFieldName,
'PERSON' plausibleTemporalAfterTableName,
'BIRTH_DATETIME' plausibleTemporalAfterFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'CONDITION_OCCURRENCE.CONDITION_START_DATE' as violating_field, 
			cdmtable.*
    	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
				join CY_IMOSPHERE_CDM_531.person plausibletable on cdmtable.person_id = plausibletable.person_id
    where 
			coalesce(
				IF(SAFE_CAST(plausibletable.birth_datetime  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(plausibletable.birth_datetime  AS STRING)),SAFE_CAST(plausibletable.birth_datetime  AS DATE)),
				parse_date('%Y%m%d', concat(plausibletable.year_of_birth,'-06-01'))
			) 
		 > IF(SAFE_CAST(cdmtable.condition_start_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.condition_start_date  AS STRING)),SAFE_CAST(cdmtable.condition_start_date  AS DATE))
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
) denominator
;

/*********
PLAUSIBLE_TEMPORAL_AFTER
get number of records and the proportion to total number of eligible records with datetimes that do not occur on or after their corresponding datetimes
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_START_DATETIME
plausibleTemporalAfterTableName = PERSON
plausibleTemporalAfterFieldName = BIRTH_DATETIME
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
plausibleTemporalAfterTableName,
plausibleTemporalAfterFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'PLAUSIBLE_TEMPORAL_AFTER' level,
    'get number of records and the proportion to total number of eligible records with datetimes that do not occur on or after their corresponding datetimes' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_START_DATETIME' cdmFieldName,
'PERSON' plausibleTemporalAfterTableName,
'BIRTH_DATETIME' plausibleTemporalAfterFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'CONDITION_OCCURRENCE.CONDITION_START_DATETIME' as violating_field, 
			cdmtable.*
    	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
				join CY_IMOSPHERE_CDM_531.person plausibletable on cdmtable.person_id = plausibletable.person_id
    where 
			coalesce(
				IF(SAFE_CAST(plausibletable.birth_datetime  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(plausibletable.birth_datetime  AS STRING)),SAFE_CAST(plausibletable.birth_datetime  AS DATE)),
				parse_date('%Y%m%d', concat(plausibletable.year_of_birth,'-06-01'))
			) 
		 > IF(SAFE_CAST(cdmtable.condition_start_datetime  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.condition_start_datetime  AS STRING)),SAFE_CAST(cdmtable.condition_start_datetime  AS DATE))
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
) denominator
;

/*********
PLAUSIBLE_TEMPORAL_AFTER
get number of records and the proportion to total number of eligible records with datetimes that do not occur on or after their corresponding datetimes
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_END_DATE
plausibleTemporalAfterTableName = CONDITION_OCCURRENCE
plausibleTemporalAfterFieldName = CONDITION_START_DATE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
plausibleTemporalAfterTableName,
plausibleTemporalAfterFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'PLAUSIBLE_TEMPORAL_AFTER' level,
    'get number of records and the proportion to total number of eligible records with datetimes that do not occur on or after their corresponding datetimes' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_END_DATE' cdmFieldName,
'CONDITION_OCCURRENCE' plausibleTemporalAfterTableName,
'CONDITION_START_DATE' plausibleTemporalAfterFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'CONDITION_OCCURRENCE.CONDITION_END_DATE' as violating_field, 
			cdmtable.*
    	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
    where 
			IF(SAFE_CAST(cdmtable.condition_start_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.condition_start_date  AS STRING)),SAFE_CAST(cdmtable.condition_start_date  AS DATE))
		 > IF(SAFE_CAST(cdmtable.condition_end_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.condition_end_date  AS STRING)),SAFE_CAST(cdmtable.condition_end_date  AS DATE))
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
) denominator
;

/*********
PLAUSIBLE_TEMPORAL_AFTER
get number of records and the proportion to total number of eligible records with datetimes that do not occur on or after their corresponding datetimes
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_END_DATETIME
plausibleTemporalAfterTableName = CONDITION_OCCURRENCE
plausibleTemporalAfterFieldName = CONDITION_START_DATETIME
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
plausibleTemporalAfterTableName,
plausibleTemporalAfterFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'PLAUSIBLE_TEMPORAL_AFTER' level,
    'get number of records and the proportion to total number of eligible records with datetimes that do not occur on or after their corresponding datetimes' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_END_DATETIME' cdmFieldName,
'CONDITION_OCCURRENCE' plausibleTemporalAfterTableName,
'CONDITION_START_DATETIME' plausibleTemporalAfterFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'CONDITION_OCCURRENCE.CONDITION_END_DATETIME' as violating_field, 
			cdmtable.*
    	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
    where 
			IF(SAFE_CAST(cdmtable.condition_start_datetime  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.condition_start_datetime  AS STRING)),SAFE_CAST(cdmtable.condition_start_datetime  AS DATE))
		 > IF(SAFE_CAST(cdmtable.condition_end_datetime  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.condition_end_datetime  AS STRING)),SAFE_CAST(cdmtable.condition_end_datetime  AS DATE))
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
) denominator
;

/*********
PLAUSIBLE_TEMPORAL_AFTER
get number of records and the proportion to total number of eligible records with datetimes that do not occur on or after their corresponding datetimes
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DRUG_EXPOSURE
cdmFieldName = DRUG_EXPOSURE_START_DATE
plausibleTemporalAfterTableName = PERSON
plausibleTemporalAfterFieldName = BIRTH_DATETIME
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
plausibleTemporalAfterTableName,
plausibleTemporalAfterFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'PLAUSIBLE_TEMPORAL_AFTER' level,
    'get number of records and the proportion to total number of eligible records with datetimes that do not occur on or after their corresponding datetimes' check,
    'DRUG_EXPOSURE' cdmTableName,
'DRUG_EXPOSURE_START_DATE' cdmFieldName,
'PERSON' plausibleTemporalAfterTableName,
'BIRTH_DATETIME' plausibleTemporalAfterFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'DRUG_EXPOSURE.DRUG_EXPOSURE_START_DATE' as violating_field, 
			cdmtable.*
    	from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
				join CY_IMOSPHERE_CDM_531.person plausibletable on cdmtable.person_id = plausibletable.person_id
    where 
			coalesce(
				IF(SAFE_CAST(plausibletable.birth_datetime  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(plausibletable.birth_datetime  AS STRING)),SAFE_CAST(plausibletable.birth_datetime  AS DATE)),
				parse_date('%Y%m%d', concat(plausibletable.year_of_birth,'-06-01'))
			) 
		 > IF(SAFE_CAST(cdmtable.drug_exposure_start_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.drug_exposure_start_date  AS STRING)),SAFE_CAST(cdmtable.drug_exposure_start_date  AS DATE))
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
) denominator
;

/*********
PLAUSIBLE_TEMPORAL_AFTER
get number of records and the proportion to total number of eligible records with datetimes that do not occur on or after their corresponding datetimes
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DRUG_EXPOSURE
cdmFieldName = DRUG_EXPOSURE_START_DATETIME
plausibleTemporalAfterTableName = PERSON
plausibleTemporalAfterFieldName = BIRTH_DATETIME
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
plausibleTemporalAfterTableName,
plausibleTemporalAfterFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'PLAUSIBLE_TEMPORAL_AFTER' level,
    'get number of records and the proportion to total number of eligible records with datetimes that do not occur on or after their corresponding datetimes' check,
    'DRUG_EXPOSURE' cdmTableName,
'DRUG_EXPOSURE_START_DATETIME' cdmFieldName,
'PERSON' plausibleTemporalAfterTableName,
'BIRTH_DATETIME' plausibleTemporalAfterFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'DRUG_EXPOSURE.DRUG_EXPOSURE_START_DATETIME' as violating_field, 
			cdmtable.*
    	from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
				join CY_IMOSPHERE_CDM_531.person plausibletable on cdmtable.person_id = plausibletable.person_id
    where 
			coalesce(
				IF(SAFE_CAST(plausibletable.birth_datetime  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(plausibletable.birth_datetime  AS STRING)),SAFE_CAST(plausibletable.birth_datetime  AS DATE)),
				parse_date('%Y%m%d', concat(plausibletable.year_of_birth,'-06-01'))
			) 
		 > IF(SAFE_CAST(cdmtable.drug_exposure_start_datetime  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.drug_exposure_start_datetime  AS STRING)),SAFE_CAST(cdmtable.drug_exposure_start_datetime  AS DATE))
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
) denominator
;

/*********
PLAUSIBLE_TEMPORAL_AFTER
get number of records and the proportion to total number of eligible records with datetimes that do not occur on or after their corresponding datetimes
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DRUG_EXPOSURE
cdmFieldName = DRUG_EXPOSURE_END_DATE
plausibleTemporalAfterTableName = DRUG_EXPOSURE
plausibleTemporalAfterFieldName = DRUG_EXPOSURE_START_DATE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
plausibleTemporalAfterTableName,
plausibleTemporalAfterFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'PLAUSIBLE_TEMPORAL_AFTER' level,
    'get number of records and the proportion to total number of eligible records with datetimes that do not occur on or after their corresponding datetimes' check,
    'DRUG_EXPOSURE' cdmTableName,
'DRUG_EXPOSURE_END_DATE' cdmFieldName,
'DRUG_EXPOSURE' plausibleTemporalAfterTableName,
'DRUG_EXPOSURE_START_DATE' plausibleTemporalAfterFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'DRUG_EXPOSURE.DRUG_EXPOSURE_END_DATE' as violating_field, 
			cdmtable.*
    	from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
    where 
			IF(SAFE_CAST(cdmtable.drug_exposure_start_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.drug_exposure_start_date  AS STRING)),SAFE_CAST(cdmtable.drug_exposure_start_date  AS DATE))
		 > IF(SAFE_CAST(cdmtable.drug_exposure_end_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.drug_exposure_end_date  AS STRING)),SAFE_CAST(cdmtable.drug_exposure_end_date  AS DATE))
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
) denominator
;

/*********
PLAUSIBLE_TEMPORAL_AFTER
get number of records and the proportion to total number of eligible records with datetimes that do not occur on or after their corresponding datetimes
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DRUG_EXPOSURE
cdmFieldName = DRUG_EXPOSURE_END_DATETIME
plausibleTemporalAfterTableName = DRUG_EXPOSURE
plausibleTemporalAfterFieldName = DRUG_EXPOSURE_START_DATETIME
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
plausibleTemporalAfterTableName,
plausibleTemporalAfterFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'PLAUSIBLE_TEMPORAL_AFTER' level,
    'get number of records and the proportion to total number of eligible records with datetimes that do not occur on or after their corresponding datetimes' check,
    'DRUG_EXPOSURE' cdmTableName,
'DRUG_EXPOSURE_END_DATETIME' cdmFieldName,
'DRUG_EXPOSURE' plausibleTemporalAfterTableName,
'DRUG_EXPOSURE_START_DATETIME' plausibleTemporalAfterFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'DRUG_EXPOSURE.DRUG_EXPOSURE_END_DATETIME' as violating_field, 
			cdmtable.*
    	from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
    where 
			IF(SAFE_CAST(cdmtable.drug_exposure_start_datetime  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.drug_exposure_start_datetime  AS STRING)),SAFE_CAST(cdmtable.drug_exposure_start_datetime  AS DATE))
		 > IF(SAFE_CAST(cdmtable.drug_exposure_end_datetime  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.drug_exposure_end_datetime  AS STRING)),SAFE_CAST(cdmtable.drug_exposure_end_datetime  AS DATE))
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
) denominator
;

/*********
PLAUSIBLE_TEMPORAL_AFTER
get number of records and the proportion to total number of eligible records with datetimes that do not occur on or after their corresponding datetimes
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DRUG_EXPOSURE
cdmFieldName = VERBATIM_END_DATE
plausibleTemporalAfterTableName = DRUG_EXPOSURE
plausibleTemporalAfterFieldName = DRUG_EXPOSURE_START_DATE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
plausibleTemporalAfterTableName,
plausibleTemporalAfterFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'PLAUSIBLE_TEMPORAL_AFTER' level,
    'get number of records and the proportion to total number of eligible records with datetimes that do not occur on or after their corresponding datetimes' check,
    'DRUG_EXPOSURE' cdmTableName,
'VERBATIM_END_DATE' cdmFieldName,
'DRUG_EXPOSURE' plausibleTemporalAfterTableName,
'DRUG_EXPOSURE_START_DATE' plausibleTemporalAfterFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'DRUG_EXPOSURE.VERBATIM_END_DATE' as violating_field, 
			cdmtable.*
    	from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
    where 
			IF(SAFE_CAST(cdmtable.drug_exposure_start_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.drug_exposure_start_date  AS STRING)),SAFE_CAST(cdmtable.drug_exposure_start_date  AS DATE))
		 > IF(SAFE_CAST(cdmtable.verbatim_end_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.verbatim_end_date  AS STRING)),SAFE_CAST(cdmtable.verbatim_end_date  AS DATE))
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
) denominator
;

/*********
PLAUSIBLE_TEMPORAL_AFTER
get number of records and the proportion to total number of eligible records with datetimes that do not occur on or after their corresponding datetimes
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_DATE
plausibleTemporalAfterTableName = PERSON
plausibleTemporalAfterFieldName = BIRTH_DATETIME
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
plausibleTemporalAfterTableName,
plausibleTemporalAfterFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'PLAUSIBLE_TEMPORAL_AFTER' level,
    'get number of records and the proportion to total number of eligible records with datetimes that do not occur on or after their corresponding datetimes' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_DATE' cdmFieldName,
'PERSON' plausibleTemporalAfterTableName,
'BIRTH_DATETIME' plausibleTemporalAfterFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'PROCEDURE_OCCURRENCE.PROCEDURE_DATE' as violating_field, 
			cdmtable.*
    	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
				join CY_IMOSPHERE_CDM_531.person plausibletable on cdmtable.person_id = plausibletable.person_id
    where 
			coalesce(
				IF(SAFE_CAST(plausibletable.birth_datetime  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(plausibletable.birth_datetime  AS STRING)),SAFE_CAST(plausibletable.birth_datetime  AS DATE)),
				parse_date('%Y%m%d', concat(plausibletable.year_of_birth,'-06-01'))
			) 
		 > IF(SAFE_CAST(cdmtable.procedure_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.procedure_date  AS STRING)),SAFE_CAST(cdmtable.procedure_date  AS DATE))
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
) denominator
;

/*********
PLAUSIBLE_TEMPORAL_AFTER
get number of records and the proportion to total number of eligible records with datetimes that do not occur on or after their corresponding datetimes
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_DATETIME
plausibleTemporalAfterTableName = PERSON
plausibleTemporalAfterFieldName = BIRTH_DATETIME
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
plausibleTemporalAfterTableName,
plausibleTemporalAfterFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'PLAUSIBLE_TEMPORAL_AFTER' level,
    'get number of records and the proportion to total number of eligible records with datetimes that do not occur on or after their corresponding datetimes' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_DATETIME' cdmFieldName,
'PERSON' plausibleTemporalAfterTableName,
'BIRTH_DATETIME' plausibleTemporalAfterFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'PROCEDURE_OCCURRENCE.PROCEDURE_DATETIME' as violating_field, 
			cdmtable.*
    	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
				join CY_IMOSPHERE_CDM_531.person plausibletable on cdmtable.person_id = plausibletable.person_id
    where 
			coalesce(
				IF(SAFE_CAST(plausibletable.birth_datetime  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(plausibletable.birth_datetime  AS STRING)),SAFE_CAST(plausibletable.birth_datetime  AS DATE)),
				parse_date('%Y%m%d', concat(plausibletable.year_of_birth,'-06-01'))
			) 
		 > IF(SAFE_CAST(cdmtable.procedure_datetime  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.procedure_datetime  AS STRING)),SAFE_CAST(cdmtable.procedure_datetime  AS DATE))
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
) denominator
;

/*********
PLAUSIBLE_TEMPORAL_AFTER
get number of records and the proportion to total number of eligible records with datetimes that do not occur on or after their corresponding datetimes
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DEVICE_EXPOSURE
cdmFieldName = DEVICE_EXPOSURE_START_DATE
plausibleTemporalAfterTableName = PERSON
plausibleTemporalAfterFieldName = BIRTH_DATETIME
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
plausibleTemporalAfterTableName,
plausibleTemporalAfterFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'PLAUSIBLE_TEMPORAL_AFTER' level,
    'get number of records and the proportion to total number of eligible records with datetimes that do not occur on or after their corresponding datetimes' check,
    'DEVICE_EXPOSURE' cdmTableName,
'DEVICE_EXPOSURE_START_DATE' cdmFieldName,
'PERSON' plausibleTemporalAfterTableName,
'BIRTH_DATETIME' plausibleTemporalAfterFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'DEVICE_EXPOSURE.DEVICE_EXPOSURE_START_DATE' as violating_field, 
			cdmtable.*
    	from CY_IMOSPHERE_CDM_531.device_exposure cdmtable
				join CY_IMOSPHERE_CDM_531.person plausibletable on cdmtable.person_id = plausibletable.person_id
    where 
			coalesce(
				IF(SAFE_CAST(plausibletable.birth_datetime  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(plausibletable.birth_datetime  AS STRING)),SAFE_CAST(plausibletable.birth_datetime  AS DATE)),
				parse_date('%Y%m%d', concat(plausibletable.year_of_birth,'-06-01'))
			) 
		 > IF(SAFE_CAST(cdmtable.device_exposure_start_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.device_exposure_start_date  AS STRING)),SAFE_CAST(cdmtable.device_exposure_start_date  AS DATE))
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.device_exposure cdmtable
) denominator
;

/*********
PLAUSIBLE_TEMPORAL_AFTER
get number of records and the proportion to total number of eligible records with datetimes that do not occur on or after their corresponding datetimes
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DEVICE_EXPOSURE
cdmFieldName = DEVICE_EXPOSURE_START_DATETIME
plausibleTemporalAfterTableName = PERSON
plausibleTemporalAfterFieldName = BIRTH_DATETIME
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
plausibleTemporalAfterTableName,
plausibleTemporalAfterFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'PLAUSIBLE_TEMPORAL_AFTER' level,
    'get number of records and the proportion to total number of eligible records with datetimes that do not occur on or after their corresponding datetimes' check,
    'DEVICE_EXPOSURE' cdmTableName,
'DEVICE_EXPOSURE_START_DATETIME' cdmFieldName,
'PERSON' plausibleTemporalAfterTableName,
'BIRTH_DATETIME' plausibleTemporalAfterFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'DEVICE_EXPOSURE.DEVICE_EXPOSURE_START_DATETIME' as violating_field, 
			cdmtable.*
    	from CY_IMOSPHERE_CDM_531.device_exposure cdmtable
				join CY_IMOSPHERE_CDM_531.person plausibletable on cdmtable.person_id = plausibletable.person_id
    where 
			coalesce(
				IF(SAFE_CAST(plausibletable.birth_datetime  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(plausibletable.birth_datetime  AS STRING)),SAFE_CAST(plausibletable.birth_datetime  AS DATE)),
				parse_date('%Y%m%d', concat(plausibletable.year_of_birth,'-06-01'))
			) 
		 > IF(SAFE_CAST(cdmtable.device_exposure_start_datetime  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.device_exposure_start_datetime  AS STRING)),SAFE_CAST(cdmtable.device_exposure_start_datetime  AS DATE))
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.device_exposure cdmtable
) denominator
;

/*********
PLAUSIBLE_TEMPORAL_AFTER
get number of records and the proportion to total number of eligible records with datetimes that do not occur on or after their corresponding datetimes
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DEVICE_EXPOSURE
cdmFieldName = DEVICE_EXPOSURE_END_DATE
plausibleTemporalAfterTableName = DEVICE_EXPOSURE
plausibleTemporalAfterFieldName = DEVICE_EXPOSURE_START_DATE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
plausibleTemporalAfterTableName,
plausibleTemporalAfterFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'PLAUSIBLE_TEMPORAL_AFTER' level,
    'get number of records and the proportion to total number of eligible records with datetimes that do not occur on or after their corresponding datetimes' check,
    'DEVICE_EXPOSURE' cdmTableName,
'DEVICE_EXPOSURE_END_DATE' cdmFieldName,
'DEVICE_EXPOSURE' plausibleTemporalAfterTableName,
'DEVICE_EXPOSURE_START_DATE' plausibleTemporalAfterFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'DEVICE_EXPOSURE.DEVICE_EXPOSURE_END_DATE' as violating_field, 
			cdmtable.*
    	from CY_IMOSPHERE_CDM_531.device_exposure cdmtable
    where 
			IF(SAFE_CAST(cdmtable.device_exposure_start_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.device_exposure_start_date  AS STRING)),SAFE_CAST(cdmtable.device_exposure_start_date  AS DATE))
		 > IF(SAFE_CAST(cdmtable.device_exposure_end_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.device_exposure_end_date  AS STRING)),SAFE_CAST(cdmtable.device_exposure_end_date  AS DATE))
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.device_exposure cdmtable
) denominator
;

/*********
PLAUSIBLE_TEMPORAL_AFTER
get number of records and the proportion to total number of eligible records with datetimes that do not occur on or after their corresponding datetimes
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DEVICE_EXPOSURE
cdmFieldName = DEVICE_EXPOSURE_END_DATETIME
plausibleTemporalAfterTableName = DEVICE_EXPOSURE
plausibleTemporalAfterFieldName = DEVICE_EXPOSURE_START_DATETIME
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
plausibleTemporalAfterTableName,
plausibleTemporalAfterFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'PLAUSIBLE_TEMPORAL_AFTER' level,
    'get number of records and the proportion to total number of eligible records with datetimes that do not occur on or after their corresponding datetimes' check,
    'DEVICE_EXPOSURE' cdmTableName,
'DEVICE_EXPOSURE_END_DATETIME' cdmFieldName,
'DEVICE_EXPOSURE' plausibleTemporalAfterTableName,
'DEVICE_EXPOSURE_START_DATETIME' plausibleTemporalAfterFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'DEVICE_EXPOSURE.DEVICE_EXPOSURE_END_DATETIME' as violating_field, 
			cdmtable.*
    	from CY_IMOSPHERE_CDM_531.device_exposure cdmtable
    where 
			IF(SAFE_CAST(cdmtable.device_exposure_start_datetime  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.device_exposure_start_datetime  AS STRING)),SAFE_CAST(cdmtable.device_exposure_start_datetime  AS DATE))
		 > IF(SAFE_CAST(cdmtable.device_exposure_end_datetime  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.device_exposure_end_datetime  AS STRING)),SAFE_CAST(cdmtable.device_exposure_end_datetime  AS DATE))
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.device_exposure cdmtable
) denominator
;

/*********
PLAUSIBLE_TEMPORAL_AFTER
get number of records and the proportion to total number of eligible records with datetimes that do not occur on or after their corresponding datetimes
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = MEASUREMENT
cdmFieldName = MEASUREMENT_DATE
plausibleTemporalAfterTableName = PERSON
plausibleTemporalAfterFieldName = BIRTH_DATETIME
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
plausibleTemporalAfterTableName,
plausibleTemporalAfterFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'PLAUSIBLE_TEMPORAL_AFTER' level,
    'get number of records and the proportion to total number of eligible records with datetimes that do not occur on or after their corresponding datetimes' check,
    'MEASUREMENT' cdmTableName,
'MEASUREMENT_DATE' cdmFieldName,
'PERSON' plausibleTemporalAfterTableName,
'BIRTH_DATETIME' plausibleTemporalAfterFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'MEASUREMENT.MEASUREMENT_DATE' as violating_field, 
			cdmtable.*
    	from CY_IMOSPHERE_CDM_531.measurement cdmtable
				join CY_IMOSPHERE_CDM_531.person plausibletable on cdmtable.person_id = plausibletable.person_id
    where 
			coalesce(
				IF(SAFE_CAST(plausibletable.birth_datetime  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(plausibletable.birth_datetime  AS STRING)),SAFE_CAST(plausibletable.birth_datetime  AS DATE)),
				parse_date('%Y%m%d', concat(plausibletable.year_of_birth,'-06-01'))
			) 
		 > IF(SAFE_CAST(cdmtable.measurement_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.measurement_date  AS STRING)),SAFE_CAST(cdmtable.measurement_date  AS DATE))
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.measurement cdmtable
) denominator
;

/*********
PLAUSIBLE_TEMPORAL_AFTER
get number of records and the proportion to total number of eligible records with datetimes that do not occur on or after their corresponding datetimes
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_DETAIL
cdmFieldName = VISIT_DETAIL_START_DATE
plausibleTemporalAfterTableName = PERSON
plausibleTemporalAfterFieldName = BIRTH_DATETIME
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
plausibleTemporalAfterTableName,
plausibleTemporalAfterFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'PLAUSIBLE_TEMPORAL_AFTER' level,
    'get number of records and the proportion to total number of eligible records with datetimes that do not occur on or after their corresponding datetimes' check,
    'VISIT_DETAIL' cdmTableName,
'VISIT_DETAIL_START_DATE' cdmFieldName,
'PERSON' plausibleTemporalAfterTableName,
'BIRTH_DATETIME' plausibleTemporalAfterFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'VISIT_DETAIL.VISIT_DETAIL_START_DATE' as violating_field, 
			cdmtable.*
    	from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
				join CY_IMOSPHERE_CDM_531.person plausibletable on cdmtable.person_id = plausibletable.person_id
    where 
			coalesce(
				IF(SAFE_CAST(plausibletable.birth_datetime  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(plausibletable.birth_datetime  AS STRING)),SAFE_CAST(plausibletable.birth_datetime  AS DATE)),
				parse_date('%Y%m%d', concat(plausibletable.year_of_birth,'-06-01'))
			) 
		 > IF(SAFE_CAST(cdmtable.visit_detail_start_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.visit_detail_start_date  AS STRING)),SAFE_CAST(cdmtable.visit_detail_start_date  AS DATE))
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
) denominator
;

/*********
PLAUSIBLE_TEMPORAL_AFTER
get number of records and the proportion to total number of eligible records with datetimes that do not occur on or after their corresponding datetimes
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_DETAIL
cdmFieldName = VISIT_DETAIL_START_DATETIME
plausibleTemporalAfterTableName = PERSON
plausibleTemporalAfterFieldName = BIRTH_DATETIME
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
plausibleTemporalAfterTableName,
plausibleTemporalAfterFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'PLAUSIBLE_TEMPORAL_AFTER' level,
    'get number of records and the proportion to total number of eligible records with datetimes that do not occur on or after their corresponding datetimes' check,
    'VISIT_DETAIL' cdmTableName,
'VISIT_DETAIL_START_DATETIME' cdmFieldName,
'PERSON' plausibleTemporalAfterTableName,
'BIRTH_DATETIME' plausibleTemporalAfterFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'VISIT_DETAIL.VISIT_DETAIL_START_DATETIME' as violating_field, 
			cdmtable.*
    	from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
				join CY_IMOSPHERE_CDM_531.person plausibletable on cdmtable.person_id = plausibletable.person_id
    where 
			coalesce(
				IF(SAFE_CAST(plausibletable.birth_datetime  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(plausibletable.birth_datetime  AS STRING)),SAFE_CAST(plausibletable.birth_datetime  AS DATE)),
				parse_date('%Y%m%d', concat(plausibletable.year_of_birth,'-06-01'))
			) 
		 > IF(SAFE_CAST(cdmtable.visit_detail_start_datetime  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.visit_detail_start_datetime  AS STRING)),SAFE_CAST(cdmtable.visit_detail_start_datetime  AS DATE))
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
) denominator
;

/*********
PLAUSIBLE_TEMPORAL_AFTER
get number of records and the proportion to total number of eligible records with datetimes that do not occur on or after their corresponding datetimes
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_DETAIL
cdmFieldName = VISIT_DETAIL_END_DATE
plausibleTemporalAfterTableName = VISIT_DETAIL
plausibleTemporalAfterFieldName = VISIT_DETAIL_START_DATE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
plausibleTemporalAfterTableName,
plausibleTemporalAfterFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'PLAUSIBLE_TEMPORAL_AFTER' level,
    'get number of records and the proportion to total number of eligible records with datetimes that do not occur on or after their corresponding datetimes' check,
    'VISIT_DETAIL' cdmTableName,
'VISIT_DETAIL_END_DATE' cdmFieldName,
'VISIT_DETAIL' plausibleTemporalAfterTableName,
'VISIT_DETAIL_START_DATE' plausibleTemporalAfterFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'VISIT_DETAIL.VISIT_DETAIL_END_DATE' as violating_field, 
			cdmtable.*
    	from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
    where 
			IF(SAFE_CAST(cdmtable.visit_detail_start_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.visit_detail_start_date  AS STRING)),SAFE_CAST(cdmtable.visit_detail_start_date  AS DATE))
		 > IF(SAFE_CAST(cdmtable.visit_detail_end_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.visit_detail_end_date  AS STRING)),SAFE_CAST(cdmtable.visit_detail_end_date  AS DATE))
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
) denominator
;

/*********
PLAUSIBLE_TEMPORAL_AFTER
get number of records and the proportion to total number of eligible records with datetimes that do not occur on or after their corresponding datetimes
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_DETAIL
cdmFieldName = VISIT_DETAIL_END_DATETIME
plausibleTemporalAfterTableName = VISIT_DETAIL
plausibleTemporalAfterFieldName = VISIT_DETAIL_START_DATETIME
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
plausibleTemporalAfterTableName,
plausibleTemporalAfterFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'PLAUSIBLE_TEMPORAL_AFTER' level,
    'get number of records and the proportion to total number of eligible records with datetimes that do not occur on or after their corresponding datetimes' check,
    'VISIT_DETAIL' cdmTableName,
'VISIT_DETAIL_END_DATETIME' cdmFieldName,
'VISIT_DETAIL' plausibleTemporalAfterTableName,
'VISIT_DETAIL_START_DATETIME' plausibleTemporalAfterFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'VISIT_DETAIL.VISIT_DETAIL_END_DATETIME' as violating_field, 
			cdmtable.*
    	from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
    where 
			IF(SAFE_CAST(cdmtable.visit_detail_start_datetime  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.visit_detail_start_datetime  AS STRING)),SAFE_CAST(cdmtable.visit_detail_start_datetime  AS DATE))
		 > IF(SAFE_CAST(cdmtable.visit_detail_end_datetime  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.visit_detail_end_datetime  AS STRING)),SAFE_CAST(cdmtable.visit_detail_end_datetime  AS DATE))
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
) denominator
;

/*********
PLAUSIBLE_TEMPORAL_AFTER
get number of records and the proportion to total number of eligible records with datetimes that do not occur on or after their corresponding datetimes
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = NOTE
cdmFieldName = NOTE_DATE
plausibleTemporalAfterTableName = PERSON
plausibleTemporalAfterFieldName = BIRTH_DATETIME
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
plausibleTemporalAfterTableName,
plausibleTemporalAfterFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'PLAUSIBLE_TEMPORAL_AFTER' level,
    'get number of records and the proportion to total number of eligible records with datetimes that do not occur on or after their corresponding datetimes' check,
    'NOTE' cdmTableName,
'NOTE_DATE' cdmFieldName,
'PERSON' plausibleTemporalAfterTableName,
'BIRTH_DATETIME' plausibleTemporalAfterFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'NOTE.NOTE_DATE' as violating_field, 
			cdmtable.*
    	from CY_IMOSPHERE_CDM_531.note cdmtable
				join CY_IMOSPHERE_CDM_531.person plausibletable on cdmtable.person_id = plausibletable.person_id
    where 
			coalesce(
				IF(SAFE_CAST(plausibletable.birth_datetime  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(plausibletable.birth_datetime  AS STRING)),SAFE_CAST(plausibletable.birth_datetime  AS DATE)),
				parse_date('%Y%m%d', concat(plausibletable.year_of_birth,'-06-01'))
			) 
		 > IF(SAFE_CAST(cdmtable.note_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.note_date  AS STRING)),SAFE_CAST(cdmtable.note_date  AS DATE))
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.note cdmtable
) denominator
;

/*********
PLAUSIBLE_TEMPORAL_AFTER
get number of records and the proportion to total number of eligible records with datetimes that do not occur on or after their corresponding datetimes
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = NOTE
cdmFieldName = NOTE_DATETIME
plausibleTemporalAfterTableName = PERSON
plausibleTemporalAfterFieldName = BIRTH_DATETIME
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
plausibleTemporalAfterTableName,
plausibleTemporalAfterFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'PLAUSIBLE_TEMPORAL_AFTER' level,
    'get number of records and the proportion to total number of eligible records with datetimes that do not occur on or after their corresponding datetimes' check,
    'NOTE' cdmTableName,
'NOTE_DATETIME' cdmFieldName,
'PERSON' plausibleTemporalAfterTableName,
'BIRTH_DATETIME' plausibleTemporalAfterFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'NOTE.NOTE_DATETIME' as violating_field, 
			cdmtable.*
    	from CY_IMOSPHERE_CDM_531.note cdmtable
				join CY_IMOSPHERE_CDM_531.person plausibletable on cdmtable.person_id = plausibletable.person_id
    where 
			coalesce(
				IF(SAFE_CAST(plausibletable.birth_datetime  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(plausibletable.birth_datetime  AS STRING)),SAFE_CAST(plausibletable.birth_datetime  AS DATE)),
				parse_date('%Y%m%d', concat(plausibletable.year_of_birth,'-06-01'))
			) 
		 > IF(SAFE_CAST(cdmtable.note_datetime  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.note_datetime  AS STRING)),SAFE_CAST(cdmtable.note_datetime  AS DATE))
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.note cdmtable
) denominator
;

/*********
PLAUSIBLE_TEMPORAL_AFTER
get number of records and the proportion to total number of eligible records with datetimes that do not occur on or after their corresponding datetimes
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = OBSERVATION
cdmFieldName = OBSERVATION_DATE
plausibleTemporalAfterTableName = PERSON
plausibleTemporalAfterFieldName = BIRTH_DATETIME
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
plausibleTemporalAfterTableName,
plausibleTemporalAfterFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'PLAUSIBLE_TEMPORAL_AFTER' level,
    'get number of records and the proportion to total number of eligible records with datetimes that do not occur on or after their corresponding datetimes' check,
    'OBSERVATION' cdmTableName,
'OBSERVATION_DATE' cdmFieldName,
'PERSON' plausibleTemporalAfterTableName,
'BIRTH_DATETIME' plausibleTemporalAfterFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'OBSERVATION.OBSERVATION_DATE' as violating_field, 
			cdmtable.*
    	from CY_IMOSPHERE_CDM_531.observation cdmtable
				join CY_IMOSPHERE_CDM_531.person plausibletable on cdmtable.person_id = plausibletable.person_id
    where 
			coalesce(
				IF(SAFE_CAST(plausibletable.birth_datetime  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(plausibletable.birth_datetime  AS STRING)),SAFE_CAST(plausibletable.birth_datetime  AS DATE)),
				parse_date('%Y%m%d', concat(plausibletable.year_of_birth,'-06-01'))
			) 
		 > IF(SAFE_CAST(cdmtable.observation_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.observation_date  AS STRING)),SAFE_CAST(cdmtable.observation_date  AS DATE))
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.observation cdmtable
) denominator
;

/*********
PLAUSIBLE_TEMPORAL_AFTER
get number of records and the proportion to total number of eligible records with datetimes that do not occur on or after their corresponding datetimes
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = OBSERVATION
cdmFieldName = OBSERVATION_DATETIME
plausibleTemporalAfterTableName = PERSON
plausibleTemporalAfterFieldName = BIRTH_DATETIME
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
plausibleTemporalAfterTableName,
plausibleTemporalAfterFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'PLAUSIBLE_TEMPORAL_AFTER' level,
    'get number of records and the proportion to total number of eligible records with datetimes that do not occur on or after their corresponding datetimes' check,
    'OBSERVATION' cdmTableName,
'OBSERVATION_DATETIME' cdmFieldName,
'PERSON' plausibleTemporalAfterTableName,
'BIRTH_DATETIME' plausibleTemporalAfterFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'OBSERVATION.OBSERVATION_DATETIME' as violating_field, 
			cdmtable.*
    	from CY_IMOSPHERE_CDM_531.observation cdmtable
				join CY_IMOSPHERE_CDM_531.person plausibletable on cdmtable.person_id = plausibletable.person_id
    where 
			coalesce(
				IF(SAFE_CAST(plausibletable.birth_datetime  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(plausibletable.birth_datetime  AS STRING)),SAFE_CAST(plausibletable.birth_datetime  AS DATE)),
				parse_date('%Y%m%d', concat(plausibletable.year_of_birth,'-06-01'))
			) 
		 > IF(SAFE_CAST(cdmtable.observation_datetime  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.observation_datetime  AS STRING)),SAFE_CAST(cdmtable.observation_datetime  AS DATE))
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.observation cdmtable
) denominator
;

/*********
PLAUSIBLE_TEMPORAL_AFTER
get number of records and the proportion to total number of eligible records with datetimes that do not occur on or after their corresponding datetimes
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PAYER_PLAN_PERIOD
cdmFieldName = PAYER_PLAN_PERIOD_END_DATE
plausibleTemporalAfterTableName = PAYER_PLAN_PERIOD
plausibleTemporalAfterFieldName = PAYER_PLAN_PERIOD_START_DATE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
plausibleTemporalAfterTableName,
plausibleTemporalAfterFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'PLAUSIBLE_TEMPORAL_AFTER' level,
    'get number of records and the proportion to total number of eligible records with datetimes that do not occur on or after their corresponding datetimes' check,
    'PAYER_PLAN_PERIOD' cdmTableName,
'PAYER_PLAN_PERIOD_END_DATE' cdmFieldName,
'PAYER_PLAN_PERIOD' plausibleTemporalAfterTableName,
'PAYER_PLAN_PERIOD_START_DATE' plausibleTemporalAfterFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'PAYER_PLAN_PERIOD.PAYER_PLAN_PERIOD_END_DATE' as violating_field, 
			cdmtable.*
    	from CY_IMOSPHERE_CDM_531.payer_plan_period cdmtable
    where 
			IF(SAFE_CAST(cdmtable.payer_plan_period_start_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.payer_plan_period_start_date  AS STRING)),SAFE_CAST(cdmtable.payer_plan_period_start_date  AS DATE))
		 > IF(SAFE_CAST(cdmtable.payer_plan_period_end_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.payer_plan_period_end_date  AS STRING)),SAFE_CAST(cdmtable.payer_plan_period_end_date  AS DATE))
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.payer_plan_period cdmtable
) denominator
;

/*********
PLAUSIBLE_TEMPORAL_AFTER
get number of records and the proportion to total number of eligible records with datetimes that do not occur on or after their corresponding datetimes
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DRUG_ERA
cdmFieldName = DRUG_ERA_START_DATE
plausibleTemporalAfterTableName = PERSON
plausibleTemporalAfterFieldName = BIRTH_DATETIME
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
plausibleTemporalAfterTableName,
plausibleTemporalAfterFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'PLAUSIBLE_TEMPORAL_AFTER' level,
    'get number of records and the proportion to total number of eligible records with datetimes that do not occur on or after their corresponding datetimes' check,
    'DRUG_ERA' cdmTableName,
'DRUG_ERA_START_DATE' cdmFieldName,
'PERSON' plausibleTemporalAfterTableName,
'BIRTH_DATETIME' plausibleTemporalAfterFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'DRUG_ERA.DRUG_ERA_START_DATE' as violating_field, 
			cdmtable.*
    	from CY_IMOSPHERE_CDM_531.drug_era cdmtable
				join CY_IMOSPHERE_CDM_531.person plausibletable on cdmtable.person_id = plausibletable.person_id
    where 
			coalesce(
				IF(SAFE_CAST(plausibletable.birth_datetime  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(plausibletable.birth_datetime  AS STRING)),SAFE_CAST(plausibletable.birth_datetime  AS DATE)),
				parse_date('%Y%m%d', concat(plausibletable.year_of_birth,'-06-01'))
			) 
		 > IF(SAFE_CAST(cdmtable.drug_era_start_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.drug_era_start_date  AS STRING)),SAFE_CAST(cdmtable.drug_era_start_date  AS DATE))
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.drug_era cdmtable
) denominator
;

/*********
PLAUSIBLE_TEMPORAL_AFTER
get number of records and the proportion to total number of eligible records with datetimes that do not occur on or after their corresponding datetimes
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DRUG_ERA
cdmFieldName = DRUG_ERA_END_DATE
plausibleTemporalAfterTableName = DRUG_ERA
plausibleTemporalAfterFieldName = DRUG_ERA_START_DATE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
plausibleTemporalAfterTableName,
plausibleTemporalAfterFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'PLAUSIBLE_TEMPORAL_AFTER' level,
    'get number of records and the proportion to total number of eligible records with datetimes that do not occur on or after their corresponding datetimes' check,
    'DRUG_ERA' cdmTableName,
'DRUG_ERA_END_DATE' cdmFieldName,
'DRUG_ERA' plausibleTemporalAfterTableName,
'DRUG_ERA_START_DATE' plausibleTemporalAfterFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'DRUG_ERA.DRUG_ERA_END_DATE' as violating_field, 
			cdmtable.*
    	from CY_IMOSPHERE_CDM_531.drug_era cdmtable
    where 
			IF(SAFE_CAST(cdmtable.drug_era_start_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.drug_era_start_date  AS STRING)),SAFE_CAST(cdmtable.drug_era_start_date  AS DATE))
		 > IF(SAFE_CAST(cdmtable.drug_era_end_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.drug_era_end_date  AS STRING)),SAFE_CAST(cdmtable.drug_era_end_date  AS DATE))
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.drug_era cdmtable
) denominator
;

/*********
PLAUSIBLE_TEMPORAL_AFTER
get number of records and the proportion to total number of eligible records with datetimes that do not occur on or after their corresponding datetimes
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_ERA
cdmFieldName = CONDITION_ERA_START_DATE
plausibleTemporalAfterTableName = PERSON
plausibleTemporalAfterFieldName = BIRTH_DATETIME
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
plausibleTemporalAfterTableName,
plausibleTemporalAfterFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'PLAUSIBLE_TEMPORAL_AFTER' level,
    'get number of records and the proportion to total number of eligible records with datetimes that do not occur on or after their corresponding datetimes' check,
    'CONDITION_ERA' cdmTableName,
'CONDITION_ERA_START_DATE' cdmFieldName,
'PERSON' plausibleTemporalAfterTableName,
'BIRTH_DATETIME' plausibleTemporalAfterFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'CONDITION_ERA.CONDITION_ERA_START_DATE' as violating_field, 
			cdmtable.*
    	from CY_IMOSPHERE_CDM_531.condition_era cdmtable
				join CY_IMOSPHERE_CDM_531.person plausibletable on cdmtable.person_id = plausibletable.person_id
    where 
			coalesce(
				IF(SAFE_CAST(plausibletable.birth_datetime  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(plausibletable.birth_datetime  AS STRING)),SAFE_CAST(plausibletable.birth_datetime  AS DATE)),
				parse_date('%Y%m%d', concat(plausibletable.year_of_birth,'-06-01'))
			) 
		 > IF(SAFE_CAST(cdmtable.condition_era_start_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.condition_era_start_date  AS STRING)),SAFE_CAST(cdmtable.condition_era_start_date  AS DATE))
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_era cdmtable
) denominator
;

/*********
PLAUSIBLE_TEMPORAL_AFTER
get number of records and the proportion to total number of eligible records with datetimes that do not occur on or after their corresponding datetimes
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_ERA
cdmFieldName = CONDITION_ERA_END_DATE
plausibleTemporalAfterTableName = PERSON
plausibleTemporalAfterFieldName = BIRTH_DATETIME
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
plausibleTemporalAfterTableName,
plausibleTemporalAfterFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'PLAUSIBLE_TEMPORAL_AFTER' level,
    'get number of records and the proportion to total number of eligible records with datetimes that do not occur on or after their corresponding datetimes' check,
    'CONDITION_ERA' cdmTableName,
'CONDITION_ERA_END_DATE' cdmFieldName,
'PERSON' plausibleTemporalAfterTableName,
'BIRTH_DATETIME' plausibleTemporalAfterFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'CONDITION_ERA.CONDITION_ERA_END_DATE' as violating_field, 
			cdmtable.*
    	from CY_IMOSPHERE_CDM_531.condition_era cdmtable
				join CY_IMOSPHERE_CDM_531.person plausibletable on cdmtable.person_id = plausibletable.person_id
    where 
			coalesce(
				IF(SAFE_CAST(plausibletable.birth_datetime  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(plausibletable.birth_datetime  AS STRING)),SAFE_CAST(plausibletable.birth_datetime  AS DATE)),
				parse_date('%Y%m%d', concat(plausibletable.year_of_birth,'-06-01'))
			) 
		 > IF(SAFE_CAST(cdmtable.condition_era_end_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.condition_era_end_date  AS STRING)),SAFE_CAST(cdmtable.condition_era_end_date  AS DATE))
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_era cdmtable
) denominator
;

