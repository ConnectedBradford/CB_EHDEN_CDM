/*********
Table Level:  
MEASURE_PERSON_COMPLETENESS
Determine what #/% of persons have at least one record in the cdmTable
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = OBSERVATION_PERIOD
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_PERSON_COMPLETENESS' level,
    'Determine what #/% of persons have at least one record in the cdmTable' check,
    'OBSERVATION_PERIOD' cdmTableName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.person_id) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.person cdmtable
			left join CY_IMOSPHERE_CDM_531.observation_period cdmtable2 
			on cdmtable.person_id = cdmtable2.person_id
		where cdmtable2.person_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.person cdmtable
) denominator
;

/*********
Table Level:  
MEASURE_PERSON_COMPLETENESS
Determine what #/% of persons have at least one record in the cdmTable
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_OCCURRENCE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_PERSON_COMPLETENESS' level,
    'Determine what #/% of persons have at least one record in the cdmTable' check,
    'VISIT_OCCURRENCE' cdmTableName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.person_id) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.person cdmtable
			left join CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable2 
			on cdmtable.person_id = cdmtable2.person_id
		where cdmtable2.person_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.person cdmtable
) denominator
;

/*********
Table Level:  
MEASURE_PERSON_COMPLETENESS
Determine what #/% of persons have at least one record in the cdmTable
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_PERSON_COMPLETENESS' level,
    'Determine what #/% of persons have at least one record in the cdmTable' check,
    'CONDITION_OCCURRENCE' cdmTableName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.person_id) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.person cdmtable
			left join CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable2 
			on cdmtable.person_id = cdmtable2.person_id
		where cdmtable2.person_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.person cdmtable
) denominator
;

/*********
Table Level:  
MEASURE_PERSON_COMPLETENESS
Determine what #/% of persons have at least one record in the cdmTable
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DRUG_EXPOSURE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_PERSON_COMPLETENESS' level,
    'Determine what #/% of persons have at least one record in the cdmTable' check,
    'DRUG_EXPOSURE' cdmTableName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.person_id) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.person cdmtable
			left join CY_IMOSPHERE_CDM_531.drug_exposure cdmtable2 
			on cdmtable.person_id = cdmtable2.person_id
		where cdmtable2.person_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.person cdmtable
) denominator
;

/*********
Table Level:  
MEASURE_PERSON_COMPLETENESS
Determine what #/% of persons have at least one record in the cdmTable
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_PERSON_COMPLETENESS' level,
    'Determine what #/% of persons have at least one record in the cdmTable' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.person_id) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.person cdmtable
			left join CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable2 
			on cdmtable.person_id = cdmtable2.person_id
		where cdmtable2.person_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.person cdmtable
) denominator
;

/*********
Table Level:  
MEASURE_PERSON_COMPLETENESS
Determine what #/% of persons have at least one record in the cdmTable
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DEVICE_EXPOSURE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_PERSON_COMPLETENESS' level,
    'Determine what #/% of persons have at least one record in the cdmTable' check,
    'DEVICE_EXPOSURE' cdmTableName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.person_id) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.person cdmtable
			left join CY_IMOSPHERE_CDM_531.device_exposure cdmtable2 
			on cdmtable.person_id = cdmtable2.person_id
		where cdmtable2.person_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.person cdmtable
) denominator
;

/*********
Table Level:  
MEASURE_PERSON_COMPLETENESS
Determine what #/% of persons have at least one record in the cdmTable
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = MEASUREMENT
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_PERSON_COMPLETENESS' level,
    'Determine what #/% of persons have at least one record in the cdmTable' check,
    'MEASUREMENT' cdmTableName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.person_id) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.person cdmtable
			left join CY_IMOSPHERE_CDM_531.measurement cdmtable2 
			on cdmtable.person_id = cdmtable2.person_id
		where cdmtable2.person_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.person cdmtable
) denominator
;

/*********
Table Level:  
MEASURE_PERSON_COMPLETENESS
Determine what #/% of persons have at least one record in the cdmTable
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_DETAIL
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_PERSON_COMPLETENESS' level,
    'Determine what #/% of persons have at least one record in the cdmTable' check,
    'VISIT_DETAIL' cdmTableName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.person_id) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.person cdmtable
			left join CY_IMOSPHERE_CDM_531.visit_detail cdmtable2 
			on cdmtable.person_id = cdmtable2.person_id
		where cdmtable2.person_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.person cdmtable
) denominator
;

/*********
Table Level:  
MEASURE_PERSON_COMPLETENESS
Determine what #/% of persons have at least one record in the cdmTable
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = NOTE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_PERSON_COMPLETENESS' level,
    'Determine what #/% of persons have at least one record in the cdmTable' check,
    'NOTE' cdmTableName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.person_id) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.person cdmtable
			left join CY_IMOSPHERE_CDM_531.note cdmtable2 
			on cdmtable.person_id = cdmtable2.person_id
		where cdmtable2.person_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.person cdmtable
) denominator
;

/*********
Table Level:  
MEASURE_PERSON_COMPLETENESS
Determine what #/% of persons have at least one record in the cdmTable
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = OBSERVATION
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_PERSON_COMPLETENESS' level,
    'Determine what #/% of persons have at least one record in the cdmTable' check,
    'OBSERVATION' cdmTableName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.person_id) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.person cdmtable
			left join CY_IMOSPHERE_CDM_531.observation cdmtable2 
			on cdmtable.person_id = cdmtable2.person_id
		where cdmtable2.person_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.person cdmtable
) denominator
;

/*********
Table Level:  
MEASURE_PERSON_COMPLETENESS
Determine what #/% of persons have at least one record in the cdmTable
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PAYER_PLAN_PERIOD
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_PERSON_COMPLETENESS' level,
    'Determine what #/% of persons have at least one record in the cdmTable' check,
    'PAYER_PLAN_PERIOD' cdmTableName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.person_id) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.person cdmtable
			left join CY_IMOSPHERE_CDM_531.payer_plan_period cdmtable2 
			on cdmtable.person_id = cdmtable2.person_id
		where cdmtable2.person_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.person cdmtable
) denominator
;

/*********
Table Level:  
MEASURE_PERSON_COMPLETENESS
Determine what #/% of persons have at least one record in the cdmTable
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DRUG_ERA
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_PERSON_COMPLETENESS' level,
    'Determine what #/% of persons have at least one record in the cdmTable' check,
    'DRUG_ERA' cdmTableName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.person_id) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.person cdmtable
			left join CY_IMOSPHERE_CDM_531.drug_era cdmtable2 
			on cdmtable.person_id = cdmtable2.person_id
		where cdmtable2.person_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.person cdmtable
) denominator
;

/*********
Table Level:  
MEASURE_PERSON_COMPLETENESS
Determine what #/% of persons have at least one record in the cdmTable
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_ERA
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_PERSON_COMPLETENESS' level,
    'Determine what #/% of persons have at least one record in the cdmTable' check,
    'CONDITION_ERA' cdmTableName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.person_id) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.person cdmtable
			left join CY_IMOSPHERE_CDM_531.condition_era cdmtable2 
			on cdmtable.person_id = cdmtable2.person_id
		where cdmtable2.person_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.person cdmtable
) denominator
;

