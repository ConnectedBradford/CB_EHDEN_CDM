/*********
PLAUSIBLE_VALUE_HIGH
get number of records and the proportion to total number of eligible records that exceed this threshold
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PERSON
cdmFieldName = YEAR_OF_BIRTH
plausibleValueHigh = YEAR(GETDATE())+1
**********/
select 
	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 'PERSON.YEAR_OF_BIRTH' as violating_field, 
		cdmtable.*
    	from CY_IMOSPHERE_CDM_531.person cdmtable
      		where cdmtable.year_of_birth > EXTRACT(YEAR from CURRENT_DATE())+1
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.person cdmtable
  	where year_of_birth is not null
) denominator
;

/*********
PLAUSIBLE_VALUE_HIGH
get number of records and the proportion to total number of eligible records that exceed this threshold
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PERSON
cdmFieldName = MONTH_OF_BIRTH
plausibleValueHigh = 12
**********/
select 
	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 'PERSON.MONTH_OF_BIRTH' as violating_field, 
		cdmtable.*
    	from CY_IMOSPHERE_CDM_531.person cdmtable
      		where cdmtable.month_of_birth > 12
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.person cdmtable
  	where month_of_birth is not null
) denominator
;

/*********
PLAUSIBLE_VALUE_HIGH
get number of records and the proportion to total number of eligible records that exceed this threshold
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PERSON
cdmFieldName = DAY_OF_BIRTH
plausibleValueHigh = 31
**********/
select 
	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 'PERSON.DAY_OF_BIRTH' as violating_field, 
		cdmtable.*
    	from CY_IMOSPHERE_CDM_531.person cdmtable
      		where cdmtable.day_of_birth > 31
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.person cdmtable
  	where day_of_birth is not null
) denominator
;

/*********
PLAUSIBLE_VALUE_HIGH
get number of records and the proportion to total number of eligible records that exceed this threshold
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PERSON
cdmFieldName = BIRTH_DATETIME
plausibleValueHigh = DATEADD(dd,1,GETDATE())
**********/
select 
	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 'PERSON.BIRTH_DATETIME' as violating_field, 
		cdmtable.*
    	from CY_IMOSPHERE_CDM_531.person cdmtable
      	where IF(SAFE_CAST(cdmtable.birth_datetime  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.birth_datetime  AS STRING)),SAFE_CAST(cdmtable.birth_datetime  AS DATE)) > IF(SAFE_CAST(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS STRING)),SAFE_CAST(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS DATE))
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.person cdmtable
  	where birth_datetime is not null
) denominator
;

/*********
PLAUSIBLE_VALUE_HIGH
get number of records and the proportion to total number of eligible records that exceed this threshold
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = OBSERVATION_PERIOD
cdmFieldName = OBSERVATION_PERIOD_START_DATE
plausibleValueHigh = DATEADD(dd,1,GETDATE())
**********/
select 
	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 'OBSERVATION_PERIOD.OBSERVATION_PERIOD_START_DATE' as violating_field, 
		cdmtable.*
    	from CY_IMOSPHERE_CDM_531.observation_period cdmtable
      	where IF(SAFE_CAST(cdmtable.observation_period_start_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.observation_period_start_date  AS STRING)),SAFE_CAST(cdmtable.observation_period_start_date  AS DATE)) > IF(SAFE_CAST(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS STRING)),SAFE_CAST(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS DATE))
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.observation_period cdmtable
  	where observation_period_start_date is not null
) denominator
;

/*********
PLAUSIBLE_VALUE_HIGH
get number of records and the proportion to total number of eligible records that exceed this threshold
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = OBSERVATION_PERIOD
cdmFieldName = OBSERVATION_PERIOD_END_DATE
plausibleValueHigh = DATEADD(dd,1,GETDATE())
**********/
select 
	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 'OBSERVATION_PERIOD.OBSERVATION_PERIOD_END_DATE' as violating_field, 
		cdmtable.*
    	from CY_IMOSPHERE_CDM_531.observation_period cdmtable
      	where IF(SAFE_CAST(cdmtable.observation_period_end_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.observation_period_end_date  AS STRING)),SAFE_CAST(cdmtable.observation_period_end_date  AS DATE)) > IF(SAFE_CAST(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS STRING)),SAFE_CAST(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS DATE))
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.observation_period cdmtable
  	where observation_period_end_date is not null
) denominator
;

/*********
PLAUSIBLE_VALUE_HIGH
get number of records and the proportion to total number of eligible records that exceed this threshold
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_OCCURRENCE
cdmFieldName = VISIT_START_DATE
plausibleValueHigh = DATEADD(dd,1,GETDATE())
**********/
select 
	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 'VISIT_OCCURRENCE.VISIT_START_DATE' as violating_field, 
		cdmtable.*
    	from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
      	where IF(SAFE_CAST(cdmtable.visit_start_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.visit_start_date  AS STRING)),SAFE_CAST(cdmtable.visit_start_date  AS DATE)) > IF(SAFE_CAST(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS STRING)),SAFE_CAST(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS DATE))
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
  	where visit_start_date is not null
) denominator
;

/*********
PLAUSIBLE_VALUE_HIGH
get number of records and the proportion to total number of eligible records that exceed this threshold
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_OCCURRENCE
cdmFieldName = VISIT_START_DATETIME
plausibleValueHigh = DATEADD(dd,1,GETDATE())
**********/
select 
	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 'VISIT_OCCURRENCE.VISIT_START_DATETIME' as violating_field, 
		cdmtable.*
    	from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
      	where IF(SAFE_CAST(cdmtable.visit_start_datetime  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.visit_start_datetime  AS STRING)),SAFE_CAST(cdmtable.visit_start_datetime  AS DATE)) > IF(SAFE_CAST(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS STRING)),SAFE_CAST(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS DATE))
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
  	where visit_start_datetime is not null
) denominator
;

/*********
PLAUSIBLE_VALUE_HIGH
get number of records and the proportion to total number of eligible records that exceed this threshold
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_OCCURRENCE
cdmFieldName = VISIT_END_DATE
plausibleValueHigh = DATEADD(dd,1,GETDATE())
**********/
select 
	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 'VISIT_OCCURRENCE.VISIT_END_DATE' as violating_field, 
		cdmtable.*
    	from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
      	where IF(SAFE_CAST(cdmtable.visit_end_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.visit_end_date  AS STRING)),SAFE_CAST(cdmtable.visit_end_date  AS DATE)) > IF(SAFE_CAST(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS STRING)),SAFE_CAST(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS DATE))
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
  	where visit_end_date is not null
) denominator
;

/*********
PLAUSIBLE_VALUE_HIGH
get number of records and the proportion to total number of eligible records that exceed this threshold
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_OCCURRENCE
cdmFieldName = VISIT_END_DATETIME
plausibleValueHigh = DATEADD(dd,1,GETDATE())
**********/
select 
	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 'VISIT_OCCURRENCE.VISIT_END_DATETIME' as violating_field, 
		cdmtable.*
    	from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
      	where IF(SAFE_CAST(cdmtable.visit_end_datetime  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.visit_end_datetime  AS STRING)),SAFE_CAST(cdmtable.visit_end_datetime  AS DATE)) > IF(SAFE_CAST(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS STRING)),SAFE_CAST(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS DATE))
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
  	where visit_end_datetime is not null
) denominator
;

/*********
PLAUSIBLE_VALUE_HIGH
get number of records and the proportion to total number of eligible records that exceed this threshold
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_START_DATE
plausibleValueHigh = DATEADD(dd,1,GETDATE())
**********/
select 
	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 'CONDITION_OCCURRENCE.CONDITION_START_DATE' as violating_field, 
		cdmtable.*
    	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
      	where IF(SAFE_CAST(cdmtable.condition_start_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.condition_start_date  AS STRING)),SAFE_CAST(cdmtable.condition_start_date  AS DATE)) > IF(SAFE_CAST(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS STRING)),SAFE_CAST(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS DATE))
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
  	where condition_start_date is not null
) denominator
;

/*********
PLAUSIBLE_VALUE_HIGH
get number of records and the proportion to total number of eligible records that exceed this threshold
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_START_DATETIME
plausibleValueHigh = DATEADD(dd,1,GETDATE())
**********/
select 
	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 'CONDITION_OCCURRENCE.CONDITION_START_DATETIME' as violating_field, 
		cdmtable.*
    	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
      	where IF(SAFE_CAST(cdmtable.condition_start_datetime  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.condition_start_datetime  AS STRING)),SAFE_CAST(cdmtable.condition_start_datetime  AS DATE)) > IF(SAFE_CAST(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS STRING)),SAFE_CAST(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS DATE))
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
  	where condition_start_datetime is not null
) denominator
;

/*********
PLAUSIBLE_VALUE_HIGH
get number of records and the proportion to total number of eligible records that exceed this threshold
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_END_DATE
plausibleValueHigh = DATEADD(dd,1,GETDATE())
**********/
select 
	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 'CONDITION_OCCURRENCE.CONDITION_END_DATE' as violating_field, 
		cdmtable.*
    	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
      	where IF(SAFE_CAST(cdmtable.condition_end_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.condition_end_date  AS STRING)),SAFE_CAST(cdmtable.condition_end_date  AS DATE)) > IF(SAFE_CAST(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS STRING)),SAFE_CAST(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS DATE))
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
  	where condition_end_date is not null
) denominator
;

/*********
PLAUSIBLE_VALUE_HIGH
get number of records and the proportion to total number of eligible records that exceed this threshold
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_END_DATETIME
plausibleValueHigh = DATEADD(dd,1,GETDATE())
**********/
select 
	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 'CONDITION_OCCURRENCE.CONDITION_END_DATETIME' as violating_field, 
		cdmtable.*
    	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
      	where IF(SAFE_CAST(cdmtable.condition_end_datetime  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.condition_end_datetime  AS STRING)),SAFE_CAST(cdmtable.condition_end_datetime  AS DATE)) > IF(SAFE_CAST(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS STRING)),SAFE_CAST(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS DATE))
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
  	where condition_end_datetime is not null
) denominator
;

/*********
PLAUSIBLE_VALUE_HIGH
get number of records and the proportion to total number of eligible records that exceed this threshold
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DRUG_EXPOSURE
cdmFieldName = DRUG_EXPOSURE_START_DATE
plausibleValueHigh = DATEADD(dd,1,GETDATE())
**********/
select 
	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 'DRUG_EXPOSURE.DRUG_EXPOSURE_START_DATE' as violating_field, 
		cdmtable.*
    	from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
      	where IF(SAFE_CAST(cdmtable.drug_exposure_start_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.drug_exposure_start_date  AS STRING)),SAFE_CAST(cdmtable.drug_exposure_start_date  AS DATE)) > IF(SAFE_CAST(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS STRING)),SAFE_CAST(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS DATE))
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
  	where drug_exposure_start_date is not null
) denominator
;

/*********
PLAUSIBLE_VALUE_HIGH
get number of records and the proportion to total number of eligible records that exceed this threshold
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DRUG_EXPOSURE
cdmFieldName = DRUG_EXPOSURE_START_DATETIME
plausibleValueHigh = DATEADD(dd,1,GETDATE())
**********/
select 
	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 'DRUG_EXPOSURE.DRUG_EXPOSURE_START_DATETIME' as violating_field, 
		cdmtable.*
    	from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
      	where IF(SAFE_CAST(cdmtable.drug_exposure_start_datetime  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.drug_exposure_start_datetime  AS STRING)),SAFE_CAST(cdmtable.drug_exposure_start_datetime  AS DATE)) > IF(SAFE_CAST(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS STRING)),SAFE_CAST(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS DATE))
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
  	where drug_exposure_start_datetime is not null
) denominator
;

/*********
PLAUSIBLE_VALUE_HIGH
get number of records and the proportion to total number of eligible records that exceed this threshold
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DRUG_EXPOSURE
cdmFieldName = DRUG_EXPOSURE_END_DATE
plausibleValueHigh = DATEADD(dd,1,GETDATE())
**********/
select 
	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 'DRUG_EXPOSURE.DRUG_EXPOSURE_END_DATE' as violating_field, 
		cdmtable.*
    	from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
      	where IF(SAFE_CAST(cdmtable.drug_exposure_end_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.drug_exposure_end_date  AS STRING)),SAFE_CAST(cdmtable.drug_exposure_end_date  AS DATE)) > IF(SAFE_CAST(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS STRING)),SAFE_CAST(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS DATE))
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
  	where drug_exposure_end_date is not null
) denominator
;

/*********
PLAUSIBLE_VALUE_HIGH
get number of records and the proportion to total number of eligible records that exceed this threshold
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DRUG_EXPOSURE
cdmFieldName = DRUG_EXPOSURE_END_DATETIME
plausibleValueHigh = DATEADD(dd,1,GETDATE())
**********/
select 
	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 'DRUG_EXPOSURE.DRUG_EXPOSURE_END_DATETIME' as violating_field, 
		cdmtable.*
    	from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
      	where IF(SAFE_CAST(cdmtable.drug_exposure_end_datetime  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.drug_exposure_end_datetime  AS STRING)),SAFE_CAST(cdmtable.drug_exposure_end_datetime  AS DATE)) > IF(SAFE_CAST(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS STRING)),SAFE_CAST(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS DATE))
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
  	where drug_exposure_end_datetime is not null
) denominator
;

/*********
PLAUSIBLE_VALUE_HIGH
get number of records and the proportion to total number of eligible records that exceed this threshold
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DRUG_EXPOSURE
cdmFieldName = VERBATIM_END_DATE
plausibleValueHigh = DATEADD(dd,1,GETDATE())
**********/
select 
	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 'DRUG_EXPOSURE.VERBATIM_END_DATE' as violating_field, 
		cdmtable.*
    	from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
      	where IF(SAFE_CAST(cdmtable.verbatim_end_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.verbatim_end_date  AS STRING)),SAFE_CAST(cdmtable.verbatim_end_date  AS DATE)) > IF(SAFE_CAST(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS STRING)),SAFE_CAST(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS DATE))
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
  	where verbatim_end_date is not null
) denominator
;

/*********
PLAUSIBLE_VALUE_HIGH
get number of records and the proportion to total number of eligible records that exceed this threshold
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DRUG_EXPOSURE
cdmFieldName = REFILLS
plausibleValueHigh = 12
**********/
select 
	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 'DRUG_EXPOSURE.REFILLS' as violating_field, 
		cdmtable.*
    	from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
      		where cdmtable.refills > 12
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
  	where refills is not null
) denominator
;

/*********
PLAUSIBLE_VALUE_HIGH
get number of records and the proportion to total number of eligible records that exceed this threshold
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DRUG_EXPOSURE
cdmFieldName = QUANTITY
plausibleValueHigh = 1095
**********/
select 
	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 'DRUG_EXPOSURE.QUANTITY' as violating_field, 
		cdmtable.*
    	from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
      		where cdmtable.quantity > 1095
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
  	where quantity is not null
) denominator
;

/*********
PLAUSIBLE_VALUE_HIGH
get number of records and the proportion to total number of eligible records that exceed this threshold
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DRUG_EXPOSURE
cdmFieldName = DAYS_SUPPLY
plausibleValueHigh = 365
**********/
select 
	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 'DRUG_EXPOSURE.DAYS_SUPPLY' as violating_field, 
		cdmtable.*
    	from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
      		where cdmtable.days_supply > 365
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
  	where days_supply is not null
) denominator
;

/*********
PLAUSIBLE_VALUE_HIGH
get number of records and the proportion to total number of eligible records that exceed this threshold
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_DATE
plausibleValueHigh = DATEADD(dd,1,GETDATE())
**********/
select 
	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 'PROCEDURE_OCCURRENCE.PROCEDURE_DATE' as violating_field, 
		cdmtable.*
    	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
      	where IF(SAFE_CAST(cdmtable.procedure_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.procedure_date  AS STRING)),SAFE_CAST(cdmtable.procedure_date  AS DATE)) > IF(SAFE_CAST(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS STRING)),SAFE_CAST(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS DATE))
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
  	where procedure_date is not null
) denominator
;

/*********
PLAUSIBLE_VALUE_HIGH
get number of records and the proportion to total number of eligible records that exceed this threshold
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_DATETIME
plausibleValueHigh = DATEADD(dd,1,GETDATE())
**********/
select 
	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 'PROCEDURE_OCCURRENCE.PROCEDURE_DATETIME' as violating_field, 
		cdmtable.*
    	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
      	where IF(SAFE_CAST(cdmtable.procedure_datetime  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.procedure_datetime  AS STRING)),SAFE_CAST(cdmtable.procedure_datetime  AS DATE)) > IF(SAFE_CAST(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS STRING)),SAFE_CAST(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS DATE))
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
  	where procedure_datetime is not null
) denominator
;

/*********
PLAUSIBLE_VALUE_HIGH
get number of records and the proportion to total number of eligible records that exceed this threshold
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DEVICE_EXPOSURE
cdmFieldName = DEVICE_EXPOSURE_START_DATE
plausibleValueHigh = DATEADD(dd,1,GETDATE())
**********/
select 
	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 'DEVICE_EXPOSURE.DEVICE_EXPOSURE_START_DATE' as violating_field, 
		cdmtable.*
    	from CY_IMOSPHERE_CDM_531.device_exposure cdmtable
      	where IF(SAFE_CAST(cdmtable.device_exposure_start_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.device_exposure_start_date  AS STRING)),SAFE_CAST(cdmtable.device_exposure_start_date  AS DATE)) > IF(SAFE_CAST(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS STRING)),SAFE_CAST(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS DATE))
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.device_exposure cdmtable
  	where device_exposure_start_date is not null
) denominator
;

/*********
PLAUSIBLE_VALUE_HIGH
get number of records and the proportion to total number of eligible records that exceed this threshold
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DEVICE_EXPOSURE
cdmFieldName = DEVICE_EXPOSURE_START_DATETIME
plausibleValueHigh = DATEADD(dd,1,GETDATE())
**********/
select 
	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 'DEVICE_EXPOSURE.DEVICE_EXPOSURE_START_DATETIME' as violating_field, 
		cdmtable.*
    	from CY_IMOSPHERE_CDM_531.device_exposure cdmtable
      	where IF(SAFE_CAST(cdmtable.device_exposure_start_datetime  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.device_exposure_start_datetime  AS STRING)),SAFE_CAST(cdmtable.device_exposure_start_datetime  AS DATE)) > IF(SAFE_CAST(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS STRING)),SAFE_CAST(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS DATE))
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.device_exposure cdmtable
  	where device_exposure_start_datetime is not null
) denominator
;

/*********
PLAUSIBLE_VALUE_HIGH
get number of records and the proportion to total number of eligible records that exceed this threshold
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DEVICE_EXPOSURE
cdmFieldName = DEVICE_EXPOSURE_END_DATE
plausibleValueHigh = DATEADD(dd,1,GETDATE())
**********/
select 
	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 'DEVICE_EXPOSURE.DEVICE_EXPOSURE_END_DATE' as violating_field, 
		cdmtable.*
    	from CY_IMOSPHERE_CDM_531.device_exposure cdmtable
      	where IF(SAFE_CAST(cdmtable.device_exposure_end_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.device_exposure_end_date  AS STRING)),SAFE_CAST(cdmtable.device_exposure_end_date  AS DATE)) > IF(SAFE_CAST(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS STRING)),SAFE_CAST(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS DATE))
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.device_exposure cdmtable
  	where device_exposure_end_date is not null
) denominator
;

/*********
PLAUSIBLE_VALUE_HIGH
get number of records and the proportion to total number of eligible records that exceed this threshold
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DEVICE_EXPOSURE
cdmFieldName = DEVICE_EXPOSURE_END_DATETIME
plausibleValueHigh = DATEADD(dd,1,GETDATE())
**********/
select 
	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 'DEVICE_EXPOSURE.DEVICE_EXPOSURE_END_DATETIME' as violating_field, 
		cdmtable.*
    	from CY_IMOSPHERE_CDM_531.device_exposure cdmtable
      	where IF(SAFE_CAST(cdmtable.device_exposure_end_datetime  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.device_exposure_end_datetime  AS STRING)),SAFE_CAST(cdmtable.device_exposure_end_datetime  AS DATE)) > IF(SAFE_CAST(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS STRING)),SAFE_CAST(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS DATE))
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.device_exposure cdmtable
  	where device_exposure_end_datetime is not null
) denominator
;

/*********
PLAUSIBLE_VALUE_HIGH
get number of records and the proportion to total number of eligible records that exceed this threshold
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = MEASUREMENT
cdmFieldName = MEASUREMENT_DATE
plausibleValueHigh = DATEADD(dd,1,GETDATE())
**********/
select 
	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 'MEASUREMENT.MEASUREMENT_DATE' as violating_field, 
		cdmtable.*
    	from CY_IMOSPHERE_CDM_531.measurement cdmtable
      	where IF(SAFE_CAST(cdmtable.measurement_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.measurement_date  AS STRING)),SAFE_CAST(cdmtable.measurement_date  AS DATE)) > IF(SAFE_CAST(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS STRING)),SAFE_CAST(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS DATE))
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.measurement cdmtable
  	where measurement_date is not null
) denominator
;

/*********
PLAUSIBLE_VALUE_HIGH
get number of records and the proportion to total number of eligible records that exceed this threshold
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_DETAIL
cdmFieldName = VISIT_DETAIL_START_DATE
plausibleValueHigh = DATEADD(dd,1,GETDATE())
**********/
select 
	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 'VISIT_DETAIL.VISIT_DETAIL_START_DATE' as violating_field, 
		cdmtable.*
    	from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
      	where IF(SAFE_CAST(cdmtable.visit_detail_start_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.visit_detail_start_date  AS STRING)),SAFE_CAST(cdmtable.visit_detail_start_date  AS DATE)) > IF(SAFE_CAST(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS STRING)),SAFE_CAST(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS DATE))
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
  	where visit_detail_start_date is not null
) denominator
;

/*********
PLAUSIBLE_VALUE_HIGH
get number of records and the proportion to total number of eligible records that exceed this threshold
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_DETAIL
cdmFieldName = VISIT_DETAIL_START_DATETIME
plausibleValueHigh = DATEADD(dd,1,GETDATE())
**********/
select 
	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 'VISIT_DETAIL.VISIT_DETAIL_START_DATETIME' as violating_field, 
		cdmtable.*
    	from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
      	where IF(SAFE_CAST(cdmtable.visit_detail_start_datetime  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.visit_detail_start_datetime  AS STRING)),SAFE_CAST(cdmtable.visit_detail_start_datetime  AS DATE)) > IF(SAFE_CAST(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS STRING)),SAFE_CAST(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS DATE))
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
  	where visit_detail_start_datetime is not null
) denominator
;

/*********
PLAUSIBLE_VALUE_HIGH
get number of records and the proportion to total number of eligible records that exceed this threshold
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_DETAIL
cdmFieldName = VISIT_DETAIL_END_DATE
plausibleValueHigh = DATEADD(dd,1,GETDATE())
**********/
select 
	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 'VISIT_DETAIL.VISIT_DETAIL_END_DATE' as violating_field, 
		cdmtable.*
    	from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
      	where IF(SAFE_CAST(cdmtable.visit_detail_end_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.visit_detail_end_date  AS STRING)),SAFE_CAST(cdmtable.visit_detail_end_date  AS DATE)) > IF(SAFE_CAST(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS STRING)),SAFE_CAST(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS DATE))
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
  	where visit_detail_end_date is not null
) denominator
;

/*********
PLAUSIBLE_VALUE_HIGH
get number of records and the proportion to total number of eligible records that exceed this threshold
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_DETAIL
cdmFieldName = VISIT_DETAIL_END_DATETIME
plausibleValueHigh = DATEADD(dd,1,GETDATE())
**********/
select 
	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 'VISIT_DETAIL.VISIT_DETAIL_END_DATETIME' as violating_field, 
		cdmtable.*
    	from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
      	where IF(SAFE_CAST(cdmtable.visit_detail_end_datetime  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.visit_detail_end_datetime  AS STRING)),SAFE_CAST(cdmtable.visit_detail_end_datetime  AS DATE)) > IF(SAFE_CAST(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS STRING)),SAFE_CAST(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS DATE))
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
  	where visit_detail_end_datetime is not null
) denominator
;

/*********
PLAUSIBLE_VALUE_HIGH
get number of records and the proportion to total number of eligible records that exceed this threshold
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = NOTE
cdmFieldName = NOTE_DATE
plausibleValueHigh = DATEADD(dd,1,GETDATE())
**********/
select 
	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 'NOTE.NOTE_DATE' as violating_field, 
		cdmtable.*
    	from CY_IMOSPHERE_CDM_531.note cdmtable
      	where IF(SAFE_CAST(cdmtable.note_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.note_date  AS STRING)),SAFE_CAST(cdmtable.note_date  AS DATE)) > IF(SAFE_CAST(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS STRING)),SAFE_CAST(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS DATE))
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.note cdmtable
  	where note_date is not null
) denominator
;

/*********
PLAUSIBLE_VALUE_HIGH
get number of records and the proportion to total number of eligible records that exceed this threshold
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = NOTE
cdmFieldName = NOTE_DATETIME
plausibleValueHigh = DATEADD(dd,1,GETDATE())
**********/
select 
	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 'NOTE.NOTE_DATETIME' as violating_field, 
		cdmtable.*
    	from CY_IMOSPHERE_CDM_531.note cdmtable
      	where IF(SAFE_CAST(cdmtable.note_datetime  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.note_datetime  AS STRING)),SAFE_CAST(cdmtable.note_datetime  AS DATE)) > IF(SAFE_CAST(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS STRING)),SAFE_CAST(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS DATE))
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.note cdmtable
  	where note_datetime is not null
) denominator
;

/*********
PLAUSIBLE_VALUE_HIGH
get number of records and the proportion to total number of eligible records that exceed this threshold
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = NOTE_NLP
cdmFieldName = NLP_DATETIME
plausibleValueHigh = DATEADD(dd,1,GETDATE())
**********/
select 
	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 'NOTE_NLP.NLP_DATETIME' as violating_field, 
		cdmtable.*
    	from CY_IMOSPHERE_CDM_531.note_nlp cdmtable
      	where IF(SAFE_CAST(cdmtable.nlp_datetime  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.nlp_datetime  AS STRING)),SAFE_CAST(cdmtable.nlp_datetime  AS DATE)) > IF(SAFE_CAST(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS STRING)),SAFE_CAST(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS DATE))
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.note_nlp cdmtable
  	where nlp_datetime is not null
) denominator
;

/*********
PLAUSIBLE_VALUE_HIGH
get number of records and the proportion to total number of eligible records that exceed this threshold
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = OBSERVATION
cdmFieldName = OBSERVATION_DATE
plausibleValueHigh = DATEADD(dd,1,GETDATE())
**********/
select 
	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 'OBSERVATION.OBSERVATION_DATE' as violating_field, 
		cdmtable.*
    	from CY_IMOSPHERE_CDM_531.observation cdmtable
      	where IF(SAFE_CAST(cdmtable.observation_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.observation_date  AS STRING)),SAFE_CAST(cdmtable.observation_date  AS DATE)) > IF(SAFE_CAST(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS STRING)),SAFE_CAST(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS DATE))
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.observation cdmtable
  	where observation_date is not null
) denominator
;

/*********
PLAUSIBLE_VALUE_HIGH
get number of records and the proportion to total number of eligible records that exceed this threshold
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = OBSERVATION
cdmFieldName = OBSERVATION_DATETIME
plausibleValueHigh = DATEADD(dd,1,GETDATE())
**********/
select 
	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 'OBSERVATION.OBSERVATION_DATETIME' as violating_field, 
		cdmtable.*
    	from CY_IMOSPHERE_CDM_531.observation cdmtable
      	where IF(SAFE_CAST(cdmtable.observation_datetime  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.observation_datetime  AS STRING)),SAFE_CAST(cdmtable.observation_datetime  AS DATE)) > IF(SAFE_CAST(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS STRING)),SAFE_CAST(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS DATE))
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.observation cdmtable
  	where observation_datetime is not null
) denominator
;

/*********
PLAUSIBLE_VALUE_HIGH
get number of records and the proportion to total number of eligible records that exceed this threshold
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DRUG_ERA
cdmFieldName = DRUG_ERA_START_DATE
plausibleValueHigh = DATEADD(dd,1,GETDATE())
**********/
select 
	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 'DRUG_ERA.DRUG_ERA_START_DATE' as violating_field, 
		cdmtable.*
    	from CY_IMOSPHERE_CDM_531.drug_era cdmtable
      	where IF(SAFE_CAST(cdmtable.drug_era_start_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.drug_era_start_date  AS STRING)),SAFE_CAST(cdmtable.drug_era_start_date  AS DATE)) > IF(SAFE_CAST(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS STRING)),SAFE_CAST(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS DATE))
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.drug_era cdmtable
  	where drug_era_start_date is not null
) denominator
;

/*********
PLAUSIBLE_VALUE_HIGH
get number of records and the proportion to total number of eligible records that exceed this threshold
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DRUG_ERA
cdmFieldName = DRUG_ERA_END_DATE
plausibleValueHigh = DATEADD(dd,1,GETDATE())
**********/
select 
	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 'DRUG_ERA.DRUG_ERA_END_DATE' as violating_field, 
		cdmtable.*
    	from CY_IMOSPHERE_CDM_531.drug_era cdmtable
      	where IF(SAFE_CAST(cdmtable.drug_era_end_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.drug_era_end_date  AS STRING)),SAFE_CAST(cdmtable.drug_era_end_date  AS DATE)) > IF(SAFE_CAST(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS STRING)),SAFE_CAST(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS DATE))
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.drug_era cdmtable
  	where drug_era_end_date is not null
) denominator
;

/*********
PLAUSIBLE_VALUE_HIGH
get number of records and the proportion to total number of eligible records that exceed this threshold
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_ERA
cdmFieldName = CONDITION_ERA_START_DATE
plausibleValueHigh = DATEADD(dd,1,GETDATE())
**********/
select 
	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 'CONDITION_ERA.CONDITION_ERA_START_DATE' as violating_field, 
		cdmtable.*
    	from CY_IMOSPHERE_CDM_531.condition_era cdmtable
      	where IF(SAFE_CAST(cdmtable.condition_era_start_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.condition_era_start_date  AS STRING)),SAFE_CAST(cdmtable.condition_era_start_date  AS DATE)) > IF(SAFE_CAST(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS STRING)),SAFE_CAST(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS DATE))
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_era cdmtable
  	where condition_era_start_date is not null
) denominator
;

/*********
PLAUSIBLE_VALUE_HIGH
get number of records and the proportion to total number of eligible records that exceed this threshold
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_ERA
cdmFieldName = CONDITION_ERA_END_DATE
plausibleValueHigh = DATEADD(dd,1,GETDATE())
**********/
select 
	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  	denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 'CONDITION_ERA.CONDITION_ERA_END_DATE' as violating_field, 
		cdmtable.*
    	from CY_IMOSPHERE_CDM_531.condition_era cdmtable
      	where IF(SAFE_CAST(cdmtable.condition_era_end_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(cdmtable.condition_era_end_date  AS STRING)),SAFE_CAST(cdmtable.condition_era_end_date  AS DATE)) > IF(SAFE_CAST(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS STRING)),SAFE_CAST(DATE_ADD(IF(SAFE_CAST(CURRENT_DATE()  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(CURRENT_DATE()  AS STRING)),SAFE_CAST(CURRENT_DATE()  AS DATE)), INTERVAL 1 DAY)  AS DATE))
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
(
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_era cdmtable
  	where condition_era_end_date is not null
) denominator
;

