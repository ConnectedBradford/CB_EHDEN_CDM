/*********
TABLE LEVEL check:
CDM_TABLE - verify the table exists
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PERSON
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
   cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'Table' level,
    'verify the table exists' check,
    'PERSON' cdmTableName,
    '' cdmFieldName,
      num_violated_rows, 
  case 
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows 
  end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
  select 
    num_violated_rows 
  from
  (
    select
      case 
        when COUNT(*) = 0 then 0
        else 0
    end as num_violated_rows
    from CY_IMOSPHERE_CDM_531.person cdmtable
  ) violated_rows
) violated_row_count,
( 
	select 1 as num_rows
) denominator
;

/*********
TABLE LEVEL check:
CDM_TABLE - verify the table exists
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = OBSERVATION_PERIOD
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
   cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'Table' level,
    'verify the table exists' check,
    'OBSERVATION_PERIOD' cdmTableName,
    '' cdmFieldName,
      num_violated_rows, 
  case 
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows 
  end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
  select 
    num_violated_rows 
  from
  (
    select
      case 
        when COUNT(*) = 0 then 0
        else 0
    end as num_violated_rows
    from CY_IMOSPHERE_CDM_531.observation_period cdmtable
  ) violated_rows
) violated_row_count,
( 
	select 1 as num_rows
) denominator
;

/*********
TABLE LEVEL check:
CDM_TABLE - verify the table exists
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_OCCURRENCE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
   cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'Table' level,
    'verify the table exists' check,
    'VISIT_OCCURRENCE' cdmTableName,
    '' cdmFieldName,
      num_violated_rows, 
  case 
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows 
  end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
  select 
    num_violated_rows 
  from
  (
    select
      case 
        when COUNT(*) = 0 then 0
        else 0
    end as num_violated_rows
    from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
  ) violated_rows
) violated_row_count,
( 
	select 1 as num_rows
) denominator
;

/*********
TABLE LEVEL check:
CDM_TABLE - verify the table exists
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
   cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'Table' level,
    'verify the table exists' check,
    'CONDITION_OCCURRENCE' cdmTableName,
    '' cdmFieldName,
      num_violated_rows, 
  case 
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows 
  end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
  select 
    num_violated_rows 
  from
  (
    select
      case 
        when COUNT(*) = 0 then 0
        else 0
    end as num_violated_rows
    from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
  ) violated_rows
) violated_row_count,
( 
	select 1 as num_rows
) denominator
;

/*********
TABLE LEVEL check:
CDM_TABLE - verify the table exists
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DRUG_EXPOSURE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
   cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'Table' level,
    'verify the table exists' check,
    'DRUG_EXPOSURE' cdmTableName,
    '' cdmFieldName,
      num_violated_rows, 
  case 
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows 
  end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
  select 
    num_violated_rows 
  from
  (
    select
      case 
        when COUNT(*) = 0 then 0
        else 0
    end as num_violated_rows
    from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
  ) violated_rows
) violated_row_count,
( 
	select 1 as num_rows
) denominator
;

/*********
TABLE LEVEL check:
CDM_TABLE - verify the table exists
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
   cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'Table' level,
    'verify the table exists' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
    '' cdmFieldName,
      num_violated_rows, 
  case 
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows 
  end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
  select 
    num_violated_rows 
  from
  (
    select
      case 
        when COUNT(*) = 0 then 0
        else 0
    end as num_violated_rows
    from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
  ) violated_rows
) violated_row_count,
( 
	select 1 as num_rows
) denominator
;

/*********
TABLE LEVEL check:
CDM_TABLE - verify the table exists
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DEVICE_EXPOSURE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
   cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'Table' level,
    'verify the table exists' check,
    'DEVICE_EXPOSURE' cdmTableName,
    '' cdmFieldName,
      num_violated_rows, 
  case 
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows 
  end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
  select 
    num_violated_rows 
  from
  (
    select
      case 
        when COUNT(*) = 0 then 0
        else 0
    end as num_violated_rows
    from CY_IMOSPHERE_CDM_531.device_exposure cdmtable
  ) violated_rows
) violated_row_count,
( 
	select 1 as num_rows
) denominator
;

/*********
TABLE LEVEL check:
CDM_TABLE - verify the table exists
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = MEASUREMENT
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
   cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'Table' level,
    'verify the table exists' check,
    'MEASUREMENT' cdmTableName,
    '' cdmFieldName,
      num_violated_rows, 
  case 
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows 
  end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
  select 
    num_violated_rows 
  from
  (
    select
      case 
        when COUNT(*) = 0 then 0
        else 0
    end as num_violated_rows
    from CY_IMOSPHERE_CDM_531.measurement cdmtable
  ) violated_rows
) violated_row_count,
( 
	select 1 as num_rows
) denominator
;

/*********
TABLE LEVEL check:
CDM_TABLE - verify the table exists
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_DETAIL
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
   cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'Table' level,
    'verify the table exists' check,
    'VISIT_DETAIL' cdmTableName,
    '' cdmFieldName,
      num_violated_rows, 
  case 
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows 
  end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
  select 
    num_violated_rows 
  from
  (
    select
      case 
        when COUNT(*) = 0 then 0
        else 0
    end as num_violated_rows
    from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
  ) violated_rows
) violated_row_count,
( 
	select 1 as num_rows
) denominator
;

/*********
TABLE LEVEL check:
CDM_TABLE - verify the table exists
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = NOTE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
   cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'Table' level,
    'verify the table exists' check,
    'NOTE' cdmTableName,
    '' cdmFieldName,
      num_violated_rows, 
  case 
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows 
  end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
  select 
    num_violated_rows 
  from
  (
    select
      case 
        when COUNT(*) = 0 then 0
        else 0
    end as num_violated_rows
    from CY_IMOSPHERE_CDM_531.note cdmtable
  ) violated_rows
) violated_row_count,
( 
	select 1 as num_rows
) denominator
;

/*********
TABLE LEVEL check:
CDM_TABLE - verify the table exists
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = NOTE_NLP
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
   cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'Table' level,
    'verify the table exists' check,
    'NOTE_NLP' cdmTableName,
    '' cdmFieldName,
      num_violated_rows, 
  case 
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows 
  end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
  select 
    num_violated_rows 
  from
  (
    select
      case 
        when COUNT(*) = 0 then 0
        else 0
    end as num_violated_rows
    from CY_IMOSPHERE_CDM_531.note_nlp cdmtable
  ) violated_rows
) violated_row_count,
( 
	select 1 as num_rows
) denominator
;

/*********
TABLE LEVEL check:
CDM_TABLE - verify the table exists
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = OBSERVATION
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
   cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'Table' level,
    'verify the table exists' check,
    'OBSERVATION' cdmTableName,
    '' cdmFieldName,
      num_violated_rows, 
  case 
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows 
  end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
  select 
    num_violated_rows 
  from
  (
    select
      case 
        when COUNT(*) = 0 then 0
        else 0
    end as num_violated_rows
    from CY_IMOSPHERE_CDM_531.observation cdmtable
  ) violated_rows
) violated_row_count,
( 
	select 1 as num_rows
) denominator
;

/*********
TABLE LEVEL check:
CDM_TABLE - verify the table exists
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = FACT_RELATIONSHIP
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
   cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'Table' level,
    'verify the table exists' check,
    'FACT_RELATIONSHIP' cdmTableName,
    '' cdmFieldName,
      num_violated_rows, 
  case 
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows 
  end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
  select 
    num_violated_rows 
  from
  (
    select
      case 
        when COUNT(*) = 0 then 0
        else 0
    end as num_violated_rows
    from CY_IMOSPHERE_CDM_531.fact_relationship cdmtable
  ) violated_rows
) violated_row_count,
( 
	select 1 as num_rows
) denominator
;

/*********
TABLE LEVEL check:
CDM_TABLE - verify the table exists
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = LOCATION
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
   cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'Table' level,
    'verify the table exists' check,
    'LOCATION' cdmTableName,
    '' cdmFieldName,
      num_violated_rows, 
  case 
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows 
  end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
  select 
    num_violated_rows 
  from
  (
    select
      case 
        when COUNT(*) = 0 then 0
        else 0
    end as num_violated_rows
    from CY_IMOSPHERE_CDM_531.location cdmtable
  ) violated_rows
) violated_row_count,
( 
	select 1 as num_rows
) denominator
;

/*********
TABLE LEVEL check:
CDM_TABLE - verify the table exists
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CARE_SITE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
   cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'Table' level,
    'verify the table exists' check,
    'CARE_SITE' cdmTableName,
    '' cdmFieldName,
      num_violated_rows, 
  case 
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows 
  end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
  select 
    num_violated_rows 
  from
  (
    select
      case 
        when COUNT(*) = 0 then 0
        else 0
    end as num_violated_rows
    from CY_IMOSPHERE_CDM_531.care_site cdmtable
  ) violated_rows
) violated_row_count,
( 
	select 1 as num_rows
) denominator
;

/*********
TABLE LEVEL check:
CDM_TABLE - verify the table exists
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROVIDER
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
   cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'Table' level,
    'verify the table exists' check,
    'PROVIDER' cdmTableName,
    '' cdmFieldName,
      num_violated_rows, 
  case 
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows 
  end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
  select 
    num_violated_rows 
  from
  (
    select
      case 
        when COUNT(*) = 0 then 0
        else 0
    end as num_violated_rows
    from CY_IMOSPHERE_CDM_531.provider cdmtable
  ) violated_rows
) violated_row_count,
( 
	select 1 as num_rows
) denominator
;

/*********
TABLE LEVEL check:
CDM_TABLE - verify the table exists
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PAYER_PLAN_PERIOD
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
   cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'Table' level,
    'verify the table exists' check,
    'PAYER_PLAN_PERIOD' cdmTableName,
    '' cdmFieldName,
      num_violated_rows, 
  case 
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows 
  end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
  select 
    num_violated_rows 
  from
  (
    select
      case 
        when COUNT(*) = 0 then 0
        else 0
    end as num_violated_rows
    from CY_IMOSPHERE_CDM_531.payer_plan_period cdmtable
  ) violated_rows
) violated_row_count,
( 
	select 1 as num_rows
) denominator
;

/*********
TABLE LEVEL check:
CDM_TABLE - verify the table exists
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DRUG_ERA
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
   cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'Table' level,
    'verify the table exists' check,
    'DRUG_ERA' cdmTableName,
    '' cdmFieldName,
      num_violated_rows, 
  case 
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows 
  end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
  select 
    num_violated_rows 
  from
  (
    select
      case 
        when COUNT(*) = 0 then 0
        else 0
    end as num_violated_rows
    from CY_IMOSPHERE_CDM_531.drug_era cdmtable
  ) violated_rows
) violated_row_count,
( 
	select 1 as num_rows
) denominator
;

/*********
TABLE LEVEL check:
CDM_TABLE - verify the table exists
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_ERA
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
   cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'Table' level,
    'verify the table exists' check,
    'CONDITION_ERA' cdmTableName,
    '' cdmFieldName,
      num_violated_rows, 
  case 
    when denominator.num_rows = 0 then 0 
    else 1.0*num_violated_rows/denominator.num_rows 
  end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
  select 
    num_violated_rows 
  from
  (
    select
      case 
        when COUNT(*) = 0 then 0
        else 0
    end as num_violated_rows
    from CY_IMOSPHERE_CDM_531.condition_era cdmtable
  ) violated_rows
) violated_row_count,
( 
	select 1 as num_rows
) denominator
;

