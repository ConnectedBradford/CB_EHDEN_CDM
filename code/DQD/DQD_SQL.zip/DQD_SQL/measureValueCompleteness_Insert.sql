/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PERSON
cdmFieldName = PERSON_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'PERSON' cdmTableName,
'PERSON_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'PERSON.PERSON_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.person cdmtable
		where cdmtable.person_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.person cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PERSON
cdmFieldName = GENDER_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'PERSON' cdmTableName,
'GENDER_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'PERSON.GENDER_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.person cdmtable
		where cdmtable.gender_concept_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.person cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PERSON
cdmFieldName = YEAR_OF_BIRTH
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'PERSON' cdmTableName,
'YEAR_OF_BIRTH' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'PERSON.YEAR_OF_BIRTH' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.person cdmtable
		where cdmtable.year_of_birth is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.person cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PERSON
cdmFieldName = MONTH_OF_BIRTH
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'PERSON' cdmTableName,
'MONTH_OF_BIRTH' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'PERSON.MONTH_OF_BIRTH' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.person cdmtable
		where cdmtable.month_of_birth is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.person cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PERSON
cdmFieldName = DAY_OF_BIRTH
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'PERSON' cdmTableName,
'DAY_OF_BIRTH' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'PERSON.DAY_OF_BIRTH' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.person cdmtable
		where cdmtable.day_of_birth is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.person cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PERSON
cdmFieldName = BIRTH_DATETIME
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'PERSON' cdmTableName,
'BIRTH_DATETIME' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'PERSON.BIRTH_DATETIME' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.person cdmtable
		where cdmtable.birth_datetime is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.person cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PERSON
cdmFieldName = RACE_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'PERSON' cdmTableName,
'RACE_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'PERSON.RACE_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.person cdmtable
		where cdmtable.race_concept_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.person cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PERSON
cdmFieldName = ETHNICITY_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'PERSON' cdmTableName,
'ETHNICITY_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'PERSON.ETHNICITY_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.person cdmtable
		where cdmtable.ethnicity_concept_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.person cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PERSON
cdmFieldName = LOCATION_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'PERSON' cdmTableName,
'LOCATION_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'PERSON.LOCATION_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.person cdmtable
		where cdmtable.location_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.person cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PERSON
cdmFieldName = PROVIDER_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'PERSON' cdmTableName,
'PROVIDER_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'PERSON.PROVIDER_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.person cdmtable
		where cdmtable.provider_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.person cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PERSON
cdmFieldName = CARE_SITE_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'PERSON' cdmTableName,
'CARE_SITE_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'PERSON.CARE_SITE_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.person cdmtable
		where cdmtable.care_site_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.person cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PERSON
cdmFieldName = PERSON_SOURCE_VALUE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'PERSON' cdmTableName,
'PERSON_SOURCE_VALUE' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'PERSON.PERSON_SOURCE_VALUE' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.person cdmtable
		where cdmtable.person_source_value is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.person cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PERSON
cdmFieldName = GENDER_SOURCE_VALUE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'PERSON' cdmTableName,
'GENDER_SOURCE_VALUE' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'PERSON.GENDER_SOURCE_VALUE' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.person cdmtable
		where cdmtable.gender_source_value is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.person cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PERSON
cdmFieldName = GENDER_SOURCE_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'PERSON' cdmTableName,
'GENDER_SOURCE_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'PERSON.GENDER_SOURCE_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.person cdmtable
		where cdmtable.gender_source_concept_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.person cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PERSON
cdmFieldName = RACE_SOURCE_VALUE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'PERSON' cdmTableName,
'RACE_SOURCE_VALUE' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'PERSON.RACE_SOURCE_VALUE' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.person cdmtable
		where cdmtable.race_source_value is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.person cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PERSON
cdmFieldName = RACE_SOURCE_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'PERSON' cdmTableName,
'RACE_SOURCE_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'PERSON.RACE_SOURCE_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.person cdmtable
		where cdmtable.race_source_concept_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.person cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PERSON
cdmFieldName = ETHNICITY_SOURCE_VALUE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'PERSON' cdmTableName,
'ETHNICITY_SOURCE_VALUE' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'PERSON.ETHNICITY_SOURCE_VALUE' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.person cdmtable
		where cdmtable.ethnicity_source_value is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.person cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PERSON
cdmFieldName = ETHNICITY_SOURCE_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'PERSON' cdmTableName,
'ETHNICITY_SOURCE_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'PERSON.ETHNICITY_SOURCE_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.person cdmtable
		where cdmtable.ethnicity_source_concept_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.person cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = OBSERVATION_PERIOD
cdmFieldName = OBSERVATION_PERIOD_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'OBSERVATION_PERIOD' cdmTableName,
'OBSERVATION_PERIOD_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'OBSERVATION_PERIOD.OBSERVATION_PERIOD_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.observation_period cdmtable
		where cdmtable.observation_period_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.observation_period cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = OBSERVATION_PERIOD
cdmFieldName = PERSON_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'OBSERVATION_PERIOD' cdmTableName,
'PERSON_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'OBSERVATION_PERIOD.PERSON_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.observation_period cdmtable
		where cdmtable.person_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.observation_period cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = OBSERVATION_PERIOD
cdmFieldName = OBSERVATION_PERIOD_START_DATE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'OBSERVATION_PERIOD' cdmTableName,
'OBSERVATION_PERIOD_START_DATE' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'OBSERVATION_PERIOD.OBSERVATION_PERIOD_START_DATE' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.observation_period cdmtable
		where cdmtable.observation_period_start_date is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.observation_period cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = OBSERVATION_PERIOD
cdmFieldName = OBSERVATION_PERIOD_END_DATE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'OBSERVATION_PERIOD' cdmTableName,
'OBSERVATION_PERIOD_END_DATE' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'OBSERVATION_PERIOD.OBSERVATION_PERIOD_END_DATE' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.observation_period cdmtable
		where cdmtable.observation_period_end_date is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.observation_period cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = OBSERVATION_PERIOD
cdmFieldName = PERIOD_TYPE_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'OBSERVATION_PERIOD' cdmTableName,
'PERIOD_TYPE_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'OBSERVATION_PERIOD.PERIOD_TYPE_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.observation_period cdmtable
		where cdmtable.period_type_concept_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.observation_period cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_OCCURRENCE
cdmFieldName = VISIT_OCCURRENCE_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'VISIT_OCCURRENCE' cdmTableName,
'VISIT_OCCURRENCE_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'VISIT_OCCURRENCE.VISIT_OCCURRENCE_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
		where cdmtable.visit_occurrence_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_OCCURRENCE
cdmFieldName = PERSON_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'VISIT_OCCURRENCE' cdmTableName,
'PERSON_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'VISIT_OCCURRENCE.PERSON_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
		where cdmtable.person_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_OCCURRENCE
cdmFieldName = VISIT_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'VISIT_OCCURRENCE' cdmTableName,
'VISIT_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'VISIT_OCCURRENCE.VISIT_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
		where cdmtable.visit_concept_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_OCCURRENCE
cdmFieldName = VISIT_START_DATE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'VISIT_OCCURRENCE' cdmTableName,
'VISIT_START_DATE' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'VISIT_OCCURRENCE.VISIT_START_DATE' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
		where cdmtable.visit_start_date is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_OCCURRENCE
cdmFieldName = VISIT_START_DATETIME
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'VISIT_OCCURRENCE' cdmTableName,
'VISIT_START_DATETIME' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'VISIT_OCCURRENCE.VISIT_START_DATETIME' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
		where cdmtable.visit_start_datetime is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_OCCURRENCE
cdmFieldName = VISIT_END_DATE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'VISIT_OCCURRENCE' cdmTableName,
'VISIT_END_DATE' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'VISIT_OCCURRENCE.VISIT_END_DATE' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
		where cdmtable.visit_end_date is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_OCCURRENCE
cdmFieldName = VISIT_END_DATETIME
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'VISIT_OCCURRENCE' cdmTableName,
'VISIT_END_DATETIME' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'VISIT_OCCURRENCE.VISIT_END_DATETIME' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
		where cdmtable.visit_end_datetime is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_OCCURRENCE
cdmFieldName = VISIT_TYPE_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'VISIT_OCCURRENCE' cdmTableName,
'VISIT_TYPE_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'VISIT_OCCURRENCE.VISIT_TYPE_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
		where cdmtable.visit_type_concept_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_OCCURRENCE
cdmFieldName = PROVIDER_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'VISIT_OCCURRENCE' cdmTableName,
'PROVIDER_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'VISIT_OCCURRENCE.PROVIDER_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
		where cdmtable.provider_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_OCCURRENCE
cdmFieldName = CARE_SITE_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'VISIT_OCCURRENCE' cdmTableName,
'CARE_SITE_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'VISIT_OCCURRENCE.CARE_SITE_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
		where cdmtable.care_site_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_OCCURRENCE
cdmFieldName = VISIT_SOURCE_VALUE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'VISIT_OCCURRENCE' cdmTableName,
'VISIT_SOURCE_VALUE' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'VISIT_OCCURRENCE.VISIT_SOURCE_VALUE' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
		where cdmtable.visit_source_value is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_OCCURRENCE
cdmFieldName = VISIT_SOURCE_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'VISIT_OCCURRENCE' cdmTableName,
'VISIT_SOURCE_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'VISIT_OCCURRENCE.VISIT_SOURCE_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
		where cdmtable.visit_source_concept_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_OCCURRENCE
cdmFieldName = ADMITTING_SOURCE_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'VISIT_OCCURRENCE' cdmTableName,
'ADMITTING_SOURCE_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'VISIT_OCCURRENCE.ADMITTING_SOURCE_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
		where cdmtable.admitting_source_concept_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_OCCURRENCE
cdmFieldName = ADMITTING_SOURCE_VALUE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'VISIT_OCCURRENCE' cdmTableName,
'ADMITTING_SOURCE_VALUE' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'VISIT_OCCURRENCE.ADMITTING_SOURCE_VALUE' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
		where cdmtable.admitting_source_value is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_OCCURRENCE
cdmFieldName = DISCHARGE_TO_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'VISIT_OCCURRENCE' cdmTableName,
'DISCHARGE_TO_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'VISIT_OCCURRENCE.DISCHARGE_TO_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
		where cdmtable.discharge_to_concept_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_OCCURRENCE
cdmFieldName = DISCHARGE_TO_SOURCE_VALUE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'VISIT_OCCURRENCE' cdmTableName,
'DISCHARGE_TO_SOURCE_VALUE' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'VISIT_OCCURRENCE.DISCHARGE_TO_SOURCE_VALUE' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
		where cdmtable.discharge_to_source_value is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_OCCURRENCE
cdmFieldName = PRECEDING_VISIT_OCCURRENCE_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'VISIT_OCCURRENCE' cdmTableName,
'PRECEDING_VISIT_OCCURRENCE_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'VISIT_OCCURRENCE.PRECEDING_VISIT_OCCURRENCE_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
		where cdmtable.preceding_visit_occurrence_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_OCCURRENCE_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_OCCURRENCE_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'CONDITION_OCCURRENCE.CONDITION_OCCURRENCE_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
		where cdmtable.condition_occurrence_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = PERSON_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'PERSON_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'CONDITION_OCCURRENCE.PERSON_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
		where cdmtable.person_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'CONDITION_OCCURRENCE.CONDITION_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
		where cdmtable.condition_concept_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_START_DATE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_START_DATE' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'CONDITION_OCCURRENCE.CONDITION_START_DATE' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
		where cdmtable.condition_start_date is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_START_DATETIME
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_START_DATETIME' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'CONDITION_OCCURRENCE.CONDITION_START_DATETIME' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
		where cdmtable.condition_start_datetime is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_END_DATE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_END_DATE' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'CONDITION_OCCURRENCE.CONDITION_END_DATE' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
		where cdmtable.condition_end_date is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_END_DATETIME
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_END_DATETIME' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'CONDITION_OCCURRENCE.CONDITION_END_DATETIME' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
		where cdmtable.condition_end_datetime is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_TYPE_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_TYPE_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'CONDITION_OCCURRENCE.CONDITION_TYPE_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
		where cdmtable.condition_type_concept_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_STATUS_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_STATUS_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'CONDITION_OCCURRENCE.CONDITION_STATUS_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
		where cdmtable.condition_status_concept_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = STOP_REASON
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'STOP_REASON' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'CONDITION_OCCURRENCE.STOP_REASON' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
		where cdmtable.stop_reason is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = PROVIDER_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'PROVIDER_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'CONDITION_OCCURRENCE.PROVIDER_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
		where cdmtable.provider_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = VISIT_OCCURRENCE_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'VISIT_OCCURRENCE_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'CONDITION_OCCURRENCE.VISIT_OCCURRENCE_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
		where cdmtable.visit_occurrence_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = VISIT_DETAIL_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'VISIT_DETAIL_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'CONDITION_OCCURRENCE.VISIT_DETAIL_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
		where cdmtable.visit_detail_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_SOURCE_VALUE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_SOURCE_VALUE' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'CONDITION_OCCURRENCE.CONDITION_SOURCE_VALUE' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
		where cdmtable.condition_source_value is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_SOURCE_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_SOURCE_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'CONDITION_OCCURRENCE.CONDITION_SOURCE_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
		where cdmtable.condition_source_concept_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_STATUS_SOURCE_VALUE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_STATUS_SOURCE_VALUE' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'CONDITION_OCCURRENCE.CONDITION_STATUS_SOURCE_VALUE' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
		where cdmtable.condition_status_source_value is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DRUG_EXPOSURE
cdmFieldName = DRUG_EXPOSURE_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'DRUG_EXPOSURE' cdmTableName,
'DRUG_EXPOSURE_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'DRUG_EXPOSURE.DRUG_EXPOSURE_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
		where cdmtable.drug_exposure_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DRUG_EXPOSURE
cdmFieldName = PERSON_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'DRUG_EXPOSURE' cdmTableName,
'PERSON_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'DRUG_EXPOSURE.PERSON_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
		where cdmtable.person_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DRUG_EXPOSURE
cdmFieldName = DRUG_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'DRUG_EXPOSURE' cdmTableName,
'DRUG_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'DRUG_EXPOSURE.DRUG_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
		where cdmtable.drug_concept_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DRUG_EXPOSURE
cdmFieldName = DRUG_EXPOSURE_START_DATE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'DRUG_EXPOSURE' cdmTableName,
'DRUG_EXPOSURE_START_DATE' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'DRUG_EXPOSURE.DRUG_EXPOSURE_START_DATE' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
		where cdmtable.drug_exposure_start_date is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DRUG_EXPOSURE
cdmFieldName = DRUG_EXPOSURE_START_DATETIME
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'DRUG_EXPOSURE' cdmTableName,
'DRUG_EXPOSURE_START_DATETIME' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'DRUG_EXPOSURE.DRUG_EXPOSURE_START_DATETIME' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
		where cdmtable.drug_exposure_start_datetime is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DRUG_EXPOSURE
cdmFieldName = DRUG_EXPOSURE_END_DATE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'DRUG_EXPOSURE' cdmTableName,
'DRUG_EXPOSURE_END_DATE' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'DRUG_EXPOSURE.DRUG_EXPOSURE_END_DATE' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
		where cdmtable.drug_exposure_end_date is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DRUG_EXPOSURE
cdmFieldName = DRUG_EXPOSURE_END_DATETIME
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'DRUG_EXPOSURE' cdmTableName,
'DRUG_EXPOSURE_END_DATETIME' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'DRUG_EXPOSURE.DRUG_EXPOSURE_END_DATETIME' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
		where cdmtable.drug_exposure_end_datetime is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DRUG_EXPOSURE
cdmFieldName = VERBATIM_END_DATE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'DRUG_EXPOSURE' cdmTableName,
'VERBATIM_END_DATE' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'DRUG_EXPOSURE.VERBATIM_END_DATE' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
		where cdmtable.verbatim_end_date is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DRUG_EXPOSURE
cdmFieldName = DRUG_TYPE_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'DRUG_EXPOSURE' cdmTableName,
'DRUG_TYPE_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'DRUG_EXPOSURE.DRUG_TYPE_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
		where cdmtable.drug_type_concept_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DRUG_EXPOSURE
cdmFieldName = STOP_REASON
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'DRUG_EXPOSURE' cdmTableName,
'STOP_REASON' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'DRUG_EXPOSURE.STOP_REASON' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
		where cdmtable.stop_reason is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DRUG_EXPOSURE
cdmFieldName = REFILLS
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'DRUG_EXPOSURE' cdmTableName,
'REFILLS' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'DRUG_EXPOSURE.REFILLS' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
		where cdmtable.refills is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DRUG_EXPOSURE
cdmFieldName = QUANTITY
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'DRUG_EXPOSURE' cdmTableName,
'QUANTITY' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'DRUG_EXPOSURE.QUANTITY' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
		where cdmtable.quantity is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DRUG_EXPOSURE
cdmFieldName = DAYS_SUPPLY
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'DRUG_EXPOSURE' cdmTableName,
'DAYS_SUPPLY' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'DRUG_EXPOSURE.DAYS_SUPPLY' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
		where cdmtable.days_supply is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DRUG_EXPOSURE
cdmFieldName = SIG
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'DRUG_EXPOSURE' cdmTableName,
'SIG' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'DRUG_EXPOSURE.SIG' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
		where cdmtable.sig is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DRUG_EXPOSURE
cdmFieldName = ROUTE_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'DRUG_EXPOSURE' cdmTableName,
'ROUTE_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'DRUG_EXPOSURE.ROUTE_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
		where cdmtable.route_concept_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DRUG_EXPOSURE
cdmFieldName = LOT_NUMBER
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'DRUG_EXPOSURE' cdmTableName,
'LOT_NUMBER' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'DRUG_EXPOSURE.LOT_NUMBER' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
		where cdmtable.lot_number is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DRUG_EXPOSURE
cdmFieldName = PROVIDER_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'DRUG_EXPOSURE' cdmTableName,
'PROVIDER_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'DRUG_EXPOSURE.PROVIDER_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
		where cdmtable.provider_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DRUG_EXPOSURE
cdmFieldName = VISIT_OCCURRENCE_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'DRUG_EXPOSURE' cdmTableName,
'VISIT_OCCURRENCE_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'DRUG_EXPOSURE.VISIT_OCCURRENCE_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
		where cdmtable.visit_occurrence_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DRUG_EXPOSURE
cdmFieldName = VISIT_DETAIL_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'DRUG_EXPOSURE' cdmTableName,
'VISIT_DETAIL_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'DRUG_EXPOSURE.VISIT_DETAIL_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
		where cdmtable.visit_detail_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DRUG_EXPOSURE
cdmFieldName = DRUG_SOURCE_VALUE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'DRUG_EXPOSURE' cdmTableName,
'DRUG_SOURCE_VALUE' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'DRUG_EXPOSURE.DRUG_SOURCE_VALUE' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
		where cdmtable.drug_source_value is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DRUG_EXPOSURE
cdmFieldName = DRUG_SOURCE_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'DRUG_EXPOSURE' cdmTableName,
'DRUG_SOURCE_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'DRUG_EXPOSURE.DRUG_SOURCE_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
		where cdmtable.drug_source_concept_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DRUG_EXPOSURE
cdmFieldName = ROUTE_SOURCE_VALUE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'DRUG_EXPOSURE' cdmTableName,
'ROUTE_SOURCE_VALUE' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'DRUG_EXPOSURE.ROUTE_SOURCE_VALUE' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
		where cdmtable.route_source_value is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DRUG_EXPOSURE
cdmFieldName = DOSE_UNIT_SOURCE_VALUE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'DRUG_EXPOSURE' cdmTableName,
'DOSE_UNIT_SOURCE_VALUE' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'DRUG_EXPOSURE.DOSE_UNIT_SOURCE_VALUE' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
		where cdmtable.dose_unit_source_value is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_OCCURRENCE_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_OCCURRENCE_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'PROCEDURE_OCCURRENCE.PROCEDURE_OCCURRENCE_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
		where cdmtable.procedure_occurrence_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PERSON_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PERSON_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'PROCEDURE_OCCURRENCE.PERSON_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
		where cdmtable.person_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'PROCEDURE_OCCURRENCE.PROCEDURE_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
		where cdmtable.procedure_concept_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_DATE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_DATE' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'PROCEDURE_OCCURRENCE.PROCEDURE_DATE' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
		where cdmtable.procedure_date is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_DATETIME
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_DATETIME' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'PROCEDURE_OCCURRENCE.PROCEDURE_DATETIME' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
		where cdmtable.procedure_datetime is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_TYPE_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_TYPE_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'PROCEDURE_OCCURRENCE.PROCEDURE_TYPE_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
		where cdmtable.procedure_type_concept_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = MODIFIER_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'MODIFIER_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'PROCEDURE_OCCURRENCE.MODIFIER_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
		where cdmtable.modifier_concept_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = QUANTITY
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'QUANTITY' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'PROCEDURE_OCCURRENCE.QUANTITY' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
		where cdmtable.quantity is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROVIDER_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROVIDER_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'PROCEDURE_OCCURRENCE.PROVIDER_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
		where cdmtable.provider_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = VISIT_OCCURRENCE_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'VISIT_OCCURRENCE_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'PROCEDURE_OCCURRENCE.VISIT_OCCURRENCE_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
		where cdmtable.visit_occurrence_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = VISIT_DETAIL_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'VISIT_DETAIL_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'PROCEDURE_OCCURRENCE.VISIT_DETAIL_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
		where cdmtable.visit_detail_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_SOURCE_VALUE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_SOURCE_VALUE' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'PROCEDURE_OCCURRENCE.PROCEDURE_SOURCE_VALUE' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
		where cdmtable.procedure_source_value is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_SOURCE_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_SOURCE_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'PROCEDURE_OCCURRENCE.PROCEDURE_SOURCE_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
		where cdmtable.procedure_source_concept_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = MODIFIER_SOURCE_VALUE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'MODIFIER_SOURCE_VALUE' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'PROCEDURE_OCCURRENCE.MODIFIER_SOURCE_VALUE' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
		where cdmtable.modifier_source_value is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DEVICE_EXPOSURE
cdmFieldName = DEVICE_EXPOSURE_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'DEVICE_EXPOSURE' cdmTableName,
'DEVICE_EXPOSURE_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'DEVICE_EXPOSURE.DEVICE_EXPOSURE_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.device_exposure cdmtable
		where cdmtable.device_exposure_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.device_exposure cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DEVICE_EXPOSURE
cdmFieldName = PERSON_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'DEVICE_EXPOSURE' cdmTableName,
'PERSON_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'DEVICE_EXPOSURE.PERSON_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.device_exposure cdmtable
		where cdmtable.person_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.device_exposure cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DEVICE_EXPOSURE
cdmFieldName = DEVICE_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'DEVICE_EXPOSURE' cdmTableName,
'DEVICE_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'DEVICE_EXPOSURE.DEVICE_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.device_exposure cdmtable
		where cdmtable.device_concept_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.device_exposure cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DEVICE_EXPOSURE
cdmFieldName = DEVICE_EXPOSURE_START_DATE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'DEVICE_EXPOSURE' cdmTableName,
'DEVICE_EXPOSURE_START_DATE' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'DEVICE_EXPOSURE.DEVICE_EXPOSURE_START_DATE' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.device_exposure cdmtable
		where cdmtable.device_exposure_start_date is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.device_exposure cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DEVICE_EXPOSURE
cdmFieldName = DEVICE_EXPOSURE_START_DATETIME
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'DEVICE_EXPOSURE' cdmTableName,
'DEVICE_EXPOSURE_START_DATETIME' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'DEVICE_EXPOSURE.DEVICE_EXPOSURE_START_DATETIME' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.device_exposure cdmtable
		where cdmtable.device_exposure_start_datetime is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.device_exposure cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DEVICE_EXPOSURE
cdmFieldName = DEVICE_EXPOSURE_END_DATE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'DEVICE_EXPOSURE' cdmTableName,
'DEVICE_EXPOSURE_END_DATE' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'DEVICE_EXPOSURE.DEVICE_EXPOSURE_END_DATE' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.device_exposure cdmtable
		where cdmtable.device_exposure_end_date is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.device_exposure cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DEVICE_EXPOSURE
cdmFieldName = DEVICE_EXPOSURE_END_DATETIME
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'DEVICE_EXPOSURE' cdmTableName,
'DEVICE_EXPOSURE_END_DATETIME' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'DEVICE_EXPOSURE.DEVICE_EXPOSURE_END_DATETIME' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.device_exposure cdmtable
		where cdmtable.device_exposure_end_datetime is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.device_exposure cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DEVICE_EXPOSURE
cdmFieldName = DEVICE_TYPE_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'DEVICE_EXPOSURE' cdmTableName,
'DEVICE_TYPE_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'DEVICE_EXPOSURE.DEVICE_TYPE_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.device_exposure cdmtable
		where cdmtable.device_type_concept_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.device_exposure cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DEVICE_EXPOSURE
cdmFieldName = UNIQUE_DEVICE_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'DEVICE_EXPOSURE' cdmTableName,
'UNIQUE_DEVICE_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'DEVICE_EXPOSURE.UNIQUE_DEVICE_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.device_exposure cdmtable
		where cdmtable.unique_device_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.device_exposure cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DEVICE_EXPOSURE
cdmFieldName = QUANTITY
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'DEVICE_EXPOSURE' cdmTableName,
'QUANTITY' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'DEVICE_EXPOSURE.QUANTITY' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.device_exposure cdmtable
		where cdmtable.quantity is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.device_exposure cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DEVICE_EXPOSURE
cdmFieldName = PROVIDER_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'DEVICE_EXPOSURE' cdmTableName,
'PROVIDER_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'DEVICE_EXPOSURE.PROVIDER_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.device_exposure cdmtable
		where cdmtable.provider_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.device_exposure cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DEVICE_EXPOSURE
cdmFieldName = VISIT_OCCURRENCE_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'DEVICE_EXPOSURE' cdmTableName,
'VISIT_OCCURRENCE_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'DEVICE_EXPOSURE.VISIT_OCCURRENCE_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.device_exposure cdmtable
		where cdmtable.visit_occurrence_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.device_exposure cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DEVICE_EXPOSURE
cdmFieldName = VISIT_DETAIL_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'DEVICE_EXPOSURE' cdmTableName,
'VISIT_DETAIL_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'DEVICE_EXPOSURE.VISIT_DETAIL_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.device_exposure cdmtable
		where cdmtable.visit_detail_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.device_exposure cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DEVICE_EXPOSURE
cdmFieldName = DEVICE_SOURCE_VALUE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'DEVICE_EXPOSURE' cdmTableName,
'DEVICE_SOURCE_VALUE' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'DEVICE_EXPOSURE.DEVICE_SOURCE_VALUE' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.device_exposure cdmtable
		where cdmtable.device_source_value is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.device_exposure cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DEVICE_EXPOSURE
cdmFieldName = DEVICE_SOURCE_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'DEVICE_EXPOSURE' cdmTableName,
'DEVICE_SOURCE_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'DEVICE_EXPOSURE.DEVICE_SOURCE_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.device_exposure cdmtable
		where cdmtable.device_source_concept_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.device_exposure cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = MEASUREMENT
cdmFieldName = MEASUREMENT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'MEASUREMENT' cdmTableName,
'MEASUREMENT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'MEASUREMENT.MEASUREMENT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.measurement cdmtable
		where cdmtable.measurement_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.measurement cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = MEASUREMENT
cdmFieldName = PERSON_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'MEASUREMENT' cdmTableName,
'PERSON_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'MEASUREMENT.PERSON_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.measurement cdmtable
		where cdmtable.person_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.measurement cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = MEASUREMENT
cdmFieldName = MEASUREMENT_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'MEASUREMENT' cdmTableName,
'MEASUREMENT_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'MEASUREMENT.MEASUREMENT_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.measurement cdmtable
		where cdmtable.measurement_concept_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.measurement cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = MEASUREMENT
cdmFieldName = MEASUREMENT_DATE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'MEASUREMENT' cdmTableName,
'MEASUREMENT_DATE' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'MEASUREMENT.MEASUREMENT_DATE' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.measurement cdmtable
		where cdmtable.measurement_date is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.measurement cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = MEASUREMENT
cdmFieldName = MEASUREMENT_DATETIME
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'MEASUREMENT' cdmTableName,
'MEASUREMENT_DATETIME' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'MEASUREMENT.MEASUREMENT_DATETIME' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.measurement cdmtable
		where cdmtable.measurement_datetime is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.measurement cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = MEASUREMENT
cdmFieldName = MEASUREMENT_TIME
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'MEASUREMENT' cdmTableName,
'MEASUREMENT_TIME' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'MEASUREMENT.MEASUREMENT_TIME' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.measurement cdmtable
		where cdmtable.measurement_time is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.measurement cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = MEASUREMENT
cdmFieldName = MEASUREMENT_TYPE_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'MEASUREMENT' cdmTableName,
'MEASUREMENT_TYPE_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'MEASUREMENT.MEASUREMENT_TYPE_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.measurement cdmtable
		where cdmtable.measurement_type_concept_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.measurement cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = MEASUREMENT
cdmFieldName = OPERATOR_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'MEASUREMENT' cdmTableName,
'OPERATOR_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'MEASUREMENT.OPERATOR_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.measurement cdmtable
		where cdmtable.operator_concept_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.measurement cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = MEASUREMENT
cdmFieldName = VALUE_AS_NUMBER
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'MEASUREMENT' cdmTableName,
'VALUE_AS_NUMBER' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'MEASUREMENT.VALUE_AS_NUMBER' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.measurement cdmtable
		where cdmtable.value_as_number is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.measurement cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = MEASUREMENT
cdmFieldName = VALUE_AS_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'MEASUREMENT' cdmTableName,
'VALUE_AS_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'MEASUREMENT.VALUE_AS_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.measurement cdmtable
		where cdmtable.value_as_concept_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.measurement cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = MEASUREMENT
cdmFieldName = UNIT_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'MEASUREMENT' cdmTableName,
'UNIT_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'MEASUREMENT.UNIT_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.measurement cdmtable
		where cdmtable.unit_concept_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.measurement cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = MEASUREMENT
cdmFieldName = RANGE_LOW
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'MEASUREMENT' cdmTableName,
'RANGE_LOW' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'MEASUREMENT.RANGE_LOW' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.measurement cdmtable
		where cdmtable.range_low is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.measurement cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = MEASUREMENT
cdmFieldName = RANGE_HIGH
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'MEASUREMENT' cdmTableName,
'RANGE_HIGH' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'MEASUREMENT.RANGE_HIGH' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.measurement cdmtable
		where cdmtable.range_high is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.measurement cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = MEASUREMENT
cdmFieldName = PROVIDER_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'MEASUREMENT' cdmTableName,
'PROVIDER_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'MEASUREMENT.PROVIDER_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.measurement cdmtable
		where cdmtable.provider_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.measurement cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = MEASUREMENT
cdmFieldName = VISIT_OCCURRENCE_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'MEASUREMENT' cdmTableName,
'VISIT_OCCURRENCE_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'MEASUREMENT.VISIT_OCCURRENCE_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.measurement cdmtable
		where cdmtable.visit_occurrence_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.measurement cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = MEASUREMENT
cdmFieldName = VISIT_DETAIL_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'MEASUREMENT' cdmTableName,
'VISIT_DETAIL_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'MEASUREMENT.VISIT_DETAIL_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.measurement cdmtable
		where cdmtable.visit_detail_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.measurement cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = MEASUREMENT
cdmFieldName = MEASUREMENT_SOURCE_VALUE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'MEASUREMENT' cdmTableName,
'MEASUREMENT_SOURCE_VALUE' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'MEASUREMENT.MEASUREMENT_SOURCE_VALUE' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.measurement cdmtable
		where cdmtable.measurement_source_value is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.measurement cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = MEASUREMENT
cdmFieldName = MEASUREMENT_SOURCE_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'MEASUREMENT' cdmTableName,
'MEASUREMENT_SOURCE_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'MEASUREMENT.MEASUREMENT_SOURCE_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.measurement cdmtable
		where cdmtable.measurement_source_concept_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.measurement cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = MEASUREMENT
cdmFieldName = UNIT_SOURCE_VALUE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'MEASUREMENT' cdmTableName,
'UNIT_SOURCE_VALUE' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'MEASUREMENT.UNIT_SOURCE_VALUE' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.measurement cdmtable
		where cdmtable.unit_source_value is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.measurement cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = MEASUREMENT
cdmFieldName = VALUE_SOURCE_VALUE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'MEASUREMENT' cdmTableName,
'VALUE_SOURCE_VALUE' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'MEASUREMENT.VALUE_SOURCE_VALUE' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.measurement cdmtable
		where cdmtable.value_source_value is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.measurement cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_DETAIL
cdmFieldName = VISIT_DETAIL_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'VISIT_DETAIL' cdmTableName,
'VISIT_DETAIL_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'VISIT_DETAIL.VISIT_DETAIL_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
		where cdmtable.visit_detail_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_DETAIL
cdmFieldName = PERSON_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'VISIT_DETAIL' cdmTableName,
'PERSON_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'VISIT_DETAIL.PERSON_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
		where cdmtable.person_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_DETAIL
cdmFieldName = VISIT_DETAIL_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'VISIT_DETAIL' cdmTableName,
'VISIT_DETAIL_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'VISIT_DETAIL.VISIT_DETAIL_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
		where cdmtable.visit_detail_concept_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_DETAIL
cdmFieldName = VISIT_DETAIL_START_DATE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'VISIT_DETAIL' cdmTableName,
'VISIT_DETAIL_START_DATE' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'VISIT_DETAIL.VISIT_DETAIL_START_DATE' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
		where cdmtable.visit_detail_start_date is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_DETAIL
cdmFieldName = VISIT_DETAIL_START_DATETIME
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'VISIT_DETAIL' cdmTableName,
'VISIT_DETAIL_START_DATETIME' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'VISIT_DETAIL.VISIT_DETAIL_START_DATETIME' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
		where cdmtable.visit_detail_start_datetime is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_DETAIL
cdmFieldName = VISIT_DETAIL_END_DATE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'VISIT_DETAIL' cdmTableName,
'VISIT_DETAIL_END_DATE' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'VISIT_DETAIL.VISIT_DETAIL_END_DATE' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
		where cdmtable.visit_detail_end_date is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_DETAIL
cdmFieldName = VISIT_DETAIL_END_DATETIME
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'VISIT_DETAIL' cdmTableName,
'VISIT_DETAIL_END_DATETIME' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'VISIT_DETAIL.VISIT_DETAIL_END_DATETIME' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
		where cdmtable.visit_detail_end_datetime is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_DETAIL
cdmFieldName = VISIT_DETAIL_TYPE_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'VISIT_DETAIL' cdmTableName,
'VISIT_DETAIL_TYPE_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'VISIT_DETAIL.VISIT_DETAIL_TYPE_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
		where cdmtable.visit_detail_type_concept_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_DETAIL
cdmFieldName = PROVIDER_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'VISIT_DETAIL' cdmTableName,
'PROVIDER_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'VISIT_DETAIL.PROVIDER_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
		where cdmtable.provider_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_DETAIL
cdmFieldName = CARE_SITE_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'VISIT_DETAIL' cdmTableName,
'CARE_SITE_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'VISIT_DETAIL.CARE_SITE_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
		where cdmtable.care_site_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_DETAIL
cdmFieldName = VISIT_DETAIL_SOURCE_VALUE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'VISIT_DETAIL' cdmTableName,
'VISIT_DETAIL_SOURCE_VALUE' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'VISIT_DETAIL.VISIT_DETAIL_SOURCE_VALUE' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
		where cdmtable.visit_detail_source_value is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_DETAIL
cdmFieldName = VISIT_DETAIL_SOURCE_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'VISIT_DETAIL' cdmTableName,
'VISIT_DETAIL_SOURCE_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'VISIT_DETAIL.VISIT_DETAIL_SOURCE_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
		where cdmtable.visit_detail_source_concept_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_DETAIL
cdmFieldName = ADMITTING_SOURCE_VALUE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'VISIT_DETAIL' cdmTableName,
'ADMITTING_SOURCE_VALUE' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'VISIT_DETAIL.ADMITTING_SOURCE_VALUE' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
		where cdmtable.admitting_source_value is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_DETAIL
cdmFieldName = ADMITTING_SOURCE_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'VISIT_DETAIL' cdmTableName,
'ADMITTING_SOURCE_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'VISIT_DETAIL.ADMITTING_SOURCE_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
		where cdmtable.admitting_source_concept_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_DETAIL
cdmFieldName = DISCHARGE_TO_SOURCE_VALUE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'VISIT_DETAIL' cdmTableName,
'DISCHARGE_TO_SOURCE_VALUE' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'VISIT_DETAIL.DISCHARGE_TO_SOURCE_VALUE' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
		where cdmtable.discharge_to_source_value is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_DETAIL
cdmFieldName = DISCHARGE_TO_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'VISIT_DETAIL' cdmTableName,
'DISCHARGE_TO_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'VISIT_DETAIL.DISCHARGE_TO_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
		where cdmtable.discharge_to_concept_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_DETAIL
cdmFieldName = PRECEDING_VISIT_DETAIL_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'VISIT_DETAIL' cdmTableName,
'PRECEDING_VISIT_DETAIL_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'VISIT_DETAIL.PRECEDING_VISIT_DETAIL_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
		where cdmtable.preceding_visit_detail_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_DETAIL
cdmFieldName = VISIT_DETAIL_PARENT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'VISIT_DETAIL' cdmTableName,
'VISIT_DETAIL_PARENT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'VISIT_DETAIL.VISIT_DETAIL_PARENT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
		where cdmtable.visit_detail_parent_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_DETAIL
cdmFieldName = VISIT_OCCURRENCE_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'VISIT_DETAIL' cdmTableName,
'VISIT_OCCURRENCE_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'VISIT_DETAIL.VISIT_OCCURRENCE_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
		where cdmtable.visit_occurrence_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = NOTE
cdmFieldName = NOTE_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'NOTE' cdmTableName,
'NOTE_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'NOTE.NOTE_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.note cdmtable
		where cdmtable.note_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.note cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = NOTE
cdmFieldName = PERSON_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'NOTE' cdmTableName,
'PERSON_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'NOTE.PERSON_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.note cdmtable
		where cdmtable.person_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.note cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = NOTE
cdmFieldName = NOTE_DATE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'NOTE' cdmTableName,
'NOTE_DATE' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'NOTE.NOTE_DATE' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.note cdmtable
		where cdmtable.note_date is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.note cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = NOTE
cdmFieldName = NOTE_DATETIME
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'NOTE' cdmTableName,
'NOTE_DATETIME' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'NOTE.NOTE_DATETIME' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.note cdmtable
		where cdmtable.note_datetime is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.note cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = NOTE
cdmFieldName = NOTE_TYPE_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'NOTE' cdmTableName,
'NOTE_TYPE_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'NOTE.NOTE_TYPE_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.note cdmtable
		where cdmtable.note_type_concept_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.note cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = NOTE
cdmFieldName = NOTE_CLASS_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'NOTE' cdmTableName,
'NOTE_CLASS_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'NOTE.NOTE_CLASS_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.note cdmtable
		where cdmtable.note_class_concept_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.note cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = NOTE
cdmFieldName = NOTE_TITLE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'NOTE' cdmTableName,
'NOTE_TITLE' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'NOTE.NOTE_TITLE' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.note cdmtable
		where cdmtable.note_title is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.note cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = NOTE
cdmFieldName = NOTE_TEXT
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'NOTE' cdmTableName,
'NOTE_TEXT' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'NOTE.NOTE_TEXT' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.note cdmtable
		where cdmtable.note_text is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.note cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = NOTE
cdmFieldName = ENCODING_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'NOTE' cdmTableName,
'ENCODING_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'NOTE.ENCODING_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.note cdmtable
		where cdmtable.encoding_concept_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.note cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = NOTE
cdmFieldName = LANGUAGE_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'NOTE' cdmTableName,
'LANGUAGE_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'NOTE.LANGUAGE_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.note cdmtable
		where cdmtable.language_concept_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.note cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = NOTE
cdmFieldName = PROVIDER_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'NOTE' cdmTableName,
'PROVIDER_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'NOTE.PROVIDER_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.note cdmtable
		where cdmtable.provider_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.note cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = NOTE
cdmFieldName = VISIT_OCCURRENCE_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'NOTE' cdmTableName,
'VISIT_OCCURRENCE_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'NOTE.VISIT_OCCURRENCE_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.note cdmtable
		where cdmtable.visit_occurrence_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.note cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = NOTE
cdmFieldName = VISIT_DETAIL_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'NOTE' cdmTableName,
'VISIT_DETAIL_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'NOTE.VISIT_DETAIL_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.note cdmtable
		where cdmtable.visit_detail_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.note cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = NOTE
cdmFieldName = NOTE_SOURCE_VALUE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'NOTE' cdmTableName,
'NOTE_SOURCE_VALUE' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'NOTE.NOTE_SOURCE_VALUE' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.note cdmtable
		where cdmtable.note_source_value is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.note cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = NOTE_NLP
cdmFieldName = NOTE_NLP_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'NOTE_NLP' cdmTableName,
'NOTE_NLP_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'NOTE_NLP.NOTE_NLP_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.note_nlp cdmtable
		where cdmtable.note_nlp_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.note_nlp cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = NOTE_NLP
cdmFieldName = NOTE_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'NOTE_NLP' cdmTableName,
'NOTE_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'NOTE_NLP.NOTE_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.note_nlp cdmtable
		where cdmtable.note_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.note_nlp cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = NOTE_NLP
cdmFieldName = SECTION_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'NOTE_NLP' cdmTableName,
'SECTION_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'NOTE_NLP.SECTION_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.note_nlp cdmtable
		where cdmtable.section_concept_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.note_nlp cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = NOTE_NLP
cdmFieldName = SNIPPET
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'NOTE_NLP' cdmTableName,
'SNIPPET' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'NOTE_NLP.SNIPPET' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.note_nlp cdmtable
		where cdmtable.snippet is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.note_nlp cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = NOTE_NLP
cdmFieldName = LEXICAL_VARIANT
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'NOTE_NLP' cdmTableName,
'LEXICAL_VARIANT' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'NOTE_NLP.LEXICAL_VARIANT' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.note_nlp cdmtable
		where cdmtable.lexical_variant is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.note_nlp cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = NOTE_NLP
cdmFieldName = NOTE_NLP_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'NOTE_NLP' cdmTableName,
'NOTE_NLP_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'NOTE_NLP.NOTE_NLP_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.note_nlp cdmtable
		where cdmtable.note_nlp_concept_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.note_nlp cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = NOTE_NLP
cdmFieldName = NOTE_NLP_SOURCE_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'NOTE_NLP' cdmTableName,
'NOTE_NLP_SOURCE_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'NOTE_NLP.NOTE_NLP_SOURCE_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.note_nlp cdmtable
		where cdmtable.note_nlp_source_concept_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.note_nlp cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = NOTE_NLP
cdmFieldName = NLP_SYSTEM
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'NOTE_NLP' cdmTableName,
'NLP_SYSTEM' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'NOTE_NLP.NLP_SYSTEM' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.note_nlp cdmtable
		where cdmtable.nlp_system is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.note_nlp cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = NOTE_NLP
cdmFieldName = NLP_DATE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'NOTE_NLP' cdmTableName,
'NLP_DATE' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'NOTE_NLP.NLP_DATE' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.note_nlp cdmtable
		where cdmtable.nlp_date is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.note_nlp cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = NOTE_NLP
cdmFieldName = NLP_DATETIME
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'NOTE_NLP' cdmTableName,
'NLP_DATETIME' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'NOTE_NLP.NLP_DATETIME' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.note_nlp cdmtable
		where cdmtable.nlp_datetime is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.note_nlp cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = NOTE_NLP
cdmFieldName = TERM_EXISTS
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'NOTE_NLP' cdmTableName,
'TERM_EXISTS' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'NOTE_NLP.TERM_EXISTS' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.note_nlp cdmtable
		where cdmtable.term_exists is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.note_nlp cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = NOTE_NLP
cdmFieldName = TERM_TEMPORAL
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'NOTE_NLP' cdmTableName,
'TERM_TEMPORAL' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'NOTE_NLP.TERM_TEMPORAL' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.note_nlp cdmtable
		where cdmtable.term_temporal is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.note_nlp cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = NOTE_NLP
cdmFieldName = TERM_MODIFIERS
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'NOTE_NLP' cdmTableName,
'TERM_MODIFIERS' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'NOTE_NLP.TERM_MODIFIERS' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.note_nlp cdmtable
		where cdmtable.term_modifiers is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.note_nlp cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = OBSERVATION
cdmFieldName = OBSERVATION_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'OBSERVATION' cdmTableName,
'OBSERVATION_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'OBSERVATION.OBSERVATION_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.observation cdmtable
		where cdmtable.observation_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.observation cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = OBSERVATION
cdmFieldName = PERSON_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'OBSERVATION' cdmTableName,
'PERSON_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'OBSERVATION.PERSON_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.observation cdmtable
		where cdmtable.person_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.observation cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = OBSERVATION
cdmFieldName = OBSERVATION_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'OBSERVATION' cdmTableName,
'OBSERVATION_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'OBSERVATION.OBSERVATION_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.observation cdmtable
		where cdmtable.observation_concept_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.observation cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = OBSERVATION
cdmFieldName = OBSERVATION_DATE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'OBSERVATION' cdmTableName,
'OBSERVATION_DATE' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'OBSERVATION.OBSERVATION_DATE' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.observation cdmtable
		where cdmtable.observation_date is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.observation cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = OBSERVATION
cdmFieldName = OBSERVATION_DATETIME
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'OBSERVATION' cdmTableName,
'OBSERVATION_DATETIME' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'OBSERVATION.OBSERVATION_DATETIME' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.observation cdmtable
		where cdmtable.observation_datetime is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.observation cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = OBSERVATION
cdmFieldName = OBSERVATION_TYPE_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'OBSERVATION' cdmTableName,
'OBSERVATION_TYPE_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'OBSERVATION.OBSERVATION_TYPE_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.observation cdmtable
		where cdmtable.observation_type_concept_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.observation cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = OBSERVATION
cdmFieldName = VALUE_AS_NUMBER
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'OBSERVATION' cdmTableName,
'VALUE_AS_NUMBER' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'OBSERVATION.VALUE_AS_NUMBER' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.observation cdmtable
		where cdmtable.value_as_number is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.observation cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = OBSERVATION
cdmFieldName = VALUE_AS_STRING
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'OBSERVATION' cdmTableName,
'VALUE_AS_STRING' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'OBSERVATION.VALUE_AS_STRING' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.observation cdmtable
		where cdmtable.value_as_string is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.observation cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = OBSERVATION
cdmFieldName = VALUE_AS_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'OBSERVATION' cdmTableName,
'VALUE_AS_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'OBSERVATION.VALUE_AS_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.observation cdmtable
		where cdmtable.value_as_concept_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.observation cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = OBSERVATION
cdmFieldName = QUALIFIER_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'OBSERVATION' cdmTableName,
'QUALIFIER_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'OBSERVATION.QUALIFIER_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.observation cdmtable
		where cdmtable.qualifier_concept_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.observation cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = OBSERVATION
cdmFieldName = UNIT_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'OBSERVATION' cdmTableName,
'UNIT_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'OBSERVATION.UNIT_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.observation cdmtable
		where cdmtable.unit_concept_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.observation cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = OBSERVATION
cdmFieldName = PROVIDER_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'OBSERVATION' cdmTableName,
'PROVIDER_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'OBSERVATION.PROVIDER_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.observation cdmtable
		where cdmtable.provider_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.observation cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = OBSERVATION
cdmFieldName = VISIT_OCCURRENCE_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'OBSERVATION' cdmTableName,
'VISIT_OCCURRENCE_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'OBSERVATION.VISIT_OCCURRENCE_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.observation cdmtable
		where cdmtable.visit_occurrence_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.observation cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = OBSERVATION
cdmFieldName = VISIT_DETAIL_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'OBSERVATION' cdmTableName,
'VISIT_DETAIL_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'OBSERVATION.VISIT_DETAIL_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.observation cdmtable
		where cdmtable.visit_detail_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.observation cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = OBSERVATION
cdmFieldName = OBSERVATION_SOURCE_VALUE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'OBSERVATION' cdmTableName,
'OBSERVATION_SOURCE_VALUE' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'OBSERVATION.OBSERVATION_SOURCE_VALUE' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.observation cdmtable
		where cdmtable.observation_source_value is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.observation cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = OBSERVATION
cdmFieldName = OBSERVATION_SOURCE_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'OBSERVATION' cdmTableName,
'OBSERVATION_SOURCE_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'OBSERVATION.OBSERVATION_SOURCE_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.observation cdmtable
		where cdmtable.observation_source_concept_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.observation cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = OBSERVATION
cdmFieldName = UNIT_SOURCE_VALUE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'OBSERVATION' cdmTableName,
'UNIT_SOURCE_VALUE' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'OBSERVATION.UNIT_SOURCE_VALUE' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.observation cdmtable
		where cdmtable.unit_source_value is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.observation cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = OBSERVATION
cdmFieldName = QUALIFIER_SOURCE_VALUE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'OBSERVATION' cdmTableName,
'QUALIFIER_SOURCE_VALUE' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'OBSERVATION.QUALIFIER_SOURCE_VALUE' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.observation cdmtable
		where cdmtable.qualifier_source_value is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.observation cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = FACT_RELATIONSHIP
cdmFieldName = DOMAIN_CONCEPT_ID_1
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'FACT_RELATIONSHIP' cdmTableName,
'DOMAIN_CONCEPT_ID_1' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'FACT_RELATIONSHIP.DOMAIN_CONCEPT_ID_1' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.fact_relationship cdmtable
		where cdmtable.domain_concept_id_1 is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.fact_relationship cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = FACT_RELATIONSHIP
cdmFieldName = FACT_ID_1
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'FACT_RELATIONSHIP' cdmTableName,
'FACT_ID_1' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'FACT_RELATIONSHIP.FACT_ID_1' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.fact_relationship cdmtable
		where cdmtable.fact_id_1 is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.fact_relationship cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = FACT_RELATIONSHIP
cdmFieldName = DOMAIN_CONCEPT_ID_2
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'FACT_RELATIONSHIP' cdmTableName,
'DOMAIN_CONCEPT_ID_2' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'FACT_RELATIONSHIP.DOMAIN_CONCEPT_ID_2' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.fact_relationship cdmtable
		where cdmtable.domain_concept_id_2 is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.fact_relationship cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = FACT_RELATIONSHIP
cdmFieldName = FACT_ID_2
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'FACT_RELATIONSHIP' cdmTableName,
'FACT_ID_2' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'FACT_RELATIONSHIP.FACT_ID_2' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.fact_relationship cdmtable
		where cdmtable.fact_id_2 is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.fact_relationship cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = FACT_RELATIONSHIP
cdmFieldName = RELATIONSHIP_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'FACT_RELATIONSHIP' cdmTableName,
'RELATIONSHIP_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'FACT_RELATIONSHIP.RELATIONSHIP_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.fact_relationship cdmtable
		where cdmtable.relationship_concept_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.fact_relationship cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = LOCATION
cdmFieldName = LOCATION_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'LOCATION' cdmTableName,
'LOCATION_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'LOCATION.LOCATION_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.location cdmtable
		where cdmtable.location_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.location cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = LOCATION
cdmFieldName = ADDRESS_1
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'LOCATION' cdmTableName,
'ADDRESS_1' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'LOCATION.ADDRESS_1' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.location cdmtable
		where cdmtable.address_1 is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.location cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = LOCATION
cdmFieldName = ADDRESS_2
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'LOCATION' cdmTableName,
'ADDRESS_2' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'LOCATION.ADDRESS_2' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.location cdmtable
		where cdmtable.address_2 is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.location cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = LOCATION
cdmFieldName = CITY
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'LOCATION' cdmTableName,
'CITY' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'LOCATION.CITY' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.location cdmtable
		where cdmtable.city is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.location cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = LOCATION
cdmFieldName = STATE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'LOCATION' cdmTableName,
'STATE' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'LOCATION.STATE' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.location cdmtable
		where cdmtable.state is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.location cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = LOCATION
cdmFieldName = ZIP
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'LOCATION' cdmTableName,
'ZIP' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'LOCATION.ZIP' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.location cdmtable
		where cdmtable.zip is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.location cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = LOCATION
cdmFieldName = COUNTY
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'LOCATION' cdmTableName,
'COUNTY' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'LOCATION.COUNTY' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.location cdmtable
		where cdmtable.county is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.location cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = LOCATION
cdmFieldName = LOCATION_SOURCE_VALUE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'LOCATION' cdmTableName,
'LOCATION_SOURCE_VALUE' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'LOCATION.LOCATION_SOURCE_VALUE' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.location cdmtable
		where cdmtable.location_source_value is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.location cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CARE_SITE
cdmFieldName = CARE_SITE_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'CARE_SITE' cdmTableName,
'CARE_SITE_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'CARE_SITE.CARE_SITE_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.care_site cdmtable
		where cdmtable.care_site_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.care_site cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CARE_SITE
cdmFieldName = CARE_SITE_NAME
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'CARE_SITE' cdmTableName,
'CARE_SITE_NAME' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'CARE_SITE.CARE_SITE_NAME' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.care_site cdmtable
		where cdmtable.care_site_name is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.care_site cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CARE_SITE
cdmFieldName = PLACE_OF_SERVICE_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'CARE_SITE' cdmTableName,
'PLACE_OF_SERVICE_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'CARE_SITE.PLACE_OF_SERVICE_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.care_site cdmtable
		where cdmtable.place_of_service_concept_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.care_site cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CARE_SITE
cdmFieldName = LOCATION_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'CARE_SITE' cdmTableName,
'LOCATION_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'CARE_SITE.LOCATION_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.care_site cdmtable
		where cdmtable.location_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.care_site cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CARE_SITE
cdmFieldName = CARE_SITE_SOURCE_VALUE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'CARE_SITE' cdmTableName,
'CARE_SITE_SOURCE_VALUE' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'CARE_SITE.CARE_SITE_SOURCE_VALUE' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.care_site cdmtable
		where cdmtable.care_site_source_value is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.care_site cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CARE_SITE
cdmFieldName = PLACE_OF_SERVICE_SOURCE_VALUE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'CARE_SITE' cdmTableName,
'PLACE_OF_SERVICE_SOURCE_VALUE' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'CARE_SITE.PLACE_OF_SERVICE_SOURCE_VALUE' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.care_site cdmtable
		where cdmtable.place_of_service_source_value is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.care_site cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROVIDER
cdmFieldName = PROVIDER_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'PROVIDER' cdmTableName,
'PROVIDER_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'PROVIDER.PROVIDER_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.provider cdmtable
		where cdmtable.provider_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.provider cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROVIDER
cdmFieldName = PROVIDER_NAME
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'PROVIDER' cdmTableName,
'PROVIDER_NAME' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'PROVIDER.PROVIDER_NAME' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.provider cdmtable
		where cdmtable.provider_name is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.provider cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROVIDER
cdmFieldName = NPI
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'PROVIDER' cdmTableName,
'NPI' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'PROVIDER.NPI' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.provider cdmtable
		where cdmtable.npi is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.provider cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROVIDER
cdmFieldName = DEA
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'PROVIDER' cdmTableName,
'DEA' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'PROVIDER.DEA' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.provider cdmtable
		where cdmtable.dea is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.provider cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROVIDER
cdmFieldName = SPECIALTY_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'PROVIDER' cdmTableName,
'SPECIALTY_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'PROVIDER.SPECIALTY_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.provider cdmtable
		where cdmtable.specialty_concept_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.provider cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROVIDER
cdmFieldName = CARE_SITE_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'PROVIDER' cdmTableName,
'CARE_SITE_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'PROVIDER.CARE_SITE_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.provider cdmtable
		where cdmtable.care_site_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.provider cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROVIDER
cdmFieldName = YEAR_OF_BIRTH
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'PROVIDER' cdmTableName,
'YEAR_OF_BIRTH' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'PROVIDER.YEAR_OF_BIRTH' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.provider cdmtable
		where cdmtable.year_of_birth is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.provider cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROVIDER
cdmFieldName = GENDER_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'PROVIDER' cdmTableName,
'GENDER_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'PROVIDER.GENDER_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.provider cdmtable
		where cdmtable.gender_concept_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.provider cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROVIDER
cdmFieldName = PROVIDER_SOURCE_VALUE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'PROVIDER' cdmTableName,
'PROVIDER_SOURCE_VALUE' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'PROVIDER.PROVIDER_SOURCE_VALUE' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.provider cdmtable
		where cdmtable.provider_source_value is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.provider cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROVIDER
cdmFieldName = SPECIALTY_SOURCE_VALUE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'PROVIDER' cdmTableName,
'SPECIALTY_SOURCE_VALUE' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'PROVIDER.SPECIALTY_SOURCE_VALUE' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.provider cdmtable
		where cdmtable.specialty_source_value is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.provider cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROVIDER
cdmFieldName = SPECIALTY_SOURCE_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'PROVIDER' cdmTableName,
'SPECIALTY_SOURCE_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'PROVIDER.SPECIALTY_SOURCE_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.provider cdmtable
		where cdmtable.specialty_source_concept_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.provider cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROVIDER
cdmFieldName = GENDER_SOURCE_VALUE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'PROVIDER' cdmTableName,
'GENDER_SOURCE_VALUE' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'PROVIDER.GENDER_SOURCE_VALUE' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.provider cdmtable
		where cdmtable.gender_source_value is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.provider cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROVIDER
cdmFieldName = GENDER_SOURCE_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'PROVIDER' cdmTableName,
'GENDER_SOURCE_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'PROVIDER.GENDER_SOURCE_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.provider cdmtable
		where cdmtable.gender_source_concept_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.provider cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PAYER_PLAN_PERIOD
cdmFieldName = PAYER_PLAN_PERIOD_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'PAYER_PLAN_PERIOD' cdmTableName,
'PAYER_PLAN_PERIOD_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'PAYER_PLAN_PERIOD.PAYER_PLAN_PERIOD_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.payer_plan_period cdmtable
		where cdmtable.payer_plan_period_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.payer_plan_period cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PAYER_PLAN_PERIOD
cdmFieldName = PERSON_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'PAYER_PLAN_PERIOD' cdmTableName,
'PERSON_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'PAYER_PLAN_PERIOD.PERSON_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.payer_plan_period cdmtable
		where cdmtable.person_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.payer_plan_period cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PAYER_PLAN_PERIOD
cdmFieldName = PAYER_PLAN_PERIOD_START_DATE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'PAYER_PLAN_PERIOD' cdmTableName,
'PAYER_PLAN_PERIOD_START_DATE' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'PAYER_PLAN_PERIOD.PAYER_PLAN_PERIOD_START_DATE' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.payer_plan_period cdmtable
		where cdmtable.payer_plan_period_start_date is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.payer_plan_period cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PAYER_PLAN_PERIOD
cdmFieldName = PAYER_PLAN_PERIOD_END_DATE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'PAYER_PLAN_PERIOD' cdmTableName,
'PAYER_PLAN_PERIOD_END_DATE' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'PAYER_PLAN_PERIOD.PAYER_PLAN_PERIOD_END_DATE' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.payer_plan_period cdmtable
		where cdmtable.payer_plan_period_end_date is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.payer_plan_period cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PAYER_PLAN_PERIOD
cdmFieldName = PAYER_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'PAYER_PLAN_PERIOD' cdmTableName,
'PAYER_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'PAYER_PLAN_PERIOD.PAYER_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.payer_plan_period cdmtable
		where cdmtable.payer_concept_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.payer_plan_period cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PAYER_PLAN_PERIOD
cdmFieldName = PAYER_SOURCE_VALUE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'PAYER_PLAN_PERIOD' cdmTableName,
'PAYER_SOURCE_VALUE' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'PAYER_PLAN_PERIOD.PAYER_SOURCE_VALUE' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.payer_plan_period cdmtable
		where cdmtable.payer_source_value is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.payer_plan_period cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PAYER_PLAN_PERIOD
cdmFieldName = PAYER_SOURCE_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'PAYER_PLAN_PERIOD' cdmTableName,
'PAYER_SOURCE_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'PAYER_PLAN_PERIOD.PAYER_SOURCE_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.payer_plan_period cdmtable
		where cdmtable.payer_source_concept_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.payer_plan_period cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PAYER_PLAN_PERIOD
cdmFieldName = PLAN_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'PAYER_PLAN_PERIOD' cdmTableName,
'PLAN_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'PAYER_PLAN_PERIOD.PLAN_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.payer_plan_period cdmtable
		where cdmtable.plan_concept_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.payer_plan_period cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PAYER_PLAN_PERIOD
cdmFieldName = PLAN_SOURCE_VALUE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'PAYER_PLAN_PERIOD' cdmTableName,
'PLAN_SOURCE_VALUE' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'PAYER_PLAN_PERIOD.PLAN_SOURCE_VALUE' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.payer_plan_period cdmtable
		where cdmtable.plan_source_value is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.payer_plan_period cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PAYER_PLAN_PERIOD
cdmFieldName = PLAN_SOURCE_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'PAYER_PLAN_PERIOD' cdmTableName,
'PLAN_SOURCE_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'PAYER_PLAN_PERIOD.PLAN_SOURCE_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.payer_plan_period cdmtable
		where cdmtable.plan_source_concept_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.payer_plan_period cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PAYER_PLAN_PERIOD
cdmFieldName = SPONSOR_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'PAYER_PLAN_PERIOD' cdmTableName,
'SPONSOR_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'PAYER_PLAN_PERIOD.SPONSOR_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.payer_plan_period cdmtable
		where cdmtable.sponsor_concept_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.payer_plan_period cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PAYER_PLAN_PERIOD
cdmFieldName = SPONSOR_SOURCE_VALUE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'PAYER_PLAN_PERIOD' cdmTableName,
'SPONSOR_SOURCE_VALUE' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'PAYER_PLAN_PERIOD.SPONSOR_SOURCE_VALUE' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.payer_plan_period cdmtable
		where cdmtable.sponsor_source_value is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.payer_plan_period cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PAYER_PLAN_PERIOD
cdmFieldName = SPONSOR_SOURCE_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'PAYER_PLAN_PERIOD' cdmTableName,
'SPONSOR_SOURCE_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'PAYER_PLAN_PERIOD.SPONSOR_SOURCE_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.payer_plan_period cdmtable
		where cdmtable.sponsor_source_concept_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.payer_plan_period cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PAYER_PLAN_PERIOD
cdmFieldName = FAMILY_SOURCE_VALUE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'PAYER_PLAN_PERIOD' cdmTableName,
'FAMILY_SOURCE_VALUE' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'PAYER_PLAN_PERIOD.FAMILY_SOURCE_VALUE' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.payer_plan_period cdmtable
		where cdmtable.family_source_value is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.payer_plan_period cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PAYER_PLAN_PERIOD
cdmFieldName = STOP_REASON_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'PAYER_PLAN_PERIOD' cdmTableName,
'STOP_REASON_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'PAYER_PLAN_PERIOD.STOP_REASON_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.payer_plan_period cdmtable
		where cdmtable.stop_reason_concept_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.payer_plan_period cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PAYER_PLAN_PERIOD
cdmFieldName = STOP_REASON_SOURCE_VALUE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'PAYER_PLAN_PERIOD' cdmTableName,
'STOP_REASON_SOURCE_VALUE' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'PAYER_PLAN_PERIOD.STOP_REASON_SOURCE_VALUE' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.payer_plan_period cdmtable
		where cdmtable.stop_reason_source_value is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.payer_plan_period cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PAYER_PLAN_PERIOD
cdmFieldName = STOP_REASON_SOURCE_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'PAYER_PLAN_PERIOD' cdmTableName,
'STOP_REASON_SOURCE_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'PAYER_PLAN_PERIOD.STOP_REASON_SOURCE_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.payer_plan_period cdmtable
		where cdmtable.stop_reason_source_concept_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.payer_plan_period cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DRUG_ERA
cdmFieldName = DRUG_ERA_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'DRUG_ERA' cdmTableName,
'DRUG_ERA_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'DRUG_ERA.DRUG_ERA_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.drug_era cdmtable
		where cdmtable.drug_era_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.drug_era cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DRUG_ERA
cdmFieldName = PERSON_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'DRUG_ERA' cdmTableName,
'PERSON_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'DRUG_ERA.PERSON_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.drug_era cdmtable
		where cdmtable.person_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.drug_era cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DRUG_ERA
cdmFieldName = DRUG_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'DRUG_ERA' cdmTableName,
'DRUG_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'DRUG_ERA.DRUG_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.drug_era cdmtable
		where cdmtable.drug_concept_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.drug_era cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DRUG_ERA
cdmFieldName = DRUG_ERA_START_DATE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'DRUG_ERA' cdmTableName,
'DRUG_ERA_START_DATE' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'DRUG_ERA.DRUG_ERA_START_DATE' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.drug_era cdmtable
		where cdmtable.drug_era_start_date is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.drug_era cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DRUG_ERA
cdmFieldName = DRUG_ERA_END_DATE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'DRUG_ERA' cdmTableName,
'DRUG_ERA_END_DATE' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'DRUG_ERA.DRUG_ERA_END_DATE' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.drug_era cdmtable
		where cdmtable.drug_era_end_date is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.drug_era cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DRUG_ERA
cdmFieldName = DRUG_EXPOSURE_COUNT
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'DRUG_ERA' cdmTableName,
'DRUG_EXPOSURE_COUNT' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'DRUG_ERA.DRUG_EXPOSURE_COUNT' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.drug_era cdmtable
		where cdmtable.drug_exposure_count is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.drug_era cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DRUG_ERA
cdmFieldName = GAP_DAYS
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'DRUG_ERA' cdmTableName,
'GAP_DAYS' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'DRUG_ERA.GAP_DAYS' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.drug_era cdmtable
		where cdmtable.gap_days is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.drug_era cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_ERA
cdmFieldName = CONDITION_ERA_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'CONDITION_ERA' cdmTableName,
'CONDITION_ERA_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'CONDITION_ERA.CONDITION_ERA_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_era cdmtable
		where cdmtable.condition_era_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_era cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_ERA
cdmFieldName = PERSON_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'CONDITION_ERA' cdmTableName,
'PERSON_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'CONDITION_ERA.PERSON_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_era cdmtable
		where cdmtable.person_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_era cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_ERA
cdmFieldName = CONDITION_CONCEPT_ID
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'CONDITION_ERA' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'CONDITION_ERA.CONDITION_CONCEPT_ID' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_era cdmtable
		where cdmtable.condition_concept_id is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_era cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_ERA
cdmFieldName = CONDITION_ERA_START_DATE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'CONDITION_ERA' cdmTableName,
'CONDITION_ERA_START_DATE' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'CONDITION_ERA.CONDITION_ERA_START_DATE' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_era cdmtable
		where cdmtable.condition_era_start_date is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_era cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_ERA
cdmFieldName = CONDITION_ERA_END_DATE
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'CONDITION_ERA' cdmTableName,
'CONDITION_ERA_END_DATE' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'CONDITION_ERA.CONDITION_ERA_END_DATE' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_era cdmtable
		where cdmtable.condition_era_end_date is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_era cdmtable
) denominator
;

/*********
MEASURE_VALUE_COMPLETENESS
Computing number of null values and the proportion to total records per field
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_ERA
cdmFieldName = CONDITION_OCCURRENCE_COUNT
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'MEASURE_VALUE_COMPLETENESS' level,
    'Computing number of null values and the proportion to total records per field' check,
    'CONDITION_ERA' cdmTableName,
'CONDITION_OCCURRENCE_COUNT' cdmFieldName,
    	num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
  denominator.num_rows as num_denominator_rows
from
(
	select 
		COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
			'CONDITION_ERA.CONDITION_OCCURRENCE_COUNT' as violating_field, 
			cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_era cdmtable
		where cdmtable.condition_occurrence_count is null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
		COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_era cdmtable
) denominator
;

