                    
/****
CONDITION ERA
Note: Eras derived from CONDITION_OCCURRENCE table, using 30d gap
 ****/
-- create base eras from the concepts found in condition_occurrence
CREATE TEMP TABLE vee8ifhfcteconditiontarget
 AS
SELECT
co.person_id
    ,co.condition_concept_id
    ,co.condition_start_date
    ,coalesce(co.condition_end_date, DATE_ADD(IF(SAFE_CAST(condition_start_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(condition_start_date  AS STRING)),SAFE_CAST(condition_start_date  AS DATE)), interval 1 DAY)) as condition_end_date
FROM
CY_IMOSPHERE_CDM_531.condition_occurrence co;
/* / */
CREATE TEMP TABLE vee8ifhfctecondenddates
 AS
SELECT
person_id
    ,condition_concept_id
    ,DATE_ADD(IF(SAFE_CAST(event_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(event_date  AS STRING)),SAFE_CAST(event_date  AS DATE)), interval - 30 DAY) as end_date -- unpad the end date
FROM
(
     select e1.person_id
        ,e1.condition_concept_id
        ,e1.event_date
        ,coalesce(e1.start_ordinal, max(e2.start_ordinal)) start_ordinal
        ,e1.overall_ord
     from (
        select person_id
            ,condition_concept_id
            ,event_date
            ,event_type
            ,start_ordinal
            ,row_number() over (
                partition by person_id
                ,condition_concept_id order by event_date
                    ,event_type
                ) as overall_ord -- this re-numbers the inner UNION so all rows are numbered ordered by the event date
        from (
            -- select the start dates, assigning a row number to each
            select person_id
                ,condition_concept_id
                ,condition_start_date as event_date
                ,- 1 as event_type
                ,row_number() over (
                    partition by person_id
                    ,condition_concept_id order by condition_start_date
                    ) as start_ordinal
            from vee8ifhfcteconditiontarget
            union all
            -- pad the end dates by 30 to allow a grace period for overlapping ranges.
            select person_id
                ,condition_concept_id
                ,DATE_ADD(IF(SAFE_CAST(condition_end_date  AS DATE) IS NULL,PARSE_DATE('%Y%m%d', cast(condition_end_date  AS STRING)),SAFE_CAST(condition_end_date  AS DATE)), interval 30 DAY)
                ,1 as event_type
                ,null
            from vee8ifhfcteconditiontarget
            ) rawdata
        ) e1
    inner join (
        select person_id
            ,condition_concept_id
            ,condition_start_date as event_date
            ,row_number() over (
                partition by person_id
                ,condition_concept_id order by condition_start_date
                ) as start_ordinal
        from vee8ifhfcteconditiontarget
        ) e2 on e1.person_id = e2.person_id
        and e1.condition_concept_id = e2.condition_concept_id
        and e2.event_date <= e1.event_date
     group by  e1.person_id
        , e1.condition_concept_id
        , e1.event_date
        , e1.start_ordinal
        , e1.overall_ord
     ) e
where (2 * e.start_ordinal) - e.overall_ord = 0;
/* / */
 CREATE TEMP TABLE vee8ifhfcteconditionends
  AS
SELECT
c.person_id
    ,c.condition_concept_id
    ,c.condition_start_date
    ,min(e.end_date) as era_end_date
FROM
vee8ifhfcteconditiontarget c
inner join vee8ifhfctecondenddates e on c.person_id = e.person_id
    and c.condition_concept_id = e.condition_concept_id
    and e.end_date >= c.condition_start_date
 group by  c.person_id
    , c.condition_concept_id
    , c.condition_start_date ;
/* / */
insert into CY_IMOSPHERE_CDM_531.condition_era (
    condition_era_id
    ,person_id
    ,condition_concept_id
    ,condition_era_start_date
    ,condition_era_end_date
    ,condition_occurrence_count
    )
select
    row_number() over (order by t.person_id) as condition_era_id
    ,t.person_id
    ,t.condition_concept_id
    ,min(t.condition_start_date) as condition_era_start_date
    ,t.era_end_date as condition_era_end_date
    ,count(*) as condition_occurrence_count
from (
    select
        ce.person_id
        ,ce.condition_concept_id
        ,ce.condition_start_date
        ,ceera.era_end_date
    from vee8ifhfcteconditionends ce
    inner join (
        select
            person_id
            ,condition_concept_id
            ,min(condition_start_date) as era_start_date
            ,min(era_end_date) as era_end_date
        from vee8ifhfcteconditionends
        group by person_id, condition_concept_id
    ) ceera
    on ce.person_id = ceera.person_id
    and ce.condition_concept_id = ceera.condition_concept_id
    and ce.condition_start_date = ceera.era_start_date
) t
group by t.person_id, t.condition_concept_id, t.era_end_date;
