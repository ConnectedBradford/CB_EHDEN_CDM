/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =    26662
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'26662' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =    26662
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =    26662
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =    26935
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'26935' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =    26935
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =    26935
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =    30969
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'30969' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =    30969
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =    30969
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =    73801
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'73801' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =    73801
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =    73801
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =    74322
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'74322' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =    74322
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =    74322
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =    78193
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'78193' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =    78193
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =    78193
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =    79758
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'79758' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =    79758
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =    79758
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   141917
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'141917' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   141917
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   141917
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   192367
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'192367' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   192367
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   192367
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   192676
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'192676' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   192676
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   192676
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   192683
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'192683' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   192683
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   192683
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   192854
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'192854' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   192854
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   192854
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   192858
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'192858' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   192858
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   192858
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   193254
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'193254' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   193254
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   193254
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   193261
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'193261' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   193261
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   193261
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   193262
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'193262' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   193262
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   193262
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   193277
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'193277' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   193277
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   193277
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   193437
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'193437' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   193437
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   193437
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   193439
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'193439' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   193439
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   193439
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   193522
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'193522' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   193522
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   193522
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   193530
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'193530' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   193530
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   193530
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   193739
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'193739' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   193739
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   193739
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   193818
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'193818' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   193818
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   193818
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   194092
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'194092' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   194092
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   194092
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   194286
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'194286' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   194286
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   194286
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   194412
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'194412' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   194412
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   194412
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   194420
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'194420' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   194420
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   194420
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   194611
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'194611' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   194611
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   194611
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   194696
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'194696' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   194696
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   194696
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   194871
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'194871' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   194871
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   194871
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   194997
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'194997' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   194997
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   194997
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   195009
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'195009' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   195009
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   195009
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   195012
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'195012' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   195012
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   195012
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   195197
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'195197' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   195197
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   195197
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   195316
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'195316' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   195316
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   195316
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   195321
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'195321' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   195321
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   195321
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   195483
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'195483' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   195483
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   195483
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   195500
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'195500' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   195500
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   195500
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   195501
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'195501' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   195501
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   195501
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   195683
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'195683' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   195683
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   195683
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   195769
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'195769' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   195769
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   195769
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   195770
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'195770' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   195770
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   195770
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   195793
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'195793' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   195793
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   195793
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   195867
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'195867' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   195867
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   195867
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   195873
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'195873' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   195873
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   195873
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   196048
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'196048' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   196048
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   196048
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   196051
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'196051' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   196051
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   196051
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   196068
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'196068' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   196068
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   196068
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   196157
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'196157' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   196157
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   196157
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   196158
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'196158' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   196158
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   196158
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   196163
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'196163' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   196163
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   196163
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   196165
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'196165' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   196165
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   196165
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   196168
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'196168' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   196168
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   196168
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   196359
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'196359' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   196359
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   196359
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   196364
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'196364' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   196364
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   196364
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   196473
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'196473' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   196473
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   196473
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   196734
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'196734' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   196734
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   196734
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   196738
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'196738' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   196738
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   196738
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   196758
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'196758' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   196758
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   196758
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   197032
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'197032' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   197032
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   197032
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   197039
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'197039' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   197039
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   197039
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   197044
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'197044' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   197044
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   197044
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   197236
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'197236' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   197236
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   197236
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   197237
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'197237' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   197237
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   197237
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   197507
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'197507' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   197507
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   197507
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   197601
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'197601' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   197601
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   197601
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   197605
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'197605' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   197605
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   197605
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   197606
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'197606' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   197606
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   197606
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   197607
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'197607' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   197607
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   197607
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   197609
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'197609' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   197609
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   197609
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   197610
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'197610' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   197610
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   197610
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   197938
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'197938' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   197938
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   197938
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   198082
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'198082' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   198082
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   198082
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   198108
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'198108' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   198108
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   198108
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   198194
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'198194' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   198194
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   198194
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   198197
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'198197' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   198197
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   198197
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   198198
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'198198' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   198198
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   198198
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   198202
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'198202' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   198202
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   198202
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   198212
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'198212' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   198212
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   198212
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   198363
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'198363' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   198363
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   198363
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   198471
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'198471' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   198471
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   198471
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   198483
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'198483' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   198483
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   198483
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   198803
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'198803' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   198803
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   198803
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   198806
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'198806' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   198806
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   198806
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   199067
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'199067' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   199067
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   199067
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   199078
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'199078' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   199078
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   199078
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   199752
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'199752' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   199752
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   199752
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   199764
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'199764' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   199764
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   199764
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   199876
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'199876' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   199876
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   199876
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   199877
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'199877' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   199877
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   199877
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   199878
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'199878' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   199878
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   199878
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   199881
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'199881' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   199881
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   199881
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   200051
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'200051' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   200051
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   200051
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   200052
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'200052' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   200052
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   200052
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   200147
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'200147' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   200147
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   200147
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   200445
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'200445' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   200445
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   200445
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   200452
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'200452' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   200452
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   200452
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   200461
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'200461' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   200461
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   200461
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   200670
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'200670' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   200670
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   200670
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   200675
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'200675' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   200675
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   200675
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   200775
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'200775' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   200775
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   200775
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   200779
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'200779' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   200779
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   200779
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   200780
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'200780' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   200780
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   200780
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   200962
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'200962' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   200962
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   200962
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   200970
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'200970' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   200970
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   200970
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   201072
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'201072' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   201072
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   201072
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   201078
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'201078' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   201078
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   201078
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   201211
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'201211' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   201211
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   201211
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   201238
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'201238' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   201238
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   201238
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   201244
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'201244' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   201244
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   201244
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   201257
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'201257' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   201257
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   201257
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   201346
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'201346' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   201346
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   201346
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   201355
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'201355' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   201355
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   201355
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   201527
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'201527' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   201527
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   201527
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   201617
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'201617' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   201617
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   201617
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   201625
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'201625' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   201625
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   201625
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   201801
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'201801' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   201801
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   201801
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   201817
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'201817' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   201817
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   201817
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   201823
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'201823' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   201823
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   201823
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   201907
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'201907' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   201907
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   201907
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   201909
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'201909' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   201909
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   201909
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   201913
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'201913' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   201913
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   201913
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   314409
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'314409' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   314409
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   314409
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   315586
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'315586' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   315586
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   315586
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   433716
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'433716' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   433716
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   433716
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   434251
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'434251' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   434251
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   434251
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   435315
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'435315' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   435315
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   435315
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   435648
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'435648' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   435648
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   435648
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   436155
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'436155' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   436155
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   436155
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   436358
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'436358' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   436358
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   436358
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   436366
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'436366' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   436366
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   436366
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   436466
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'436466' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   436466
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   436466
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   437501
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'437501' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   437501
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   437501
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   437655
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'437655' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   437655
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   437655
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   438477
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'438477' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   438477
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   438477
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   439871
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'439871' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   439871
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   439871
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   440971
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'440971' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   440971
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   440971
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   441068
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'441068' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   441068
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   441068
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   441077
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'441077' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   441077
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   441077
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   441805
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'441805' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   441805
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   441805
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   442781
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'442781' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   442781
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   442781
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   443211
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'443211' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   443211
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   443211
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   443435
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'443435' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   443435
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   443435
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   443800
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'443800' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   443800
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   443800
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   444078
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'444078' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   444078
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   444078
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =   444106
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'444106' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =   444106
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =   444106
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_CONCEPT_ID
conceptId =  2003947
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_CONCEPT_ID' cdmFieldName,
'2003947' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.procedure_concept_id =  2003947
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
	where procedure_concept_id =  2003947
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_CONCEPT_ID
conceptId =  2003966
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_CONCEPT_ID' cdmFieldName,
'2003966' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.procedure_concept_id =  2003966
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
	where procedure_concept_id =  2003966
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_CONCEPT_ID
conceptId =  2003983
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_CONCEPT_ID' cdmFieldName,
'2003983' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.procedure_concept_id =  2003983
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
	where procedure_concept_id =  2003983
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_CONCEPT_ID
conceptId =  2004031
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_CONCEPT_ID' cdmFieldName,
'2004031' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.procedure_concept_id =  2004031
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
	where procedure_concept_id =  2004031
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_CONCEPT_ID
conceptId =  2004063
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_CONCEPT_ID' cdmFieldName,
'2004063' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.procedure_concept_id =  2004063
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
	where procedure_concept_id =  2004063
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_CONCEPT_ID
conceptId =  2004070
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_CONCEPT_ID' cdmFieldName,
'2004070' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.procedure_concept_id =  2004070
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
	where procedure_concept_id =  2004070
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_CONCEPT_ID
conceptId =  2004090
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_CONCEPT_ID' cdmFieldName,
'2004090' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.procedure_concept_id =  2004090
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
	where procedure_concept_id =  2004090
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_CONCEPT_ID
conceptId =  2004164
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_CONCEPT_ID' cdmFieldName,
'2004164' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.procedure_concept_id =  2004164
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
	where procedure_concept_id =  2004164
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_CONCEPT_ID
conceptId =  2004263
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_CONCEPT_ID' cdmFieldName,
'2004263' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.procedure_concept_id =  2004263
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
	where procedure_concept_id =  2004263
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_CONCEPT_ID
conceptId =  2004329
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_CONCEPT_ID' cdmFieldName,
'2004329' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.procedure_concept_id =  2004329
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
	where procedure_concept_id =  2004329
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_CONCEPT_ID
conceptId =  2004342
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_CONCEPT_ID' cdmFieldName,
'2004342' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.procedure_concept_id =  2004342
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
	where procedure_concept_id =  2004342
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_CONCEPT_ID
conceptId =  2004443
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_CONCEPT_ID' cdmFieldName,
'2004443' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.procedure_concept_id =  2004443
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
	where procedure_concept_id =  2004443
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_CONCEPT_ID
conceptId =  2004627
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_CONCEPT_ID' cdmFieldName,
'2004627' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.procedure_concept_id =  2004627
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
	where procedure_concept_id =  2004627
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_CONCEPT_ID
conceptId =  2109825
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_CONCEPT_ID' cdmFieldName,
'2109825' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.procedure_concept_id =  2109825
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
	where procedure_concept_id =  2109825
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_CONCEPT_ID
conceptId =  2109833
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_CONCEPT_ID' cdmFieldName,
'2109833' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.procedure_concept_id =  2109833
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
	where procedure_concept_id =  2109833
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_CONCEPT_ID
conceptId =  2109900
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_CONCEPT_ID' cdmFieldName,
'2109900' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.procedure_concept_id =  2109900
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
	where procedure_concept_id =  2109900
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_CONCEPT_ID
conceptId =  2109902
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_CONCEPT_ID' cdmFieldName,
'2109902' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.procedure_concept_id =  2109902
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
	where procedure_concept_id =  2109902
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_CONCEPT_ID
conceptId =  2109905
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_CONCEPT_ID' cdmFieldName,
'2109905' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.procedure_concept_id =  2109905
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
	where procedure_concept_id =  2109905
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_CONCEPT_ID
conceptId =  2109906
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_CONCEPT_ID' cdmFieldName,
'2109906' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.procedure_concept_id =  2109906
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
	where procedure_concept_id =  2109906
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_CONCEPT_ID
conceptId =  2109916
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_CONCEPT_ID' cdmFieldName,
'2109916' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.procedure_concept_id =  2109916
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
	where procedure_concept_id =  2109916
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_CONCEPT_ID
conceptId =  2109968
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_CONCEPT_ID' cdmFieldName,
'2109968' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.procedure_concept_id =  2109968
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
	where procedure_concept_id =  2109968
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_CONCEPT_ID
conceptId =  2109973
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_CONCEPT_ID' cdmFieldName,
'2109973' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.procedure_concept_id =  2109973
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
	where procedure_concept_id =  2109973
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_CONCEPT_ID
conceptId =  2109981
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_CONCEPT_ID' cdmFieldName,
'2109981' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.procedure_concept_id =  2109981
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
	where procedure_concept_id =  2109981
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_CONCEPT_ID
conceptId =  2110004
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_CONCEPT_ID' cdmFieldName,
'2110004' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.procedure_concept_id =  2110004
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
	where procedure_concept_id =  2110004
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_CONCEPT_ID
conceptId =  2110011
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_CONCEPT_ID' cdmFieldName,
'2110011' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.procedure_concept_id =  2110011
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
	where procedure_concept_id =  2110011
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_CONCEPT_ID
conceptId =  2110026
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_CONCEPT_ID' cdmFieldName,
'2110026' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.procedure_concept_id =  2110026
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
	where procedure_concept_id =  2110026
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_CONCEPT_ID
conceptId =  2110039
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_CONCEPT_ID' cdmFieldName,
'2110039' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.procedure_concept_id =  2110039
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
	where procedure_concept_id =  2110039
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_CONCEPT_ID
conceptId =  2110044
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_CONCEPT_ID' cdmFieldName,
'2110044' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.procedure_concept_id =  2110044
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
	where procedure_concept_id =  2110044
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_CONCEPT_ID
conceptId =  2110078
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_CONCEPT_ID' cdmFieldName,
'2110078' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.procedure_concept_id =  2110078
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
	where procedure_concept_id =  2110078
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_CONCEPT_ID
conceptId =  2110116
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_CONCEPT_ID' cdmFieldName,
'2110116' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.procedure_concept_id =  2110116
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
	where procedure_concept_id =  2110116
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_CONCEPT_ID
conceptId =  2110142
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_CONCEPT_ID' cdmFieldName,
'2110142' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.procedure_concept_id =  2110142
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
	where procedure_concept_id =  2110142
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_CONCEPT_ID
conceptId =  2110144
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_CONCEPT_ID' cdmFieldName,
'2110144' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.procedure_concept_id =  2110144
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
	where procedure_concept_id =  2110144
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_CONCEPT_ID
conceptId =  2110169
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_CONCEPT_ID' cdmFieldName,
'2110169' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.procedure_concept_id =  2110169
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
	where procedure_concept_id =  2110169
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_CONCEPT_ID
conceptId =  2110175
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_CONCEPT_ID' cdmFieldName,
'2110175' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.procedure_concept_id =  2110175
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
	where procedure_concept_id =  2110175
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_CONCEPT_ID
conceptId =  2110194
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_CONCEPT_ID' cdmFieldName,
'2110194' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.procedure_concept_id =  2110194
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
	where procedure_concept_id =  2110194
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_CONCEPT_ID
conceptId =  2110195
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_CONCEPT_ID' cdmFieldName,
'2110195' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.procedure_concept_id =  2110195
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
	where procedure_concept_id =  2110195
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_CONCEPT_ID
conceptId =  2110203
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_CONCEPT_ID' cdmFieldName,
'2110203' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.procedure_concept_id =  2110203
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
	where procedure_concept_id =  2110203
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_CONCEPT_ID
conceptId =  2110222
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_CONCEPT_ID' cdmFieldName,
'2110222' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.procedure_concept_id =  2110222
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
	where procedure_concept_id =  2110222
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_CONCEPT_ID
conceptId =  2110227
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_CONCEPT_ID' cdmFieldName,
'2110227' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.procedure_concept_id =  2110227
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
	where procedure_concept_id =  2110227
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_CONCEPT_ID
conceptId =  2110230
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_CONCEPT_ID' cdmFieldName,
'2110230' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.procedure_concept_id =  2110230
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
	where procedure_concept_id =  2110230
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_CONCEPT_ID
conceptId =  2110307
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_CONCEPT_ID' cdmFieldName,
'2110307' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.procedure_concept_id =  2110307
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
	where procedure_concept_id =  2110307
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_CONCEPT_ID
conceptId =  2110315
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_CONCEPT_ID' cdmFieldName,
'2110315' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.procedure_concept_id =  2110315
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
	where procedure_concept_id =  2110315
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_CONCEPT_ID
conceptId =  2110316
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_CONCEPT_ID' cdmFieldName,
'2110316' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.procedure_concept_id =  2110316
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
	where procedure_concept_id =  2110316
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_CONCEPT_ID
conceptId =  2110317
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_CONCEPT_ID' cdmFieldName,
'2110317' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.procedure_concept_id =  2110317
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
	where procedure_concept_id =  2110317
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_CONCEPT_ID
conceptId =  2110326
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_CONCEPT_ID' cdmFieldName,
'2110326' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.procedure_concept_id =  2110326
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
	where procedure_concept_id =  2110326
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_CONCEPT_ID
conceptId =  2211747
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_CONCEPT_ID' cdmFieldName,
'2211747' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.procedure_concept_id =  2211747
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
	where procedure_concept_id =  2211747
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_CONCEPT_ID
conceptId =  2211749
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_CONCEPT_ID' cdmFieldName,
'2211749' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.procedure_concept_id =  2211749
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
	where procedure_concept_id =  2211749
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_CONCEPT_ID
conceptId =  2211751
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_CONCEPT_ID' cdmFieldName,
'2211751' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.procedure_concept_id =  2211751
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
	where procedure_concept_id =  2211751
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_CONCEPT_ID
conceptId =  2211753
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_CONCEPT_ID' cdmFieldName,
'2211753' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.procedure_concept_id =  2211753
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
	where procedure_concept_id =  2211753
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_CONCEPT_ID
conceptId =  2211755
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_CONCEPT_ID' cdmFieldName,
'2211755' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.procedure_concept_id =  2211755
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
	where procedure_concept_id =  2211755
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_CONCEPT_ID
conceptId =  2211756
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_CONCEPT_ID' cdmFieldName,
'2211756' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.procedure_concept_id =  2211756
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
	where procedure_concept_id =  2211756
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_CONCEPT_ID
conceptId =  2211757
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_CONCEPT_ID' cdmFieldName,
'2211757' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.procedure_concept_id =  2211757
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
	where procedure_concept_id =  2211757
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_CONCEPT_ID
conceptId =  2211765
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_CONCEPT_ID' cdmFieldName,
'2211765' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.procedure_concept_id =  2211765
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
	where procedure_concept_id =  2211765
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_CONCEPT_ID
conceptId =  2211769
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_CONCEPT_ID' cdmFieldName,
'2211769' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.procedure_concept_id =  2211769
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
	where procedure_concept_id =  2211769
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_CONCEPT_ID
conceptId =  2617204
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_CONCEPT_ID' cdmFieldName,
'2617204' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.procedure_concept_id =  2617204
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
	where procedure_concept_id =  2617204
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_CONCEPT_ID
conceptId =  2721063
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_CONCEPT_ID' cdmFieldName,
'2721063' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.procedure_concept_id =  2721063
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
	where procedure_concept_id =  2721063
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_CONCEPT_ID
conceptId =  2721064
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_CONCEPT_ID' cdmFieldName,
'2721064' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.procedure_concept_id =  2721064
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
	where procedure_concept_id =  2721064
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_CONCEPT_ID
conceptId =  2780478
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_CONCEPT_ID' cdmFieldName,
'2780478' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.procedure_concept_id =  2780478
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
	where procedure_concept_id =  2780478
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_CONCEPT_ID
conceptId =  2780523
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_CONCEPT_ID' cdmFieldName,
'2780523' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.procedure_concept_id =  2780523
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
	where procedure_concept_id =  2780523
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =  4005743
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'4005743' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =  4005743
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =  4005743
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =  4005933
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'4005933' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =  4005933
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =  4005933
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =  4012343
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'4012343' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =  4012343
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =  4012343
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =  4016155
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'4016155' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =  4016155
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =  4016155
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_CONCEPT_ID
conceptId =  4021531
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_CONCEPT_ID' cdmFieldName,
'4021531' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.procedure_concept_id =  4021531
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
	where procedure_concept_id =  4021531
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =  4032594
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'4032594' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =  4032594
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =  4032594
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_CONCEPT_ID
conceptId =  4032622
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_CONCEPT_ID' cdmFieldName,
'4032622' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.procedure_concept_id =  4032622
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
	where procedure_concept_id =  4032622
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_CONCEPT_ID
conceptId =  4038747
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_CONCEPT_ID' cdmFieldName,
'4038747' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.procedure_concept_id =  4038747
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
	where procedure_concept_id =  4038747
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =  4048225
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'4048225' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =  4048225
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =  4048225
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =  4050091
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'4050091' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =  4050091
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =  4050091
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =  4051956
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'4051956' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =  4051956
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =  4051956
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_CONCEPT_ID
conceptId =  4052532
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_CONCEPT_ID' cdmFieldName,
'4052532' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.procedure_concept_id =  4052532
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
	where procedure_concept_id =  4052532
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =  4054550
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'4054550' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =  4054550
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =  4054550
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =  4056903
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'4056903' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =  4056903
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =  4056903
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_CONCEPT_ID
conceptId =  4058792
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_CONCEPT_ID' cdmFieldName,
'4058792' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.procedure_concept_id =  4058792
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
	where procedure_concept_id =  4058792
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =  4060207
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'4060207' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =  4060207
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =  4060207
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =  4060556
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'4060556' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =  4060556
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =  4060556
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =  4060558
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'4060558' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =  4060558
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =  4060558
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =  4060559
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'4060559' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =  4060559
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =  4060559
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =  4061050
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'4061050' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =  4061050
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =  4061050
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =  4071874
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'4071874' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =  4071874
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =  4071874
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_CONCEPT_ID
conceptId =  4073700
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_CONCEPT_ID' cdmFieldName,
'4073700' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.procedure_concept_id =  4073700
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
	where procedure_concept_id =  4073700
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =  4081648
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'4081648' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =  4081648
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =  4081648
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_CONCEPT_ID
conceptId =  4083772
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_CONCEPT_ID' cdmFieldName,
'4083772' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.procedure_concept_id =  4083772
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
	where procedure_concept_id =  4083772
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =  4090039
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'4090039' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =  4090039
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =  4090039
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =  4092515
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'4092515' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =  4092515
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =  4092515
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =  4093346
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'4093346' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =  4093346
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =  4093346
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =  4095940
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'4095940' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =  4095940
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =  4095940
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_CONCEPT_ID
conceptId =  4096783
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_CONCEPT_ID' cdmFieldName,
'4096783' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.procedure_concept_id =  4096783
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
	where procedure_concept_id =  4096783
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =  4109081
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'4109081' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =  4109081
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =  4109081
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_CONCEPT_ID
conceptId =  4127886
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_CONCEPT_ID' cdmFieldName,
'4127886' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.procedure_concept_id =  4127886
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
	where procedure_concept_id =  4127886
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =  4128329
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'4128329' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =  4128329
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =  4128329
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =  4129155
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'4129155' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =  4129155
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =  4129155
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_CONCEPT_ID
conceptId =  4138738
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_CONCEPT_ID' cdmFieldName,
'4138738' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.procedure_concept_id =  4138738
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
	where procedure_concept_id =  4138738
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =  4140828
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'4140828' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =  4140828
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =  4140828
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_CONCEPT_ID
conceptId =  4141940
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_CONCEPT_ID' cdmFieldName,
'4141940' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.procedure_concept_id =  4141940
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
	where procedure_concept_id =  4141940
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =  4143116
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'4143116' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =  4143116
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =  4143116
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_CONCEPT_ID
conceptId =  4146777
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_CONCEPT_ID' cdmFieldName,
'4146777' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.procedure_concept_id =  4146777
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
	where procedure_concept_id =  4146777
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =  4147021
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'4147021' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =  4147021
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =  4147021
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =  4149084
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'4149084' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =  4149084
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =  4149084
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =  4150042
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'4150042' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =  4150042
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =  4150042
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =  4150816
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'4150816' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =  4150816
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =  4150816
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =  4155529
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'4155529' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =  4155529
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =  4155529
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =  4156113
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'4156113' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =  4156113
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =  4156113
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_CONCEPT_ID
conceptId =  4161944
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_CONCEPT_ID' cdmFieldName,
'4161944' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.procedure_concept_id =  4161944
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
	where procedure_concept_id =  4161944
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =  4162860
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'4162860' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =  4162860
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =  4162860
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =  4163261
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'4163261' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =  4163261
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =  4163261
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =  4171394
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'4171394' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =  4171394
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =  4171394
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =  4171915
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'4171915' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =  4171915
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =  4171915
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =  4180978
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'4180978' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =  4180978
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =  4180978
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_CONCEPT_ID
conceptId =  4181912
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_CONCEPT_ID' cdmFieldName,
'4181912' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.procedure_concept_id =  4181912
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
	where procedure_concept_id =  4181912
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =  4194652
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'4194652' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =  4194652
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =  4194652
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =  4199600
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'4199600' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =  4199600
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =  4199600
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_CONCEPT_ID
conceptId =  4234536
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_CONCEPT_ID' cdmFieldName,
'4234536' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.procedure_concept_id =  4234536
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
	where procedure_concept_id =  4234536
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =  4235215
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'4235215' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =  4235215
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =  4235215
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_CONCEPT_ID
conceptId =  4238715
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_CONCEPT_ID' cdmFieldName,
'4238715' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.procedure_concept_id =  4238715
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
	where procedure_concept_id =  4238715
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_CONCEPT_ID
conceptId =  4243919
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_CONCEPT_ID' cdmFieldName,
'4243919' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.procedure_concept_id =  4243919
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
	where procedure_concept_id =  4243919
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =  4260520
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'4260520' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =  4260520
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =  4260520
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =  4270932
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'4270932' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =  4270932
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =  4270932
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_CONCEPT_ID
conceptId =  4275113
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_CONCEPT_ID' cdmFieldName,
'4275113' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.procedure_concept_id =  4275113
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
	where procedure_concept_id =  4275113
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =  4279913
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'4279913' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =  4279913
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =  4279913
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =  4281030
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'4281030' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =  4281030
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =  4281030
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =  4294393
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'4294393' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =  4294393
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =  4294393
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_CONCEPT_ID
conceptId =  4294805
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_CONCEPT_ID' cdmFieldName,
'4294805' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.procedure_concept_id =  4294805
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
	where procedure_concept_id =  4294805
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =  4295261
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'4295261' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =  4295261
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =  4295261
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =  4303258
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'4303258' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =  4303258
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =  4303258
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_CONCEPT_ID
conceptId =  4306780
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_CONCEPT_ID' cdmFieldName,
'4306780' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.procedure_concept_id =  4306780
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
	where procedure_concept_id =  4306780
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_CONCEPT_ID
conceptId =  4310552
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_CONCEPT_ID' cdmFieldName,
'4310552' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.procedure_concept_id =  4310552
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
	where procedure_concept_id =  4310552
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =  4320332
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'4320332' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =  4320332
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =  4320332
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_CONCEPT_ID
conceptId =  4321575
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_CONCEPT_ID' cdmFieldName,
'4321575' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.procedure_concept_id =  4321575
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
	where procedure_concept_id =  4321575
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_CONCEPT_ID
conceptId =  4330583
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'PROCEDURE_OCCURRENCE' cdmTableName,
'PROCEDURE_CONCEPT_ID' cdmFieldName,
'4330583' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.procedure_concept_id =  4330583
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
	where procedure_concept_id =  4330583
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId =  4339088
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'4339088' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id =  4339088
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id =  4339088
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId = 40481080
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'40481080' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id = 40481080
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id = 40481080
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId = 40482030
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'40482030' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id = 40482030
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id = 40482030
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId = 40482406
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'40482406' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id = 40482406
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id = 40482406
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId = 40483613
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'40483613' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id = 40483613
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id = 40483613
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId = 40490888
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'40490888' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id = 40490888
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id = 40490888
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId = 42709954
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'42709954' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id = 42709954
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id = 42709954
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId = 45757415
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'45757415' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id = 45757415
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id = 45757415
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId = 45766654
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'45766654' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id = 45766654
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id = 45766654
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId = 45770892
plausibleGender = Female
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'45770892' conceptId,
'Female' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id = 45770892
		  and p.gender_concept_id <> 8532 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id = 45770892
) denominator
;

/*********
CONCEPT LEVEL check:
PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
conceptId = 45772671
plausibleGender = Male
**********/

INSERT INTO CY_IMOSPHERE_CDM_531.DQD_Results
(
   level,
   check,
   cdmTableName,
cdmFieldName,
conceptId,
plausibleGender,
   num_violated_rows,
   pct_violated_rows,
   num_denominator_rows
)
select 
'CONCEPT LEVEL check' level,
    'PLAUSIBLE_GENDER - number of records of a given concept which occur in person with implausible gender for that concept' check,
    'CONDITION_OCCURRENCE' cdmTableName,
'CONDITION_CONCEPT_ID' cdmFieldName,
'45772671' conceptId,
'Male' plausibleGender,
      num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(*) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
			inner join CY_IMOSPHERE_CDM_531.person p
			on cdmtable.person_id = p.person_id
		where cdmtable.condition_concept_id = 45772671
		  and p.gender_concept_id <> 8507 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
	where condition_concept_id = 45772671
) denominator
;

