/*********
FK_CLASS
Drug era standard concepts, ingredients only
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
vocabDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DRUG_ERA
cdmFieldName = DRUG_CONCEPT_ID
fkClass = Ingredient
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from (
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from (
		/*violatedRowsBegin*/
		select 
		  'DRUG_ERA.DRUG_CONCEPT_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.drug_era cdmtable
		  left join CY_CDM_VOCAB.concept co
		  on cdmtable.drug_concept_id = co.concept_id
    where co.concept_id != 0 
      and (co.concept_class_id != 'Ingredient') 
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.drug_era cdmtable
) denominator
;

