/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PERSON
cdmFieldName = PERSON_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'PERSON.PERSON_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.person cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.person_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.person_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.person_id) as STRING)) != 0
		  )
      and cdmtable.person_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.person
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PERSON
cdmFieldName = GENDER_CONCEPT_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'PERSON.GENDER_CONCEPT_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.person cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.gender_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.gender_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.gender_concept_id) as STRING)) != 0
		  )
      and cdmtable.gender_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.person
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PERSON
cdmFieldName = YEAR_OF_BIRTH
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'PERSON.YEAR_OF_BIRTH' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.person cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.year_of_birth AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.year_of_birth AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.year_of_birth) as STRING)) != 0
		  )
      and cdmtable.year_of_birth is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.person
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PERSON
cdmFieldName = MONTH_OF_BIRTH
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'PERSON.MONTH_OF_BIRTH' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.person cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.month_of_birth AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.month_of_birth AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.month_of_birth) as STRING)) != 0
		  )
      and cdmtable.month_of_birth is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.person
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PERSON
cdmFieldName = DAY_OF_BIRTH
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'PERSON.DAY_OF_BIRTH' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.person cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.day_of_birth AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.day_of_birth AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.day_of_birth) as STRING)) != 0
		  )
      and cdmtable.day_of_birth is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.person
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PERSON
cdmFieldName = RACE_CONCEPT_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'PERSON.RACE_CONCEPT_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.person cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.race_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.race_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.race_concept_id) as STRING)) != 0
		  )
      and cdmtable.race_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.person
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PERSON
cdmFieldName = ETHNICITY_CONCEPT_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'PERSON.ETHNICITY_CONCEPT_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.person cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.ethnicity_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.ethnicity_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.ethnicity_concept_id) as STRING)) != 0
		  )
      and cdmtable.ethnicity_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.person
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PERSON
cdmFieldName = LOCATION_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'PERSON.LOCATION_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.person cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.location_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.location_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.location_id) as STRING)) != 0
		  )
      and cdmtable.location_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.person
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PERSON
cdmFieldName = PROVIDER_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'PERSON.PROVIDER_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.person cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.provider_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.provider_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.provider_id) as STRING)) != 0
		  )
      and cdmtable.provider_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.person
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PERSON
cdmFieldName = CARE_SITE_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'PERSON.CARE_SITE_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.person cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.care_site_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.care_site_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.care_site_id) as STRING)) != 0
		  )
      and cdmtable.care_site_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.person
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = OBSERVATION_PERIOD
cdmFieldName = OBSERVATION_PERIOD_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'OBSERVATION_PERIOD.OBSERVATION_PERIOD_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.observation_period cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.observation_period_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.observation_period_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.observation_period_id) as STRING)) != 0
		  )
      and cdmtable.observation_period_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.observation_period
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = OBSERVATION_PERIOD
cdmFieldName = PERSON_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'OBSERVATION_PERIOD.PERSON_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.observation_period cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.person_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.person_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.person_id) as STRING)) != 0
		  )
      and cdmtable.person_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.observation_period
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_OCCURRENCE
cdmFieldName = VISIT_OCCURRENCE_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'VISIT_OCCURRENCE.VISIT_OCCURRENCE_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.visit_occurrence_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.visit_occurrence_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.visit_occurrence_id) as STRING)) != 0
		  )
      and cdmtable.visit_occurrence_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_occurrence
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_OCCURRENCE
cdmFieldName = PERSON_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'VISIT_OCCURRENCE.PERSON_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.person_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.person_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.person_id) as STRING)) != 0
		  )
      and cdmtable.person_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_occurrence
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_OCCURRENCE
cdmFieldName = VISIT_CONCEPT_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'VISIT_OCCURRENCE.VISIT_CONCEPT_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.visit_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.visit_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.visit_concept_id) as STRING)) != 0
		  )
      and cdmtable.visit_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_occurrence
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_OCCURRENCE
cdmFieldName = PROVIDER_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'VISIT_OCCURRENCE.PROVIDER_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.provider_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.provider_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.provider_id) as STRING)) != 0
		  )
      and cdmtable.provider_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_occurrence
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_OCCURRENCE
cdmFieldName = CARE_SITE_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'VISIT_OCCURRENCE.CARE_SITE_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.care_site_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.care_site_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.care_site_id) as STRING)) != 0
		  )
      and cdmtable.care_site_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_occurrence
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_OCCURRENCE
cdmFieldName = VISIT_SOURCE_CONCEPT_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'VISIT_OCCURRENCE.VISIT_SOURCE_CONCEPT_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.visit_source_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.visit_source_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.visit_source_concept_id) as STRING)) != 0
		  )
      and cdmtable.visit_source_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_occurrence
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_OCCURRENCE
cdmFieldName = ADMITTING_SOURCE_CONCEPT_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'VISIT_OCCURRENCE.ADMITTING_SOURCE_CONCEPT_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.admitting_source_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.admitting_source_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.admitting_source_concept_id) as STRING)) != 0
		  )
      and cdmtable.admitting_source_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_occurrence
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_OCCURRENCE
cdmFieldName = DISCHARGE_TO_CONCEPT_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'VISIT_OCCURRENCE.DISCHARGE_TO_CONCEPT_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.discharge_to_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.discharge_to_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.discharge_to_concept_id) as STRING)) != 0
		  )
      and cdmtable.discharge_to_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_occurrence
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_OCCURRENCE
cdmFieldName = PRECEDING_VISIT_OCCURRENCE_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'VISIT_OCCURRENCE.PRECEDING_VISIT_OCCURRENCE_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.visit_occurrence cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.preceding_visit_occurrence_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.preceding_visit_occurrence_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.preceding_visit_occurrence_id) as STRING)) != 0
		  )
      and cdmtable.preceding_visit_occurrence_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_occurrence
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_CONCEPT_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'CONDITION_OCCURRENCE.CONDITION_CONCEPT_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.condition_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.condition_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.condition_concept_id) as STRING)) != 0
		  )
      and cdmtable.condition_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_TYPE_CONCEPT_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'CONDITION_OCCURRENCE.CONDITION_TYPE_CONCEPT_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.condition_type_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.condition_type_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.condition_type_concept_id) as STRING)) != 0
		  )
      and cdmtable.condition_type_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_STATUS_CONCEPT_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'CONDITION_OCCURRENCE.CONDITION_STATUS_CONCEPT_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.condition_status_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.condition_status_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.condition_status_concept_id) as STRING)) != 0
		  )
      and cdmtable.condition_status_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = PROVIDER_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'CONDITION_OCCURRENCE.PROVIDER_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.provider_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.provider_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.provider_id) as STRING)) != 0
		  )
      and cdmtable.provider_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = VISIT_OCCURRENCE_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'CONDITION_OCCURRENCE.VISIT_OCCURRENCE_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.visit_occurrence_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.visit_occurrence_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.visit_occurrence_id) as STRING)) != 0
		  )
      and cdmtable.visit_occurrence_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = VISIT_DETAIL_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'CONDITION_OCCURRENCE.VISIT_DETAIL_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.visit_detail_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.visit_detail_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.visit_detail_id) as STRING)) != 0
		  )
      and cdmtable.visit_detail_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_OCCURRENCE
cdmFieldName = CONDITION_SOURCE_CONCEPT_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'CONDITION_OCCURRENCE.CONDITION_SOURCE_CONCEPT_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_occurrence cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.condition_source_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.condition_source_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.condition_source_concept_id) as STRING)) != 0
		  )
      and cdmtable.condition_source_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_occurrence
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DRUG_EXPOSURE
cdmFieldName = DRUG_CONCEPT_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'DRUG_EXPOSURE.DRUG_CONCEPT_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.drug_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.drug_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.drug_concept_id) as STRING)) != 0
		  )
      and cdmtable.drug_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.drug_exposure
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DRUG_EXPOSURE
cdmFieldName = DRUG_TYPE_CONCEPT_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'DRUG_EXPOSURE.DRUG_TYPE_CONCEPT_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.drug_type_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.drug_type_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.drug_type_concept_id) as STRING)) != 0
		  )
      and cdmtable.drug_type_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.drug_exposure
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DRUG_EXPOSURE
cdmFieldName = REFILLS
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'DRUG_EXPOSURE.REFILLS' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.refills AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.refills AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.refills) as STRING)) != 0
		  )
      and cdmtable.refills is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.drug_exposure
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DRUG_EXPOSURE
cdmFieldName = DAYS_SUPPLY
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'DRUG_EXPOSURE.DAYS_SUPPLY' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.days_supply AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.days_supply AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.days_supply) as STRING)) != 0
		  )
      and cdmtable.days_supply is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.drug_exposure
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DRUG_EXPOSURE
cdmFieldName = ROUTE_CONCEPT_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'DRUG_EXPOSURE.ROUTE_CONCEPT_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.route_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.route_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.route_concept_id) as STRING)) != 0
		  )
      and cdmtable.route_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.drug_exposure
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DRUG_EXPOSURE
cdmFieldName = PROVIDER_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'DRUG_EXPOSURE.PROVIDER_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.provider_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.provider_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.provider_id) as STRING)) != 0
		  )
      and cdmtable.provider_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.drug_exposure
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DRUG_EXPOSURE
cdmFieldName = VISIT_OCCURRENCE_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'DRUG_EXPOSURE.VISIT_OCCURRENCE_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.visit_occurrence_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.visit_occurrence_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.visit_occurrence_id) as STRING)) != 0
		  )
      and cdmtable.visit_occurrence_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.drug_exposure
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DRUG_EXPOSURE
cdmFieldName = VISIT_DETAIL_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'DRUG_EXPOSURE.VISIT_DETAIL_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.visit_detail_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.visit_detail_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.visit_detail_id) as STRING)) != 0
		  )
      and cdmtable.visit_detail_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.drug_exposure
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DRUG_EXPOSURE
cdmFieldName = DRUG_SOURCE_CONCEPT_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'DRUG_EXPOSURE.DRUG_SOURCE_CONCEPT_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.drug_exposure cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.drug_source_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.drug_source_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.drug_source_concept_id) as STRING)) != 0
		  )
      and cdmtable.drug_source_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.drug_exposure
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_OCCURRENCE_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'PROCEDURE_OCCURRENCE.PROCEDURE_OCCURRENCE_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.procedure_occurrence_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.procedure_occurrence_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.procedure_occurrence_id) as STRING)) != 0
		  )
      and cdmtable.procedure_occurrence_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PERSON_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'PROCEDURE_OCCURRENCE.PERSON_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.person_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.person_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.person_id) as STRING)) != 0
		  )
      and cdmtable.person_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_CONCEPT_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'PROCEDURE_OCCURRENCE.PROCEDURE_CONCEPT_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.procedure_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.procedure_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.procedure_concept_id) as STRING)) != 0
		  )
      and cdmtable.procedure_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_TYPE_CONCEPT_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'PROCEDURE_OCCURRENCE.PROCEDURE_TYPE_CONCEPT_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.procedure_type_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.procedure_type_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.procedure_type_concept_id) as STRING)) != 0
		  )
      and cdmtable.procedure_type_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = MODIFIER_CONCEPT_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'PROCEDURE_OCCURRENCE.MODIFIER_CONCEPT_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.modifier_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.modifier_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.modifier_concept_id) as STRING)) != 0
		  )
      and cdmtable.modifier_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = QUANTITY
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'PROCEDURE_OCCURRENCE.QUANTITY' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.quantity AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.quantity AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.quantity) as STRING)) != 0
		  )
      and cdmtable.quantity is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROVIDER_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'PROCEDURE_OCCURRENCE.PROVIDER_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.provider_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.provider_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.provider_id) as STRING)) != 0
		  )
      and cdmtable.provider_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = VISIT_OCCURRENCE_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'PROCEDURE_OCCURRENCE.VISIT_OCCURRENCE_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.visit_occurrence_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.visit_occurrence_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.visit_occurrence_id) as STRING)) != 0
		  )
      and cdmtable.visit_occurrence_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = VISIT_DETAIL_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'PROCEDURE_OCCURRENCE.VISIT_DETAIL_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.visit_detail_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.visit_detail_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.visit_detail_id) as STRING)) != 0
		  )
      and cdmtable.visit_detail_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROCEDURE_OCCURRENCE
cdmFieldName = PROCEDURE_SOURCE_CONCEPT_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'PROCEDURE_OCCURRENCE.PROCEDURE_SOURCE_CONCEPT_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.procedure_occurrence cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.procedure_source_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.procedure_source_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.procedure_source_concept_id) as STRING)) != 0
		  )
      and cdmtable.procedure_source_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.procedure_occurrence
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DEVICE_EXPOSURE
cdmFieldName = DEVICE_CONCEPT_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'DEVICE_EXPOSURE.DEVICE_CONCEPT_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.device_exposure cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.device_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.device_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.device_concept_id) as STRING)) != 0
		  )
      and cdmtable.device_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.device_exposure
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DEVICE_EXPOSURE
cdmFieldName = DEVICE_TYPE_CONCEPT_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'DEVICE_EXPOSURE.DEVICE_TYPE_CONCEPT_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.device_exposure cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.device_type_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.device_type_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.device_type_concept_id) as STRING)) != 0
		  )
      and cdmtable.device_type_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.device_exposure
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DEVICE_EXPOSURE
cdmFieldName = QUANTITY
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'DEVICE_EXPOSURE.QUANTITY' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.device_exposure cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.quantity AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.quantity AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.quantity) as STRING)) != 0
		  )
      and cdmtable.quantity is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.device_exposure
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DEVICE_EXPOSURE
cdmFieldName = PROVIDER_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'DEVICE_EXPOSURE.PROVIDER_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.device_exposure cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.provider_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.provider_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.provider_id) as STRING)) != 0
		  )
      and cdmtable.provider_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.device_exposure
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DEVICE_EXPOSURE
cdmFieldName = VISIT_OCCURRENCE_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'DEVICE_EXPOSURE.VISIT_OCCURRENCE_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.device_exposure cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.visit_occurrence_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.visit_occurrence_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.visit_occurrence_id) as STRING)) != 0
		  )
      and cdmtable.visit_occurrence_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.device_exposure
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DEVICE_EXPOSURE
cdmFieldName = VISIT_DETAIL_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'DEVICE_EXPOSURE.VISIT_DETAIL_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.device_exposure cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.visit_detail_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.visit_detail_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.visit_detail_id) as STRING)) != 0
		  )
      and cdmtable.visit_detail_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.device_exposure
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DEVICE_EXPOSURE
cdmFieldName = DEVICE_SOURCE_CONCEPT_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'DEVICE_EXPOSURE.DEVICE_SOURCE_CONCEPT_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.device_exposure cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.device_source_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.device_source_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.device_source_concept_id) as STRING)) != 0
		  )
      and cdmtable.device_source_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.device_exposure
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = MEASUREMENT
cdmFieldName = MEASUREMENT_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'MEASUREMENT.MEASUREMENT_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.measurement cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.measurement_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.measurement_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.measurement_id) as STRING)) != 0
		  )
      and cdmtable.measurement_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.measurement
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = MEASUREMENT
cdmFieldName = PERSON_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'MEASUREMENT.PERSON_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.measurement cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.person_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.person_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.person_id) as STRING)) != 0
		  )
      and cdmtable.person_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.measurement
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = MEASUREMENT
cdmFieldName = MEASUREMENT_CONCEPT_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'MEASUREMENT.MEASUREMENT_CONCEPT_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.measurement cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.measurement_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.measurement_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.measurement_concept_id) as STRING)) != 0
		  )
      and cdmtable.measurement_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.measurement
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = MEASUREMENT
cdmFieldName = MEASUREMENT_TYPE_CONCEPT_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'MEASUREMENT.MEASUREMENT_TYPE_CONCEPT_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.measurement cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.measurement_type_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.measurement_type_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.measurement_type_concept_id) as STRING)) != 0
		  )
      and cdmtable.measurement_type_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.measurement
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = MEASUREMENT
cdmFieldName = OPERATOR_CONCEPT_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'MEASUREMENT.OPERATOR_CONCEPT_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.measurement cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.operator_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.operator_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.operator_concept_id) as STRING)) != 0
		  )
      and cdmtable.operator_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.measurement
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = MEASUREMENT
cdmFieldName = VALUE_AS_CONCEPT_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'MEASUREMENT.VALUE_AS_CONCEPT_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.measurement cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.value_as_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.value_as_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.value_as_concept_id) as STRING)) != 0
		  )
      and cdmtable.value_as_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.measurement
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = MEASUREMENT
cdmFieldName = UNIT_CONCEPT_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'MEASUREMENT.UNIT_CONCEPT_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.measurement cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.unit_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.unit_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.unit_concept_id) as STRING)) != 0
		  )
      and cdmtable.unit_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.measurement
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = MEASUREMENT
cdmFieldName = PROVIDER_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'MEASUREMENT.PROVIDER_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.measurement cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.provider_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.provider_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.provider_id) as STRING)) != 0
		  )
      and cdmtable.provider_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.measurement
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = MEASUREMENT
cdmFieldName = VISIT_OCCURRENCE_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'MEASUREMENT.VISIT_OCCURRENCE_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.measurement cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.visit_occurrence_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.visit_occurrence_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.visit_occurrence_id) as STRING)) != 0
		  )
      and cdmtable.visit_occurrence_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.measurement
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = MEASUREMENT
cdmFieldName = VISIT_DETAIL_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'MEASUREMENT.VISIT_DETAIL_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.measurement cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.visit_detail_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.visit_detail_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.visit_detail_id) as STRING)) != 0
		  )
      and cdmtable.visit_detail_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.measurement
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = MEASUREMENT
cdmFieldName = MEASUREMENT_SOURCE_CONCEPT_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'MEASUREMENT.MEASUREMENT_SOURCE_CONCEPT_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.measurement cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.measurement_source_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.measurement_source_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.measurement_source_concept_id) as STRING)) != 0
		  )
      and cdmtable.measurement_source_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.measurement
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_DETAIL
cdmFieldName = VISIT_DETAIL_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'VISIT_DETAIL.VISIT_DETAIL_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.visit_detail_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.visit_detail_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.visit_detail_id) as STRING)) != 0
		  )
      and cdmtable.visit_detail_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_detail
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_DETAIL
cdmFieldName = PERSON_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'VISIT_DETAIL.PERSON_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.person_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.person_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.person_id) as STRING)) != 0
		  )
      and cdmtable.person_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_detail
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_DETAIL
cdmFieldName = VISIT_DETAIL_CONCEPT_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'VISIT_DETAIL.VISIT_DETAIL_CONCEPT_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.visit_detail_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.visit_detail_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.visit_detail_concept_id) as STRING)) != 0
		  )
      and cdmtable.visit_detail_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_detail
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_DETAIL
cdmFieldName = PROVIDER_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'VISIT_DETAIL.PROVIDER_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.provider_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.provider_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.provider_id) as STRING)) != 0
		  )
      and cdmtable.provider_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_detail
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = VISIT_DETAIL
cdmFieldName = CARE_SITE_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'VISIT_DETAIL.CARE_SITE_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.visit_detail cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.care_site_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.care_site_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.care_site_id) as STRING)) != 0
		  )
      and cdmtable.care_site_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.visit_detail
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = NOTE
cdmFieldName = NOTE_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'NOTE.NOTE_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.note cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.note_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.note_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.note_id) as STRING)) != 0
		  )
      and cdmtable.note_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.note
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = NOTE
cdmFieldName = PERSON_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'NOTE.PERSON_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.note cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.person_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.person_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.person_id) as STRING)) != 0
		  )
      and cdmtable.person_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.note
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = NOTE
cdmFieldName = NOTE_TYPE_CONCEPT_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'NOTE.NOTE_TYPE_CONCEPT_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.note cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.note_type_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.note_type_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.note_type_concept_id) as STRING)) != 0
		  )
      and cdmtable.note_type_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.note
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = NOTE
cdmFieldName = NOTE_CLASS_CONCEPT_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'NOTE.NOTE_CLASS_CONCEPT_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.note cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.note_class_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.note_class_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.note_class_concept_id) as STRING)) != 0
		  )
      and cdmtable.note_class_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.note
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = NOTE
cdmFieldName = ENCODING_CONCEPT_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'NOTE.ENCODING_CONCEPT_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.note cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.encoding_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.encoding_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.encoding_concept_id) as STRING)) != 0
		  )
      and cdmtable.encoding_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.note
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = NOTE
cdmFieldName = LANGUAGE_CONCEPT_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'NOTE.LANGUAGE_CONCEPT_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.note cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.language_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.language_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.language_concept_id) as STRING)) != 0
		  )
      and cdmtable.language_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.note
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = NOTE
cdmFieldName = PROVIDER_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'NOTE.PROVIDER_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.note cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.provider_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.provider_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.provider_id) as STRING)) != 0
		  )
      and cdmtable.provider_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.note
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = NOTE
cdmFieldName = VISIT_OCCURRENCE_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'NOTE.VISIT_OCCURRENCE_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.note cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.visit_occurrence_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.visit_occurrence_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.visit_occurrence_id) as STRING)) != 0
		  )
      and cdmtable.visit_occurrence_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.note
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = NOTE
cdmFieldName = VISIT_DETAIL_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'NOTE.VISIT_DETAIL_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.note cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.visit_detail_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.visit_detail_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.visit_detail_id) as STRING)) != 0
		  )
      and cdmtable.visit_detail_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.note
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = NOTE_NLP
cdmFieldName = NOTE_NLP_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'NOTE_NLP.NOTE_NLP_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.note_nlp cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.note_nlp_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.note_nlp_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.note_nlp_id) as STRING)) != 0
		  )
      and cdmtable.note_nlp_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.note_nlp
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = NOTE_NLP
cdmFieldName = NOTE_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'NOTE_NLP.NOTE_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.note_nlp cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.note_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.note_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.note_id) as STRING)) != 0
		  )
      and cdmtable.note_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.note_nlp
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = NOTE_NLP
cdmFieldName = SECTION_CONCEPT_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'NOTE_NLP.SECTION_CONCEPT_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.note_nlp cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.section_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.section_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.section_concept_id) as STRING)) != 0
		  )
      and cdmtable.section_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.note_nlp
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = NOTE_NLP
cdmFieldName = NOTE_NLP_CONCEPT_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'NOTE_NLP.NOTE_NLP_CONCEPT_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.note_nlp cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.note_nlp_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.note_nlp_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.note_nlp_concept_id) as STRING)) != 0
		  )
      and cdmtable.note_nlp_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.note_nlp
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = NOTE_NLP
cdmFieldName = NOTE_NLP_SOURCE_CONCEPT_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'NOTE_NLP.NOTE_NLP_SOURCE_CONCEPT_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.note_nlp cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.note_nlp_source_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.note_nlp_source_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.note_nlp_source_concept_id) as STRING)) != 0
		  )
      and cdmtable.note_nlp_source_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.note_nlp
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = OBSERVATION
cdmFieldName = OBSERVATION_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'OBSERVATION.OBSERVATION_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.observation cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.observation_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.observation_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.observation_id) as STRING)) != 0
		  )
      and cdmtable.observation_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.observation
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = OBSERVATION
cdmFieldName = PERSON_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'OBSERVATION.PERSON_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.observation cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.person_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.person_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.person_id) as STRING)) != 0
		  )
      and cdmtable.person_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.observation
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = OBSERVATION
cdmFieldName = OBSERVATION_CONCEPT_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'OBSERVATION.OBSERVATION_CONCEPT_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.observation cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.observation_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.observation_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.observation_concept_id) as STRING)) != 0
		  )
      and cdmtable.observation_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.observation
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = OBSERVATION
cdmFieldName = OBSERVATION_TYPE_CONCEPT_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'OBSERVATION.OBSERVATION_TYPE_CONCEPT_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.observation cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.observation_type_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.observation_type_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.observation_type_concept_id) as STRING)) != 0
		  )
      and cdmtable.observation_type_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.observation
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = OBSERVATION
cdmFieldName = QUALIFIER_CONCEPT_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'OBSERVATION.QUALIFIER_CONCEPT_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.observation cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.qualifier_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.qualifier_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.qualifier_concept_id) as STRING)) != 0
		  )
      and cdmtable.qualifier_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.observation
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = OBSERVATION
cdmFieldName = UNIT_CONCEPT_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'OBSERVATION.UNIT_CONCEPT_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.observation cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.unit_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.unit_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.unit_concept_id) as STRING)) != 0
		  )
      and cdmtable.unit_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.observation
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = OBSERVATION
cdmFieldName = PROVIDER_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'OBSERVATION.PROVIDER_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.observation cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.provider_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.provider_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.provider_id) as STRING)) != 0
		  )
      and cdmtable.provider_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.observation
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = OBSERVATION
cdmFieldName = VISIT_OCCURRENCE_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'OBSERVATION.VISIT_OCCURRENCE_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.observation cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.visit_occurrence_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.visit_occurrence_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.visit_occurrence_id) as STRING)) != 0
		  )
      and cdmtable.visit_occurrence_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.observation
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = OBSERVATION
cdmFieldName = VISIT_DETAIL_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'OBSERVATION.VISIT_DETAIL_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.observation cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.visit_detail_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.visit_detail_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.visit_detail_id) as STRING)) != 0
		  )
      and cdmtable.visit_detail_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.observation
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = OBSERVATION
cdmFieldName = OBSERVATION_SOURCE_CONCEPT_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'OBSERVATION.OBSERVATION_SOURCE_CONCEPT_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.observation cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.observation_source_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.observation_source_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.observation_source_concept_id) as STRING)) != 0
		  )
      and cdmtable.observation_source_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.observation
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = FACT_RELATIONSHIP
cdmFieldName = DOMAIN_CONCEPT_ID_1
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'FACT_RELATIONSHIP.DOMAIN_CONCEPT_ID_1' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.fact_relationship cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.domain_concept_id_1 AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.domain_concept_id_1 AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.domain_concept_id_1) as STRING)) != 0
		  )
      and cdmtable.domain_concept_id_1 is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.fact_relationship
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = FACT_RELATIONSHIP
cdmFieldName = FACT_ID_1
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'FACT_RELATIONSHIP.FACT_ID_1' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.fact_relationship cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.fact_id_1 AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.fact_id_1 AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.fact_id_1) as STRING)) != 0
		  )
      and cdmtable.fact_id_1 is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.fact_relationship
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = FACT_RELATIONSHIP
cdmFieldName = DOMAIN_CONCEPT_ID_2
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'FACT_RELATIONSHIP.DOMAIN_CONCEPT_ID_2' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.fact_relationship cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.domain_concept_id_2 AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.domain_concept_id_2 AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.domain_concept_id_2) as STRING)) != 0
		  )
      and cdmtable.domain_concept_id_2 is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.fact_relationship
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = FACT_RELATIONSHIP
cdmFieldName = FACT_ID_2
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'FACT_RELATIONSHIP.FACT_ID_2' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.fact_relationship cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.fact_id_2 AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.fact_id_2 AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.fact_id_2) as STRING)) != 0
		  )
      and cdmtable.fact_id_2 is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.fact_relationship
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = FACT_RELATIONSHIP
cdmFieldName = RELATIONSHIP_CONCEPT_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'FACT_RELATIONSHIP.RELATIONSHIP_CONCEPT_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.fact_relationship cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.relationship_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.relationship_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.relationship_concept_id) as STRING)) != 0
		  )
      and cdmtable.relationship_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.fact_relationship
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = LOCATION
cdmFieldName = LOCATION_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'LOCATION.LOCATION_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.location cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.location_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.location_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.location_id) as STRING)) != 0
		  )
      and cdmtable.location_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.location
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CARE_SITE
cdmFieldName = CARE_SITE_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'CARE_SITE.CARE_SITE_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.care_site cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.care_site_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.care_site_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.care_site_id) as STRING)) != 0
		  )
      and cdmtable.care_site_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.care_site
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CARE_SITE
cdmFieldName = PLACE_OF_SERVICE_CONCEPT_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'CARE_SITE.PLACE_OF_SERVICE_CONCEPT_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.care_site cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.place_of_service_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.place_of_service_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.place_of_service_concept_id) as STRING)) != 0
		  )
      and cdmtable.place_of_service_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.care_site
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CARE_SITE
cdmFieldName = LOCATION_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'CARE_SITE.LOCATION_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.care_site cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.location_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.location_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.location_id) as STRING)) != 0
		  )
      and cdmtable.location_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.care_site
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROVIDER
cdmFieldName = PROVIDER_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'PROVIDER.PROVIDER_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.provider cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.provider_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.provider_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.provider_id) as STRING)) != 0
		  )
      and cdmtable.provider_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.provider
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROVIDER
cdmFieldName = SPECIALTY_CONCEPT_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'PROVIDER.SPECIALTY_CONCEPT_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.provider cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.specialty_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.specialty_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.specialty_concept_id) as STRING)) != 0
		  )
      and cdmtable.specialty_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.provider
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROVIDER
cdmFieldName = CARE_SITE_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'PROVIDER.CARE_SITE_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.provider cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.care_site_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.care_site_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.care_site_id) as STRING)) != 0
		  )
      and cdmtable.care_site_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.provider
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROVIDER
cdmFieldName = YEAR_OF_BIRTH
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'PROVIDER.YEAR_OF_BIRTH' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.provider cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.year_of_birth AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.year_of_birth AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.year_of_birth) as STRING)) != 0
		  )
      and cdmtable.year_of_birth is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.provider
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROVIDER
cdmFieldName = GENDER_CONCEPT_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'PROVIDER.GENDER_CONCEPT_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.provider cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.gender_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.gender_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.gender_concept_id) as STRING)) != 0
		  )
      and cdmtable.gender_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.provider
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROVIDER
cdmFieldName = SPECIALTY_SOURCE_CONCEPT_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'PROVIDER.SPECIALTY_SOURCE_CONCEPT_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.provider cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.specialty_source_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.specialty_source_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.specialty_source_concept_id) as STRING)) != 0
		  )
      and cdmtable.specialty_source_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.provider
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PROVIDER
cdmFieldName = GENDER_SOURCE_CONCEPT_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'PROVIDER.GENDER_SOURCE_CONCEPT_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.provider cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.gender_source_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.gender_source_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.gender_source_concept_id) as STRING)) != 0
		  )
      and cdmtable.gender_source_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.provider
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PAYER_PLAN_PERIOD
cdmFieldName = PAYER_PLAN_PERIOD_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'PAYER_PLAN_PERIOD.PAYER_PLAN_PERIOD_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.payer_plan_period cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.payer_plan_period_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.payer_plan_period_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.payer_plan_period_id) as STRING)) != 0
		  )
      and cdmtable.payer_plan_period_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.payer_plan_period
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PAYER_PLAN_PERIOD
cdmFieldName = PERSON_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'PAYER_PLAN_PERIOD.PERSON_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.payer_plan_period cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.person_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.person_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.person_id) as STRING)) != 0
		  )
      and cdmtable.person_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.payer_plan_period
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PAYER_PLAN_PERIOD
cdmFieldName = PAYER_CONCEPT_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'PAYER_PLAN_PERIOD.PAYER_CONCEPT_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.payer_plan_period cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.payer_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.payer_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.payer_concept_id) as STRING)) != 0
		  )
      and cdmtable.payer_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.payer_plan_period
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PAYER_PLAN_PERIOD
cdmFieldName = PAYER_SOURCE_CONCEPT_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'PAYER_PLAN_PERIOD.PAYER_SOURCE_CONCEPT_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.payer_plan_period cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.payer_source_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.payer_source_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.payer_source_concept_id) as STRING)) != 0
		  )
      and cdmtable.payer_source_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.payer_plan_period
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PAYER_PLAN_PERIOD
cdmFieldName = PLAN_CONCEPT_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'PAYER_PLAN_PERIOD.PLAN_CONCEPT_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.payer_plan_period cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.plan_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.plan_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.plan_concept_id) as STRING)) != 0
		  )
      and cdmtable.plan_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.payer_plan_period
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PAYER_PLAN_PERIOD
cdmFieldName = PLAN_SOURCE_CONCEPT_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'PAYER_PLAN_PERIOD.PLAN_SOURCE_CONCEPT_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.payer_plan_period cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.plan_source_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.plan_source_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.plan_source_concept_id) as STRING)) != 0
		  )
      and cdmtable.plan_source_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.payer_plan_period
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PAYER_PLAN_PERIOD
cdmFieldName = SPONSOR_CONCEPT_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'PAYER_PLAN_PERIOD.SPONSOR_CONCEPT_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.payer_plan_period cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.sponsor_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.sponsor_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.sponsor_concept_id) as STRING)) != 0
		  )
      and cdmtable.sponsor_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.payer_plan_period
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PAYER_PLAN_PERIOD
cdmFieldName = SPONSOR_SOURCE_CONCEPT_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'PAYER_PLAN_PERIOD.SPONSOR_SOURCE_CONCEPT_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.payer_plan_period cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.sponsor_source_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.sponsor_source_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.sponsor_source_concept_id) as STRING)) != 0
		  )
      and cdmtable.sponsor_source_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.payer_plan_period
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PAYER_PLAN_PERIOD
cdmFieldName = STOP_REASON_CONCEPT_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'PAYER_PLAN_PERIOD.STOP_REASON_CONCEPT_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.payer_plan_period cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.stop_reason_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.stop_reason_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.stop_reason_concept_id) as STRING)) != 0
		  )
      and cdmtable.stop_reason_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.payer_plan_period
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = PAYER_PLAN_PERIOD
cdmFieldName = STOP_REASON_SOURCE_CONCEPT_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'PAYER_PLAN_PERIOD.STOP_REASON_SOURCE_CONCEPT_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.payer_plan_period cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.stop_reason_source_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.stop_reason_source_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.stop_reason_source_concept_id) as STRING)) != 0
		  )
      and cdmtable.stop_reason_source_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.payer_plan_period
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DRUG_ERA
cdmFieldName = DRUG_ERA_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'DRUG_ERA.DRUG_ERA_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.drug_era cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.drug_era_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.drug_era_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.drug_era_id) as STRING)) != 0
		  )
      and cdmtable.drug_era_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.drug_era
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DRUG_ERA
cdmFieldName = PERSON_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'DRUG_ERA.PERSON_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.drug_era cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.person_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.person_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.person_id) as STRING)) != 0
		  )
      and cdmtable.person_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.drug_era
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DRUG_ERA
cdmFieldName = DRUG_CONCEPT_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'DRUG_ERA.DRUG_CONCEPT_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.drug_era cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.drug_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.drug_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.drug_concept_id) as STRING)) != 0
		  )
      and cdmtable.drug_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.drug_era
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DRUG_ERA
cdmFieldName = DRUG_EXPOSURE_COUNT
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'DRUG_ERA.DRUG_EXPOSURE_COUNT' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.drug_era cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.drug_exposure_count AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.drug_exposure_count AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.drug_exposure_count) as STRING)) != 0
		  )
      and cdmtable.drug_exposure_count is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.drug_era
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = DRUG_ERA
cdmFieldName = GAP_DAYS
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'DRUG_ERA.GAP_DAYS' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.drug_era cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.gap_days AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.gap_days AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.gap_days) as STRING)) != 0
		  )
      and cdmtable.gap_days is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.drug_era
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_ERA
cdmFieldName = CONDITION_ERA_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'CONDITION_ERA.CONDITION_ERA_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_era cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.condition_era_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.condition_era_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.condition_era_id) as STRING)) != 0
		  )
      and cdmtable.condition_era_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_era
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_ERA
cdmFieldName = PERSON_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'CONDITION_ERA.PERSON_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_era cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.person_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.person_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.person_id) as STRING)) != 0
		  )
      and cdmtable.person_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_era
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_ERA
cdmFieldName = CONDITION_CONCEPT_ID
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'CONDITION_ERA.CONDITION_CONCEPT_ID' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_era cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.condition_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.condition_concept_id AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.condition_concept_id) as STRING)) != 0
		  )
      and cdmtable.condition_concept_id is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_era
) denominator
;

/*********
FIELD_CDM_DATATYPE
At a minimum, for each field that is supposed to be an integer, verify it is an integer
Parameters used in this template:
cdmDatabaseSchema = CY_IMOSPHERE_CDM_531
cdmTableName = CONDITION_ERA
cdmFieldName = CONDITION_OCCURRENCE_COUNT
**********/
select 
  num_violated_rows, 
	case 
		when denominator.num_rows = 0 then 0 
		else 1.0*num_violated_rows/denominator.num_rows 
	end as pct_violated_rows, 
	denominator.num_rows as num_denominator_rows
from
(
	select 
	  COUNT(violated_rows.violating_field) as num_violated_rows
	from
	(
		/*violatedRowsBegin*/
		select 
		  'CONDITION_ERA.CONDITION_OCCURRENCE_COUNT' as violating_field, 
		  cdmtable.* 
		from CY_IMOSPHERE_CDM_531.condition_era cdmtable
		where 
		  CASE WHEN SAFE_CAST(cdmtable.condition_occurrence_count AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 0 
		  or (
		    CASE WHEN SAFE_CAST(cdmtable.condition_occurrence_count AS FLOAT64) IS NULL THEN 0 ELSE 1 END = 1 
		    and strpos('.', cast(abs(cdmtable.condition_occurrence_count) as STRING)) != 0
		  )
      and cdmtable.condition_occurrence_count is not null
		/*violatedRowsEnd*/
	) violated_rows
) violated_row_count,
( 
	select 
	  COUNT(*) as num_rows
	from CY_IMOSPHERE_CDM_531.condition_era
) denominator
;

